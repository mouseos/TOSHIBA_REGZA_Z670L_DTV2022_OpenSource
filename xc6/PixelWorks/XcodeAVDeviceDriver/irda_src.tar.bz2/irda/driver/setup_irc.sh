#!/bin/sh

rmmod xc4_irda
insmod ./xc4_irda.ko
mknod /dev/irc c 61 0
mknod /dev/irc1 c 61 1
