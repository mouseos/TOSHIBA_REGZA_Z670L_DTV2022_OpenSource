#ifndef __XC4_IRDA_IOCTL_H__
#define __XC4_IRDA_IOCTL_H__

#include <linux/ioctl.h>

#define IRC_MAGIC   0xfe12ab89

typedef struct {
    unsigned int magic;
    int on;
    unsigned int pattern[8];
    unsigned int mask[8];
} IRC_PATTERN_MATCH_INFO;

#define XC4IRC_IOC_MAGIC 'i'
/*
 * S means "Set" through a ptr
 * T means "Tell" directly with the argument value
 * G means "Get": reply by setting through a pointer
 * Q means "Query": response is on the return value
 * X means "eXchange": G and S atomically
 * H means "sHift": T and Q atomically
 */
#define XC4IRC_IOCT_TX_CARRIER_LOW_CFG \
	_IOW(XC4IRC_IOC_MAGIC, 0x0001, unsigned int)
#define XC4IRC_IOCT_TX_CARRIER_HIGH_CFG \
	_IOW(XC4IRC_IOC_MAGIC, 0x0002, unsigned int)
#define XC4IRC_IOCT_IOC_RX_BIT_TIME \
	_IOW(XC4IRC_IOC_MAGIC, 0x0003, unsigned int)
#define XC4IRC_IOCT_IOC_RX_MAX_SPACE \
	_IOW(XC4IRC_IOC_MAGIC, 0x0004, unsigned int)
#define XC4IRC_IOCT_PATTERN_MATCH \
	_IOW(XC4IRC_IOC_MAGIC, 0x0005, unsigned int)

#endif
