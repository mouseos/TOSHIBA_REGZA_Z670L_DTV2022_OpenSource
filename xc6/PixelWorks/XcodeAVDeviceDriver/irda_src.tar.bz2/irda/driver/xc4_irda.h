#ifndef __XC4_IRDA_h__
#define __XC4_IRDA_h__

#include <linux/semaphore.h>
#include <linux/list.h>
#include <linux/timer.h>

#include "xc4_irda_ioctl.h"


#define XC4IRC_IRQ XCODE6_IRQ_IRC
#define XC4IRC_DRV_NAME "xcode4_irda"

#ifdef CONFIG_ARCH_ARC
#define CPU_INTERRUPT1_MASK MIPS3_INTERRUPT1_MASK
#define CPU_INTERRUPT1_MASK_IRC_INT_SHIFT MIPS3_INTERRUPT1_MASK_IRC_INT_SHIFT
#define CPU_INTERRUPT1 MIPS3_INTERRUPT1
#define CPU_INTERRUPT1_IRC_INT_MASK MIPS3_INTERRUPT1_IRC_INT_MASK
#else
#ifdef CONFIG_CPU_MIPS32
#define CPU_INTERRUPT1_MASK MIPS5_INTERRUPT1_MASK
#define CPU_INTERRUPT1_MASK_IRC_INT_SHIFT MIPS5_INTERRUPT1_MASK_IRC_INT_SHIFT
#define CPU_INTERRUPT1 MIPS5_INTERRUPT1
#define CPU_INTERRUPT1_IRC_INT_MASK MIPS5_INTERRUPT1_IRC_INT_MASK
#endif	/* CONFIG_CPU_MIPS32 */
#endif	/* CONFIG_ARCH_ARC */




/* stole from LIRC */
#define XC4IRC_DEV_MAJOR 61
#define XC4IRC_DEV_COUNT 2

#define XC4IRC_RX_BUF_SIZE 8192
#define XC4IRC_RX_BUF_DESC_NR 128

#define XC4IRC_RX_TIMER_DEFAULT HZ

/* 1/10s, 100ms */
#define XC4IRC_PATT_BH_TIMER_DEFAULT (HZ / 10)

struct xc4irc_rxbuf_desc {
	u32 rx_buf_offset;
	u32 rx_bits_count;
	struct list_head list;
};

struct xc4irc_controller {

	struct cdev cdev;

	dev_t devno;

	int core_id;

	u32 send_carries;
	u32 send_duty_cycle;

	u8 current_tx_port;
	u32 carrier_low_cfg;
	u32 carrier_high_cfg;
	int features;

	char *rx_buf;
	wait_queue_head_t inq;

	struct list_head rxbuf_descs;
	u32 rxbuf_outstanding;

	u32 pattern_match_on;
	u32 pattern_match_l;
	u32 pattern_match_h;
	u32 pattern_match_mask_l;
	u32 pattern_match_mask_h;

//	unsigned int rx_bits_count;
//	unsigned int rx_buf_offset;

	struct mutex mutex;

	struct timer_list rx_timer;
        struct timer_list patt_bh_timer;

        atomic_t pattern_matched;
};

struct xc4irc_master {
	struct xc4irc_controller *hosts[XC4IRC_DEV_COUNT];
	atomic_t host_opened[XC4IRC_DEV_COUNT];
};


#endif
