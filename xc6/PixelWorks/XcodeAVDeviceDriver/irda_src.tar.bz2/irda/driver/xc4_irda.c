#include <linux/version.h>

#include <linux/module.h>
#include <linux/errno.h>
#include <linux/signal.h>
#include <linux/sched.h>
#include <linux/fs.h>
#include <linux/interrupt.h>
#include <linux/ioport.h>
#include <linux/kernel.h>
#include <linux/major.h>
#include <linux/serial_reg.h>
#include <linux/time.h>
#include <linux/string.h>
#include <linux/types.h>
#include <linux/wait.h>
#include <linux/mm.h>
#include <linux/delay.h>
#include <linux/poll.h>
#include <linux/slab.h>
#include <linux/pci.h>
#include <linux/platform_device.h>
#include <linux/cdev.h>
#include <asm/system.h>
#include <linux/uaccess.h>
#include <linux/io.h>
#include <linux/irq.h>
#include <linux/fcntl.h>
#include <linux/completion.h>
#include <linux/dma-mapping.h>

#include <plat/xcodeRegDef.h>

#include "xc4_irda.h"

//#define DEBUG

#define KINFO(_fmt, _args...)			\
	printk(KERN_INFO _fmt, ## _args)

#ifdef DEBUG
#define KDEBUG(_fmt, _args...)				\
	printk(KERN_ERR "%s: " _fmt, __func__, ## _args)

#define JDUMPBUF(_buf, _size)						\
	do {									\
		int _i;							\
		char *c;							\
		c = (char *)(_buf);						\
		for (_i=0; _i<_size; _i++) {					\
			if ((_i != 0) && ((_i % 16) == 0) && (_i > 15 ))	\
			printk("\n");					\
			printk("%02x ", c[_i]);				\
		}								\
		printk("\n");							\
	} while(0)

#else
#define KDEBUG(_fmt, _args...)
#define JDUMPBUF(_buf, _size)
#endif

#define _MMFB_BASE 0x0
#define _MMREG(off)((unsigned long) ((unsigned long)XC_SOC_PROC_MMREG_BASE + ((unsigned long)(off))))


#define _MMFB_LOC(off) ((unsigned long)(_MMFB_BASE + (off)))

#define MMR_READ(reg) 				readl((void *)_MMREG(reg))
#define MMR_WRITE(data, reg)        writel( (data), (void *)(_MMREG(reg)))
#define MMFB_READ(off)              readl((void *)_MMFB_LOC(off))
#define MMFB_WRITE(data, off)       writel( (data), (void *)_MMFB_LOC(off))

#define init_MUTEX(x) mutex_init(x)

/* XXX: this is fixed for FPGA testing. 
 * Will not work if the PLL clock changed
 * Also assuming the protocol using 36KHz
 */
//#define CARR_H 0x200
//#define CARR_L 0x100
/* SONY */
#define CARR_H 125
#define CARR_L 375

/* 
 * Due to a hw bug, even with pattern match on, some "noises" can still
 * come up to the driver space. Originally it can be handled by the user space
 * easily  but someone want to have a
 * "driver of omniscience, omnipresence and omnipotence",
 * so we do everything here be a friendly guy because of someone's laziness
 */
#define SW_PATTERN_MATCH_ENABLE 0


/* 
 * hw bug in Viper Eng board. If the GPIO_C_CTRL:GPIO_MODE_SEL2 set 
 * (GPIO MODE), the TX port will be driven high and the transmitter
 * keep generating signals. Set this flag for forcing the driver
 * retain the GPIO_C_CTRL in HW mode for IRDA ports
 */
#define SW_WORKAROUND_HOLD_GPIO_C_IRDA_MODE 0


DECLARE_COMPLETION(tx_complete);

//static atomic_t xc4irc_opened;
//struct xc4irc_controller host;

struct xc4irc_master master;

/* obsoleted. use ioctl() instead */
#if 0
static int xc4irc_set_carrier(struct xc4irc_controller *host,
		unsigned int freq, unsigned int duty_cycle)
{
	/* XXX
	 * We need to use the external clock to compute 
	 * the current number of clocks
	 */
	if (freq != 0)
		host->send_carries = freq;

	if (duty_cycle != 0)
		host->send_duty_cycle = duty_cycle;

	host->carrier_low_cfg = CARR_L;
	host->carrier_high_cfg = CARR_H;

	MMR_WRITE(host->carrier_high_cfg, IRC_TX_CARRIER_HIGH_CFG);
	MMR_WRITE(host->carrier_low_cfg, IRC_TX_CARRIER_LOW_CFG);

	/* Set RX Carrier. Meaningless if we are using demod mode */
	MMR_WRITE((host->carrier_high_cfg + host->carrier_low_cfg + 1), 
			IRC_RX_CARR_CFG0);
	MMR_WRITE((host->carrier_high_cfg + host->carrier_low_cfg), 
			IRC_RX_CARR_CFG1);

	//	MMR_WRITE((host->carrier_high_cfg + host->carrier_low_cfg) * 32 - 1, 
	//		  IRC_RX_BIT_TIME);

	MMR_WRITE(11999, IRC_RX_BIT_TIME); /* SONY */


	return (0);

}
#endif

static int xc4irc_reset_hw(struct xc4irc_controller *host, int forced)
{
	volatile unsigned long s = 0;
	int i;
	int sth_opened = 0;

	for (i = 0; i < XC4IRC_DEV_COUNT; i++) {
		sth_opened |= atomic_read(& (master.host_opened[i]));
	}

	if (! sth_opened || forced) {
		/* Clear interrupt status */
		MMR_WRITE(1, IRC_TX_INT_STATUS);
		MMR_WRITE(3, IRC_RX0_INT_STATUS);

		/* first dev open, lets init the whole block */

		KDEBUG("First open, init whole block\n");

		// for low power mode, enable IRC clk
		s = MMR_READ(ACC_BLK_STOP0);
		clear_bit(IRC_BLK_STOP_SHIFT, &s);
		MMR_WRITE(s, ACC_BLK_STOP0);

		/* Set IRC_RESET */
		s = MMR_READ(ACC_RESET_REG0);
		set_bit(IRC_RESET_SHIFT, &s);
		MMR_WRITE(s, ACC_RESET_REG0);

#ifndef CONFIG_PLAT_XCODE68xx
		/* Retain the GPIO */
		s = MMR_READ(GPIO_C_CTRL);
		//	clear_bit(GPIO_C_CTRL_GPIO_MODE_SEL2_SHIFT, &s);
		clear_bit(29, &s);	/* XXX the RDF in VDS and kernel is NOT sync! */
		MMR_WRITE(s, GPIO_C_CTRL);
#else
		s = MMR_READ(GPIO_T_CTRL);
		clear_bit(31, &s);
		MMR_WRITE(s, GPIO_T_CTRL);
#endif
		/* disable loopback */
		MMR_WRITE(0, IRC_RX0_LPBK_EN);

		/* Take out IRC_RESET */
		s = MMR_READ(ACC_RESET_REG0);
		clear_bit(IRC_RESET_SHIFT, &s);
		MMR_WRITE(s, ACC_RESET_REG0);

		/* Enable IRQ to MIPS */
#ifdef USE_IIA
        IIALocalSetMask(IIA_IRC_INT);
#endif
	}

	switch (host->core_id) {
		case 0:
			/* Clear interrupt status */
			MMR_WRITE(1, IRC_TX_INT_STATUS);
			MMR_WRITE(3, IRC_RX0_INT_STATUS);

			/* Set RX Config
			 * Demodulate mode, Active Low
			 * Sample all bit times
			 */
			MMR_WRITE(IRC_RX0_CFG_ONE_QUART_SAMP_EN_MASK |
                IRC_RX0_CFG_TWO_QUART_SAMP_EN_MASK |
                IRC_RX0_CFG_THR_QUART_SAMP_EN_MASK
            /* Set this if you want to enable FIFO fill level interrupt */
            /* | (level & IRC_RX0_CFG_FIFO_FILL_THRESH) */
                , IRC_RX0_CFG);
			//		MMR_WRITE(0x71, IRC_RX_CFG);

			/* Only need to setup for host0. as only it has RX */
			/* Set up RX hardware buffer */
			KDEBUG("virt_to_phys(host.rx_buf) %p, host.rx_buf %p\n",
					(void *)virt_to_phys(master.hosts[0]->rx_buf),
					master.hosts[0]->rx_buf);
			MMR_WRITE(virt_to_phys(master.hosts[0]->rx_buf),
					IRC_RX0_LOWER_ADR);
			MMR_WRITE(XC4IRC_RX_BUF_SIZE, IRC_RX0_ADR_SIZE);

			/* XXX:
			 * This reg is protocol depenedance
			 * We should set extra API in IOCTL,
			 * or the hardware has a better way to do this?
			 */
			MMR_WRITE(32, IRC_RX0_MAX_SPACE); /* SONY */

			/* Enable IR block */
			MMR_WRITE(0, IRC_TX_CTRL);
			MMR_WRITE(0, IRC_RX0_CTRL);

			MMR_WRITE(1, IRC_TX_INT_EN);

			if (host->pattern_match_on) {
				/* bit0 RX_INT_EN off
				 * bit1 PATT_MATCH_EN on
				 */
				MMR_WRITE(IRC_RX0_INT_EN_PATT_MATCH_EN_MASK
/*                   | IRC_RX0_INT_EN_FIFO_FILL_THRESH_EN_MASK */,
                    IRC_RX0_INT_EN);
			} else {
				MMR_WRITE(IRC_RX0_INT_EN_INT_EN_MASK, IRC_RX0_INT_EN);
                for (i=0;i<8;i++)
                {
	    			MMR_WRITE((i<<IRC_RX0_PATT_MATCH_IDX_IDX_SHIFT) |
                        (1<<IRC_RX0_PATT_MATCH_IDX_RD_WRN_SHIFT) |
                        (0<<IRC_RX0_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
                        IRC_RX0_PATT_MATCH_IDX);
	    			MMR_WRITE(0, IRC_RX0_PATT_MATCH_WR_DATA);

	    			MMR_WRITE((i<<IRC_RX0_PATT_MATCH_IDX_IDX_SHIFT) |
                        (1<<IRC_RX0_PATT_MATCH_IDX_RD_WRN_SHIFT) |
                        (1<<IRC_RX0_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
                        IRC_RX0_PATT_MATCH_IDX);
	    			MMR_WRITE(0, IRC_RX0_PATT_MATCH_WR_DATA);
                }
			}

			break;

        #ifndef CONFIG_PLAT_XCODE68xx
		case 1:
			/* Clear interrupt status */
			MMR_WRITE(1, IRC_TX1_INT_STATUS);

			/* XXX:
			 * This reg is protocol depenedance
			 * We should set extra API in IOCTL,
			 * or the hardware has a better way to do this?
			 */
			MMR_WRITE(32, IRC_RX0_MAX_SPACE); /* SONY */

			/* Enable IR block */
			MMR_WRITE(0, IRC_TX1_CTRL);

			MMR_WRITE(1, IRC_TX1_INT_EN);


			break;
        #endif

	}


	return (0);
}

static unsigned int xc4irc_read_data_fb(u32 rx_buf_offset,
		u32 rx_bits_count,
		char **buf)
{
	unsigned int buf_len;
	unsigned int buf_flush_len;
	unsigned int buf_start;
	char *b;


	buf_len = rx_bits_count / 8;
	if ((rx_bits_count % 8) != 0)
		buf_len ++;

	/* test and set 32bits align */
	if ((buf_len & 0x3) == 0) {
		buf_flush_len = buf_len;
	} else {
		buf_flush_len = (buf_len + 4) & 0xfffffffc;
	}
	KDEBUG("bit_cnt %d, buf_len = %d, buf_flush_len = %d\n",
			rx_bits_count,
			buf_len,
			buf_flush_len);


	buf_start = MMR_READ(IRC_RX0_LOWER_ADR) + rx_buf_offset;
	inv_dcache_range((u32)phys_to_virt(buf_start), 
			(u32)phys_to_virt((buf_start + buf_flush_len)));

	/* XXX:
	 * This may be a bug in the ARC kernel
	 * the PHYS_SRAM_OFFSET and PAGE_OFFSET are the same
	 * hence the convertion fail. 
	 * see asm/page.h
	 */
	b = phys_to_virt(buf_start);
	*buf = b;

	return (buf_len);
}

#if SW_PATTERN_MATCH_ENABLE
/* This is what the HW pattern filter should do
 * but it get bug in the irq generation, we make a safe net
 * for them
 */
static int xc4irc_sw_pattern_match(struct xc4irc_controller *host, 
		char *buf, unsigned int len)
{
	u32 pattern_match_l;
	u32 pattern_match_h;
	u32 pattern_match_mask_l;
	u32 pattern_match_mask_h;
	u32 pl, ph;

	char buf2[8];
	u32 *word_buf;

	/* 
	 * Can omit the memcpy for speed, but handle the
	 * casting of the buffer smaller than word size is 
	 * messy. Can divide a special case path for this
	 * if memcpy is *strictly prohibited*
	 */
	memset(buf2, 0, 8);
	if (len <= 8) 
		memcpy(buf2, buf, len);
	else
		memcpy(buf2, buf, 8);

	/* XXX: will endian of reg and fb not match? */
	word_buf = (u32 *) buf2;

	KDEBUG("word_buf[0] 0x%08x, word_buf[1] 0x%08x\n",
			word_buf[0], word_buf[1]);

	if (host->pattern_match_on) {
		pattern_match_l = host->pattern_match_l;
		pattern_match_h = host->pattern_match_h;
		pattern_match_mask_l = host->pattern_match_mask_l;
		pattern_match_mask_h = host->pattern_match_mask_h;

		pl = word_buf[0] & pattern_match_mask_l;
		ph = word_buf[1] & pattern_match_mask_h;
		if (pl == pattern_match_l && ph == pattern_match_h)
			return 1;
		else
			return 0;

	} else {
		return 1;       /* no pattern match, always matched */
	}

	return (0);
}
#endif

static void xc4irc_stop_hw(struct xc4irc_controller *hostp)
{
	volatile unsigned long s = 0;

	int i;
	int sth_opened = 0;

	switch (hostp->core_id) {
		case 0:
			/* Clear interrupt status */
			MMR_WRITE(1, IRC_TX_INT_STATUS);
			MMR_WRITE(3, IRC_RX0_INT_STATUS);

			/* Disable IR block */
			MMR_WRITE(1, IRC_TX_CTRL);
			MMR_WRITE(1, IRC_RX0_CTRL);
			break;

        #ifndef CONFIG_PLAT_XCODE68xx
		case 1:
			/* Clear interrupt status */
			MMR_WRITE(1, IRC_TX1_INT_STATUS);

			/* Disable IR block */
			MMR_WRITE(1, IRC_TX1_CTRL);
    		break;
        #endif
        
	}

	for (i = 0; i < XC4IRC_DEV_COUNT; i++) {
		sth_opened |= atomic_read(& (master.host_opened[i]));
	}

	if (! sth_opened) {
		/* this is the last dev to close. off the hw */

		KDEBUG("Last close core id %d\n", hostp->core_id);

#if ! SW_WORKAROUND_HOLD_GPIO_C_IRDA_MODE
		/* release the GPIO */
		s = MMR_READ(GPIO_C_CTRL);
		//	set_bit(GPIO_C_CTRL_GPIO_MODE_SEL2_SHIFT, &s);
		set_bit(29, &s);
		MMR_WRITE(s, GPIO_C_CTRL);
#endif

		/* Set IRC_RESET */
		s = MMR_READ(ACC_RESET_REG0);
		set_bit(IRC_RESET_SHIFT, &s);
		MMR_WRITE(s, ACC_RESET_REG0);

		// for low power mode, disable IRC clk
		s = MMR_READ(ACC_BLK_STOP0);
		set_bit(IRC_BLK_STOP_SHIFT, &s);
		MMR_WRITE(s, ACC_BLK_STOP0);

	}


}

static void xc4irc_pop_rx_fifo(struct xc4irc_controller *hostp,
		int rx_seq_nr)
{
	int i;
	volatile unsigned long rx_data0 = 0;
	volatile unsigned long rx_data1 = 0;
	struct xc4irc_rxbuf_desc *new_rx_desc = NULL;

	u32 rx_buf_offset = 0;
	u32 rx_bits_count = 0;
#if SW_PATTERN_MATCH_ENABLE
	char *buf;
	unsigned int buf_len;
	int sw_patt_matched = 0;
#endif

	for (i = 0; i < rx_seq_nr; i++) {
		/* Pop the data */
		rx_data0 = MMR_READ(IRC_RX0_DATA0);
		set_bit(IRC_RX0_DATA0_ENTRY_POP_SHIFT, &rx_data0);
		MMR_WRITE(rx_data0, IRC_RX0_DATA0);


		/* re-read it */
		rx_data0 = MMR_READ(IRC_RX0_DATA0);
		rx_buf_offset =
			rx_data0 & IRC_RX0_DATA0_OFFSET_MASK;
		rx_bits_count =
			(rx_data0 & IRC_RX0_DATA0_BIT_CNT_MASK) >> IRC_RX0_DATA0_BIT_CNT_SHIFT;

#if SW_PATTERN_MATCH_ENABLE
		buf_len = xc4irc_read_data_fb(rx_buf_offset,
				rx_bits_count,
				&buf);
		JDUMPBUF(buf, buf_len);

		sw_patt_matched = xc4irc_sw_pattern_match(hostp, buf, buf_len);
		KDEBUG("sw_patt_matched %s\n", sw_patt_matched ? "yes" : "no");
		if (! sw_patt_matched) {
			continue;
		}
#endif

		new_rx_desc =
			kmalloc(sizeof(struct xc4irc_rxbuf_desc), GFP_ATOMIC);
		if (!new_rx_desc) {
			printk(KERN_ERR 
					"rxbuf_desc alloc failed!\n");
			break;
			/* TODO: Handle this error better */
		}

		list_add_tail(&(new_rx_desc->list),
				&(hostp->rxbuf_descs));

		new_rx_desc->rx_buf_offset =
			rx_data0 & IRC_RX0_DATA0_OFFSET_MASK;
		new_rx_desc->rx_bits_count =
			(rx_data0 & IRC_RX0_DATA0_BIT_CNT_MASK) >> IRC_RX0_DATA0_BIT_CNT_SHIFT;

		hostp->rxbuf_outstanding ++;

		KDEBUG("RX Data0 [%d] 0x%08x, bit cnt %d\n",
				i, rx_data0, new_rx_desc->rx_bits_count);

		rx_data1 = MMR_READ(IRC_RX0_DATA1);
		KDEBUG("RX Data1 [%d] 0x%08x\n",
				i, rx_data1);

	}

}

static irqreturn_t xc4irc_irq_handler(int irq, void *dev_id)
{
	volatile u32 int_sts = 0;
	volatile u32 rx_fifo_sts = 0;
	volatile u32 temp = 0;
	//volatile unsigned long rx_data0 = 0;
	//volatile unsigned long rx_data1 = 0;
	int rx_seq_nr = 0;
	int j;
	//u32 rx_idx = 0;
	irqreturn_t ret=IRQ_NONE;

	//struct xc4irc_rxbuf_desc *new_rx_desc = NULL;

#ifdef USE_IIA
	if (IIALocalReadInt(IIA_IRC_INT)) {
#endif
		for(j=0;j<XC4IRC_DEV_COUNT;j++)
		{
			struct xc4irc_controller *hostp =
				(struct xc4irc_controller *) master.hosts[j];

			KDEBUG("Get irq %d with dev %p core id %d\n",
				irq, dev_id, hostp->core_id);

			switch (hostp->core_id) {
				case 0:
					int_sts = MMR_READ(IRC_TX_INT_STATUS);
					break;
                
                #ifndef CONFIG_PLAT_XCODE68xx
				case 1:
					int_sts = MMR_READ(IRC_TX1_INT_STATUS);
					break;
                #endif
			}

			/* if host 0, we need to check the RX as well */
			if (int_sts == 0 && hostp->core_id != 0) {
				continue;
			}

			if (int_sts == 0x01) {
				KDEBUG("TX_STATUS 0x%08x\n", int_sts);

				switch (hostp->core_id) {
					case 0:
						MMR_WRITE(1, IRC_TX_INT_STATUS);
						break;

                    #ifndef CONFIG_PLAT_XCODE68xx
					case 1:
						MMR_WRITE(1, IRC_TX1_INT_STATUS);
						break;
                    #endif
				}

				complete(&tx_complete);
			} else {
				int_sts = MMR_READ(IRC_RX0_INT_STATUS);
				KDEBUG("RX0_STATUS 0x%08x\n", int_sts);

				temp = MMR_READ(IRC_RX0_INT_EN);
				KDEBUG("RX0_INT_EN 0x%08x\n", temp);

				if ((int_sts & IRC_RX0_INT_STATUS_INT_STATUS_MASK) ||
						(int_sts & IRC_RX0_INT_STATUS_PATT_MATCH_STATUS_MASK)) {

					rx_fifo_sts = MMR_READ(IRC_RX0_DATA_FIFO_STATUS);
					rx_seq_nr = rx_fifo_sts & IRC_RX0_DATA_FIFO_STATUS_NUM_OUTSTANDING_SEQ_MASK;
					KDEBUG("rx_fifo_sts 0x%08x, RX %d seqs\n",
							rx_fifo_sts,
							rx_seq_nr);

#if 0
					/* XXX Hardware delay? */
					/* the reg is not ready? */
					if (rx_seq_nr == 0) {
						int i = 12000;
						while (rx_seq_nr == 0) {
							/* we really need timeout, sorry */
							if (i <= 0)
								break;

							rx_fifo_sts = MMR_READ(IRC_RX_DATA_FIFO_STATUS);
							rx_seq_nr = rx_fifo_sts & RX_NUM_OUTSTANDING_SEQ_MASK;

							i--;
							udelay(10);
							/* XXX total wait 120ms */
						}
						KDEBUG("We polled the fifo %d loops\n",
								12000 - i);
					}
#endif

					if (hostp->pattern_match_on && rx_seq_nr == 0) {
						/* XXX Hardware bug: patt match IRQ 
						 * come too earily*/
						if ((int_sts & IRC_RX0_INT_STATUS_PATT_MATCH_STATUS_MASK)) {

							if (atomic_read(&hostp->pattern_matched) == 0) {
								hostp->patt_bh_timer.expires = jiffies + XC4IRC_PATT_BH_TIMER_DEFAULT;
								add_timer(&hostp->patt_bh_timer);

								atomic_set(&hostp->pattern_matched, 1);
							}
							MMR_WRITE(int_sts, IRC_RX0_INT_STATUS);
							ret=IRQ_RETVAL(IRQ_HANDLED);
							continue;
						}
					}

					if (hostp->rxbuf_outstanding >= 128) {
						KINFO("RX buffer full. No longer receive data\n");
						MMR_WRITE(0x3, IRC_RX0_INT_STATUS);
						ret=IRQ_RETVAL(IRQ_HANDLED);
						continue;
					}

					xc4irc_pop_rx_fifo(hostp, rx_seq_nr);


					MMR_WRITE(0x3, IRC_RX0_INT_STATUS);

					wake_up_interruptible(&(hostp->inq));

				} else if (int_sts & IRC_RX0_INT_STATUS_FIFO_FILL_THRESH_STATUS_MASK) {
                    //clear it now...nothing should be done with this interrupt yet
					MMR_WRITE(IRC_RX0_INT_STATUS_FIFO_FILL_THRESH_STATUS_MASK, IRC_RX0_INT_STATUS);
                } else {
					//				printk(KERN_ERR "We got an IRQ in CPU but not in IRC core!\n");
					continue;
				}
			}

			ret=IRQ_RETVAL(IRQ_HANDLED);
		}
#ifdef USE_IIA
	}
#endif
	return ret;

}

static int xc4irc_open(struct inode *inode, struct file *file)
{
	unsigned minor;

	KDEBUG("Open with nonblock: %s\n",
			((file->f_flags & O_NONBLOCK) ? "yes" : "no"));

	/* We assume the minor number is matching the core ids */
	minor = iminor(inode);
	KINFO("%s opened with minor %d\n",
			XC4IRC_DRV_NAME, minor);

	if (atomic_read(&(master.host_opened[minor]))) {
		KINFO("%s is using by another process\n",
				XC4IRC_DRV_NAME);
		return(-EBUSY);
	}


	//	file->private_data = &(host);
	file->private_data = master.hosts[minor];

	/* Set IRC_RESET */
	xc4irc_reset_hw(master.hosts[minor], 0);

	//	host.rxbuf_outstanding = 0;
	master.hosts[minor]->rxbuf_outstanding = 0;


	atomic_set(&(master.host_opened[minor]), 1);

	return (0);
}

static int xc4irc_close(struct inode *inode, struct file *filp)
{
	struct list_head *lp;
	struct list_head *n;
//	struct xc4irc_rxbuf_desc *deadpool[XC4IRC_RX_BUF_DESC_NR];
	struct xc4irc_controller *hostp;
	int i = 0;

	hostp = (struct xc4irc_controller *) filp->private_data;

	KINFO("%s closed\n", XC4IRC_DRV_NAME);

	atomic_set(& (master.host_opened[hostp->core_id]), 0);

	xc4irc_stop_hw(hostp);

	KDEBUG("hostp %p, &(hostp->rxbuf_descs) %p, (&(hostp->rxbuf_descs))->next %p\n",
			hostp , &(hostp->rxbuf_descs), (&(hostp->rxbuf_descs))->next);	  

	list_for_each_safe(lp, n, &(hostp->rxbuf_descs)) {
		list_del(lp);
		kfree(list_entry(lp, struct xc4irc_rxbuf_desc, list));
		i++;
	}
	if (i > 0)
		KINFO("%d rx data outstanding. Free up now\n", i);

	atomic_set(&hostp->pattern_matched, 0);
	del_timer(&hostp->rx_timer);
	del_timer(&hostp->patt_bh_timer);

	return (0);
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
static int xc4irc_ioctl(struct inode *inode, struct file *filp,
		unsigned int cmd, unsigned long arg)
#else
static long xc4irc_ioctl(struct file *filp,	unsigned int cmd, unsigned long arg)
#endif
{
    IRC_PATTERN_MATCH_INFO *info;
	struct xc4irc_controller *hostp;
	int core_id;
	int err = 0, i;

	hostp = (struct xc4irc_controller *) filp->private_data;
	core_id = hostp->core_id;

	KINFO("IOCTL cmd 0x%08x arg %lu\n",
			cmd, arg);

	switch (cmd) {
		case XC4IRC_IOCT_TX_CARRIER_LOW_CFG:
			hostp->carrier_low_cfg = arg;
			switch (core_id) {
				default:
				case 0:
#ifdef CONFIG_PLAT_XCODE68xx
					hostp->carrier_low_cfg = hostp->carrier_low_cfg*162/144;
#endif
					MMR_WRITE(hostp->carrier_low_cfg, 
							IRC_TX_CARRIER_LOW_CFG);
					break;

                #ifndef CONFIG_PLAT_XCODE68xx
				case 1:
					MMR_WRITE(hostp->carrier_low_cfg, 
							IRC_TX1_CARRIER_LOW_CFG);
					break;
                #endif
			}
			break;

		case XC4IRC_IOCT_TX_CARRIER_HIGH_CFG:
			hostp->carrier_high_cfg = arg;
			switch (core_id) {
				default:
				case 0:
#ifdef CONFIG_PLAT_XCODE68xx
					hostp->carrier_high_cfg = hostp->carrier_high_cfg*162/144;
#endif
					MMR_WRITE(hostp->carrier_high_cfg,
							IRC_TX_CARRIER_HIGH_CFG);
					break;

                #ifndef CONFIG_PLAT_XCODE68xx
				case 1:
					MMR_WRITE(hostp->carrier_high_cfg,
							IRC_TX1_CARRIER_HIGH_CFG);
					break;
                #endif
			}
			break;

		case  XC4IRC_IOCT_IOC_RX_BIT_TIME:
#ifdef CONFIG_PLAT_XCODE68xx
                        arg=arg*162/144;
#endif
			if (core_id == 0)
				MMR_WRITE(arg, IRC_RX0_BIT_TIME);
			break;

		case  XC4IRC_IOCT_IOC_RX_MAX_SPACE:
			if (core_id == 0)
				MMR_WRITE(arg, IRC_RX0_MAX_SPACE);
			break;

		case XC4IRC_IOCT_PATTERN_MATCH:
            info=(IRC_PATTERN_MATCH_INFO *)arg;
            if(info->magic!=IRC_MAGIC)
                return -EINVAL;
			/* only core 0 have RX and pattern match */
			if (hostp->core_id == 0) {
				if (hostp->pattern_match_on != info->on) {
					hostp->pattern_match_on = info->on;

					/* interrupt mode need change */
					err = xc4irc_reset_hw(hostp, 0);
				}
				if (hostp->pattern_match_on) {
					KDEBUG("Start Timer\n");
					hostp->rx_timer.expires = jiffies + 
						XC4IRC_RX_TIMER_DEFAULT;
                    for (i=0;i<8;i++)
                    {
    	    			MMR_WRITE(info->pattern[i], IRC_RX0_PATT_MATCH_WR_DATA);
	        			MMR_WRITE((i<<IRC_RX0_PATT_MATCH_IDX_IDX_SHIFT) |
                            (0<<IRC_RX0_PATT_MATCH_IDX_RD_WRN_SHIFT) |
                            (0<<IRC_RX0_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
                            IRC_RX0_PATT_MATCH_IDX);
    
	    			    MMR_WRITE(info->mask[i], IRC_RX0_PATT_MATCH_WR_DATA);
	        			MMR_WRITE((i<<IRC_RX0_PATT_MATCH_IDX_IDX_SHIFT) |
                            (0<<IRC_RX0_PATT_MATCH_IDX_RD_WRN_SHIFT) |
                            (1<<IRC_RX0_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
                            IRC_RX0_PATT_MATCH_IDX);
                    }
#if 0
                    for (i=0;i<8;i++)
                    {
	        			MMR_WRITE((i<<IRC_RX0_PATT_MATCH_IDX_IDX_SHIFT) |
                            (1<<IRC_RX0_PATT_MATCH_IDX_RD_WRN_SHIFT) |
                            (0<<IRC_RX0_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
                            IRC_RX0_PATT_MATCH_IDX);
    	    			printk("patt %d = 0x%08x\n", i, MMR_READ(IRC_RX0_PATT_MATCH_RD_DATA));
                    }
                    for (i=0;i<8;i++)
                    {
	        			MMR_WRITE((i<<IRC_RX0_PATT_MATCH_IDX_IDX_SHIFT) |
                            (1<<IRC_RX0_PATT_MATCH_IDX_RD_WRN_SHIFT) |
                            (1<<IRC_RX0_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
                            IRC_RX0_PATT_MATCH_IDX);
    	    			printk("mask %d = 0x%08x\n", i, MMR_READ(IRC_RX0_PATT_MATCH_RD_DATA));
                    }
#endif
					add_timer(&hostp->rx_timer);
				} else {
					KDEBUG("Del Timer\n");
                    for (i=0;i<8;i++)
                    {
	        			MMR_WRITE((i<<IRC_RX0_PATT_MATCH_IDX_IDX_SHIFT) |
                            (1<<IRC_RX0_PATT_MATCH_IDX_RD_WRN_SHIFT) |
                            (0<<IRC_RX0_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
                            IRC_RX0_PATT_MATCH_IDX);
    	    			MMR_WRITE(0, IRC_RX0_PATT_MATCH_WR_DATA);
    
	        			MMR_WRITE((i<<IRC_RX0_PATT_MATCH_IDX_IDX_SHIFT) |
                            (1<<IRC_RX0_PATT_MATCH_IDX_RD_WRN_SHIFT) |
                            (1<<IRC_RX0_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
                            IRC_RX0_PATT_MATCH_IDX);
	    			    MMR_WRITE(0, IRC_RX0_PATT_MATCH_WR_DATA);
                    }
					del_timer(&hostp->rx_timer);
				}

			}
			break;

#if 0
		case XC4IRC_IOCT_PATTERN_MATCH_L:
			hostp->pattern_match_l = arg;
			KDEBUG("patt low 0x%08x\n", arg);
			MMR_WRITE(hostp->pattern_match_l, IRC_RX0_PATT_MATCH_L);
			break;

		case XC4IRC_IOCT_PATTERN_MATCH_H:
			hostp->pattern_match_h = arg;
			KDEBUG("patt high 0x%08x\n", arg);
			MMR_WRITE(hostp->pattern_match_h, IRC_RX0_PATT_MATCH_H);
			break;

		case XC4IRC_IOCT_PATTERN_MATCH_MASK_L:
			hostp->pattern_match_mask_l = arg;
			MMR_WRITE(hostp->pattern_match_mask_l,
					IRC_RX0_PATT_MATCH_MASK_L);
			break;

		case XC4IRC_IOCT_PATTERN_MATCH_MASK_H:
			hostp->pattern_match_mask_h = arg;
			MMR_WRITE(hostp->pattern_match_mask_h,
					IRC_RX0_PATT_MATCH_MASK_H);
			break;
#endif
	}

	return (0);
}

static ssize_t xc4irc_read(struct file *filp, char __user *buf,
		size_t count, loff_t *f_pos)
{
	struct xc4irc_controller *hostp;
	unsigned int buf_len;
	//unsigned int buf_flush_len;
	//unsigned int buf_start;
	char *b;
	//u32 rx_idx = 0;
	struct xc4irc_rxbuf_desc *rx_desc = NULL;
	struct list_head *lp;
	int i = 0;

	hostp = filp->private_data;

	KDEBUG("START\n");

	/* only core 0 have RX */
	if (hostp->core_id != 0) {
		return -EINVAL;
	}

	if (mutex_lock_interruptible(&(hostp->mutex)))
		return -ERESTARTSYS;


	KDEBUG("start rxbuf_outstanding %d\n", 
			hostp->rxbuf_outstanding);

	if (hostp->rxbuf_outstanding <= 0) {

		if (filp->f_flags & O_NONBLOCK) {
			mutex_unlock(&(hostp->mutex));
			return (-EAGAIN);
		}

		/* Must wait */
		if (wait_event_interruptible(hostp->inq,
					(hostp->rxbuf_outstanding > 0))) {
			mutex_unlock(&(hostp->mutex));

			return (-ERESTARTSYS);
		}

	}

	/* return from wait */

	lp = hostp->rxbuf_descs.next;
	rx_desc = list_entry(lp, struct xc4irc_rxbuf_desc, list);

	buf_len = xc4irc_read_data_fb(rx_desc->rx_buf_offset,
			rx_desc->rx_bits_count,
			&b);

	JDUMPBUF(b, buf_len);

	/* Some body reported that they saw extra zeros at the end of
	 * a sequence. The sequence length is reported by hardware with 
	 * bits count and I have no idea why hardware likes to generate 
	 * few more zeros at the end, may be noise, may be aligment.
	 * I do not care as the application should always handle their
	 * protocol-engine and parse the raw data. But they expected a
	 * philosopher's stone-like kernel driver, so I do this for the
	 * lamentable case
	 */
	if (buf_len > count)
		buf_len = count;

	for (i = (buf_len-1); i >=0; i--) {
		if (b[i] != 0x00) {
			break;
		}
	}
	KDEBUG("i = %d, chop %d bytes from tail\n", i, buf_len - (i+1));

	buf_len = i + 1;

	copy_to_user(buf, b, buf_len);

	list_del(lp);
	kfree(rx_desc);
	hostp->rxbuf_outstanding --;

	//	hostp->rx_bits_count = 0;

	mutex_unlock(&(hostp->mutex));

	return (buf_len);
}

static ssize_t xc4irc_write(struct file *filp, const char __user *buf, 
		size_t count, loff_t *f_pos)
{
	struct xc4irc_controller *hostp;
	unsigned int *instructions;
	unsigned int inst_end;
	//int i;
	int inst_nr = 0;
	u32 tx_base = 0;
	u32 tx_ins_desc = 0;

	int core_id = 0;

	hostp = filp->private_data;
	core_id = hostp->core_id;


	if (mutex_lock_interruptible(&(hostp->mutex)))
		return -ERESTARTSYS;

	KDEBUG("write call");

	instructions = (unsigned int *) kmalloc(count, GFP_KERNEL);
	if (!instructions) {
		KINFO("Cannot allocate buffer for instructions\n");
		mutex_unlock(&(hostp->mutex));
		return (-ENOMEM);
	}


	copy_from_user((void *)instructions, buf, count);
	inst_nr = count / sizeof(unsigned int);

	/*
		 for (i = 0; i < inst_nr; i++) {
		 printk("0x%08x\n", instructions[i]);
		 }
	 */

	/* MIPS kernel cache.h do the macro unsafely
	 * Work around it
	 */
	/*
		 flush_dcache_range(instructions,
		 ((char *)instructions) + length);
	 */
	inst_end = (unsigned int)((char *) instructions) + count;
	flush_dcache_range(((unsigned int)instructions), inst_end);

	tx_base = virt_to_phys(instructions);
	tx_ins_desc = inst_nr << TX_NUM_OF_INS_SHIFT;
	KDEBUG("tx_base 0x%08x, tx_ins_desc 0x%08x\n",
			tx_base, tx_ins_desc);

	switch (core_id) {
		default:
		case 0:
			MMR_WRITE(tx_base, IRC_TX_BASE_ADR);
			MMR_WRITE(tx_ins_desc, IRC_TX_INS_DESC);
			MMR_WRITE(1, IRC_TX_RUN);
			break;

        #ifndef CONFIG_PLAT_XCODE68xx
		case 1:
			MMR_WRITE(tx_base, IRC_TX1_BASE_ADR);
			MMR_WRITE(tx_ins_desc, IRC_TX1_INS_DESC);
			MMR_WRITE(1, IRC_TX1_RUN);
			break;
        #endif
	}


	wait_for_completion(&tx_complete);

	kfree(instructions);

	mutex_unlock(&(hostp->mutex));
	return (count);

}

unsigned int xc4irc_poll(struct file *filp, poll_table *wait)
{
	struct xc4irc_controller *hostp;
	unsigned int mask = 0;

	hostp = filp->private_data;

	KDEBUG("Before poll_wait\n");
	poll_wait(filp, &(hostp->inq), wait);
	KDEBUG("After poll_wait, rxbuf_outstanding %d\n",
			hostp->rxbuf_outstanding);

	if (hostp->rxbuf_outstanding > 0) {
		/* have data readable, tell them */
		mask = (POLLIN | POLLRDNORM);
	}

	KDEBUG("return mask 0x%08x\n", mask);

	return (mask);
}

void xc4irc_patt_bh_timer_fn(unsigned long arg)
{
	struct xc4irc_controller *host;
	volatile u32 rx_fifo_sts = 0;
	volatile u32 int_sts = 0;
	//volatile unsigned long rx_data0 = 0;
	int rx_seq_nr = 0;
	//int i;

	KDEBUG("PATTERN Matching BH start\n");

	host = (struct xc4irc_controller *) arg;

	/* sanity test */
	if (host->core_id != 0) {
		goto out;
	}

	if (!host->pattern_match_on) {
		goto out;
	}

	int_sts = MMR_READ(IRC_RX0_INT_STATUS);
	KDEBUG("RX_STATUS 0x%08x\n", int_sts);
	//        if (int_sts & PATT_MATCH_STATUS_MASK) {
	if (atomic_read (&host->pattern_matched)) {

		rx_fifo_sts = MMR_READ(IRC_RX0_DATA_FIFO_STATUS);
		rx_seq_nr = rx_fifo_sts & IRC_RX0_DATA_FIFO_STATUS_NUM_OUTSTANDING_SEQ_MASK;

		if (rx_seq_nr <= 0) {
			KDEBUG("We still have no full seq...\n");
			goto out;
		}

		/* let main irq handler handle this */
		if (host->rxbuf_outstanding >= 128) {
			goto out;
		}

		xc4irc_pop_rx_fifo(host, rx_seq_nr);

		wake_up_interruptible(&(host->inq));
	}

out:
	//        MMR_WRITE(int_sts, IRC_RX_INT_STATUS);
	//        MMR_WRITE(3, IRC_RX_INT_STATUS);
	atomic_set(&host->pattern_matched, 0);
	return;

}

void xc4irc_rx_timer_fn(unsigned long arg)
{
	struct xc4irc_controller *host;
	volatile u32 rx_fifo_sts = 0;
	volatile u32 int_sts = 0;
	volatile unsigned long rx_data0 = 0;
	int rx_seq_nr = 0;
	int i;

	KDEBUG("RX timer start\n");

	host = (struct xc4irc_controller *) arg;

	/* sanity test */
	if (host->core_id != 0) {
		goto resched;
	}

	if (!host->pattern_match_on) {
		goto resched;
	}

	rx_fifo_sts = MMR_READ(IRC_RX0_DATA_FIFO_STATUS);
	rx_seq_nr = rx_fifo_sts & IRC_RX0_DATA_FIFO_STATUS_NUM_OUTSTANDING_SEQ_MASK;	

	/* nothing in fifo */
	if (rx_seq_nr == 0) {
		goto resched;
	} else {
		int_sts = MMR_READ(IRC_RX0_INT_STATUS);
		KDEBUG("RX_STATUS 0x%08x\n", int_sts);
		if (int_sts & IRC_RX0_INT_STATUS_PATT_MATCH_STATUS_MASK || 
				(atomic_read (&host->pattern_matched))) {
			KDEBUG("Go resched\n");
			/* pattern matched. Let IRQ handler takes care */
			goto resched;
		} else {
			KDEBUG("POP rx_seq_nr %d\n", rx_seq_nr);
#if ! SW_PATTERN_MATCH_ENABLE
			for (i = 0; i < rx_seq_nr; i++) {
				/* Pop the data */
				rx_data0 = MMR_READ(IRC_RX0_DATA0);
				set_bit(IRC_RX0_DATA0_ENTRY_POP_SHIFT, &rx_data0);
				MMR_WRITE(rx_data0, IRC_RX0_DATA0);
			}
#else
			/* XXX: A special case of a correct sequence
			 * can be missed in the normal path
			 * 1. a noise seq arrived, RX_STATUS on
			 * 2. meanwhile a pattern arrived, but the whole 
			 * seq is not yet fin, due to a hw bug, the 
			 * PATT_MATCH is on even the seq is not finished
			 * 3. The irq handler kicks in, see the PATT_MATCH on
			 * with outstanding seq num 1 (as the first noise seq)
			 * this confused the handler thinks that noise seq is
			 * a correct one
			 * 4. pop the fifo, and the sw filter will discard the
			 * noise seq
			 * 5. irq handler clear all irq status, the info of the
			 * half-arrived pattern is lost
			 * 6. the whole seq of this pattern is arrived, but no 
			 * way can know it now as this will not gen an IRQ
			 * 7. rx timer kicks in, see the outstand seq no > 0
			 * when clean up the fifo as treat it as noise
			 * So before we clean the trash can, we take a look 
			 * inside it first to rescue the gems
			 */
			xc4irc_pop_rx_fifo(host, rx_seq_nr);
			wake_up_interruptible(&(host->inq));
#endif
		}
	}



resched:
	host->rx_timer.expires = jiffies + XC4IRC_RX_TIMER_DEFAULT;
	add_timer(&host->rx_timer);

	return;
}


struct file_operations xc4irc_fops = {
	.owner = THIS_MODULE,
	.open = xc4irc_open,
	.release = xc4irc_close,
	.write = xc4irc_write,
	.read = xc4irc_read,
#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 36)
	.ioctl = xc4irc_ioctl,
#else
	.unlocked_ioctl = xc4irc_ioctl,
#endif
	.poll = xc4irc_poll,
};

#ifdef CONFIG_PM

#define SAVE_IRC_REG(reg) 	reg_saved[((reg)-IRC_TX_RUN)*4] = MMR_READ((reg))
#define RESTORE_IRC_REG(reg) 	MMR_WRITE(reg_saved[((reg)-IRC_TX_RUN)*4], (reg)) 

static u32 reg_saved[(IRC_DUMMY_REG - IRC_TX_RUN + 1)*4];
static u32 reg_pattern_saved[2][8];
static u32 reg_pattern_mask_saved[2][8];

static int xc_irda_suspend(struct platform_device *dev, pm_message_t state)
{
	int i;

  	printk("xc_irda: suspend\n");

	SAVE_IRC_REG(IRC_TX_CTRL);
	SAVE_IRC_REG(IRC_TX_CARRIER_LOW_CFG);
	SAVE_IRC_REG(IRC_TX_CARRIER_HIGH_CFG);
	SAVE_IRC_REG(IRC_TX_BASE_ADR);
	SAVE_IRC_REG(IRC_TX_INT_EN);

    #ifndef CONFIG_PLAT_XCODE68xx
	SAVE_IRC_REG(IRC_TX1_CTRL);
	SAVE_IRC_REG(IRC_TX1_CARRIER_LOW_CFG);
	SAVE_IRC_REG(IRC_TX1_CARRIER_HIGH_CFG);
	SAVE_IRC_REG(IRC_TX1_BASE_ADR);
	SAVE_IRC_REG(IRC_TX1_INT_EN);
    #endif

	SAVE_IRC_REG(IRC_RX0_CTRL);
	SAVE_IRC_REG(IRC_RX0_CFG);
	SAVE_IRC_REG(IRC_RX0_CARR_CFG0);
	SAVE_IRC_REG(IRC_RX0_CARR_CFG1);
	SAVE_IRC_REG(IRC_RX0_BIT_TIME);
	SAVE_IRC_REG(IRC_RX0_LOWER_ADR);
	SAVE_IRC_REG(IRC_RX0_ADR_SIZE);
	SAVE_IRC_REG(IRC_RX0_MAX_SPACE);
	SAVE_IRC_REG(IRC_RX0_INT_EN);
	SAVE_IRC_REG(IRC_RX0_PATT_MATCH_START_BIT);
	for (i=0;i<8;i++)
	{
		MMR_WRITE((i<<IRC_RX0_PATT_MATCH_IDX_IDX_SHIFT) |
				(0<<IRC_RX0_PATT_MATCH_IDX_RD_WRN_SHIFT) |
				(0<<IRC_RX0_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
				IRC_RX0_PATT_MATCH_IDX);
		reg_pattern_saved[0][i]=MMR_READ(IRC_RX0_PATT_MATCH_WR_DATA);

		MMR_WRITE((i<<IRC_RX0_PATT_MATCH_IDX_IDX_SHIFT) |
				(0<<IRC_RX0_PATT_MATCH_IDX_RD_WRN_SHIFT) |
				(1<<IRC_RX0_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
				IRC_RX0_PATT_MATCH_IDX);
		reg_pattern_mask_saved[0][i]=MMR_READ(IRC_RX0_PATT_MATCH_WR_DATA);
	}
	SAVE_IRC_REG(IRC_RX0_LPBK_EN);

	SAVE_IRC_REG(IRC_RX1_CTRL);
	SAVE_IRC_REG(IRC_RX1_CFG);
	SAVE_IRC_REG(IRC_RX1_CARR_CFG0);
	SAVE_IRC_REG(IRC_RX1_CARR_CFG1);
	SAVE_IRC_REG(IRC_RX1_BIT_TIME);
	SAVE_IRC_REG(IRC_RX1_LOWER_ADR);
	SAVE_IRC_REG(IRC_RX1_ADR_SIZE);
	SAVE_IRC_REG(IRC_RX1_MAX_SPACE);
	SAVE_IRC_REG(IRC_RX1_INT_EN);
	SAVE_IRC_REG(IRC_RX1_PATT_MATCH_START_BIT);
	for (i=0;i<8;i++)
	{
		MMR_WRITE((i<<IRC_RX1_PATT_MATCH_IDX_IDX_SHIFT) |
				(0<<IRC_RX1_PATT_MATCH_IDX_RD_WRN_SHIFT) |
				(0<<IRC_RX1_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
				IRC_RX1_PATT_MATCH_IDX);
		reg_pattern_saved[1][i]=MMR_READ(IRC_RX1_PATT_MATCH_WR_DATA);

		MMR_WRITE((i<<IRC_RX1_PATT_MATCH_IDX_IDX_SHIFT) |
				(0<<IRC_RX1_PATT_MATCH_IDX_RD_WRN_SHIFT) |
				(1<<IRC_RX1_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
				IRC_RX1_PATT_MATCH_IDX);
		reg_pattern_mask_saved[1][i]=MMR_READ(IRC_RX1_PATT_MATCH_WR_DATA);
	}
	SAVE_IRC_REG(IRC_RX1_LPBK_EN);

  return 0;
}

static int xc_irda_resume(struct platform_device *dev)
{
	int i;

  printk("xc_irda: resume\n");

	for (i = 0; i < XC4IRC_DEV_COUNT; i++) 
		xc4irc_reset_hw(master.hosts[i], 1);

	RESTORE_IRC_REG(IRC_TX_CTRL);
	RESTORE_IRC_REG(IRC_TX_CARRIER_LOW_CFG);
	RESTORE_IRC_REG(IRC_TX_CARRIER_HIGH_CFG);
	RESTORE_IRC_REG(IRC_TX_BASE_ADR);
	RESTORE_IRC_REG(IRC_TX_INT_EN);

    #ifndef CONFIG_PLAT_XCODE68xx
	RESTORE_IRC_REG(IRC_TX1_CTRL);
	RESTORE_IRC_REG(IRC_TX1_CARRIER_LOW_CFG);
	RESTORE_IRC_REG(IRC_TX1_CARRIER_HIGH_CFG);
	RESTORE_IRC_REG(IRC_TX1_BASE_ADR);
	RESTORE_IRC_REG(IRC_TX1_INT_EN);
    #endif
    
	RESTORE_IRC_REG(IRC_RX0_CTRL);
	RESTORE_IRC_REG(IRC_RX0_CFG);
	RESTORE_IRC_REG(IRC_RX0_CARR_CFG0);
	RESTORE_IRC_REG(IRC_RX0_CARR_CFG1);
	RESTORE_IRC_REG(IRC_RX0_BIT_TIME);
	RESTORE_IRC_REG(IRC_RX0_LOWER_ADR);
	RESTORE_IRC_REG(IRC_RX0_ADR_SIZE);
	RESTORE_IRC_REG(IRC_RX0_MAX_SPACE);
	RESTORE_IRC_REG(IRC_RX0_INT_EN);
	RESTORE_IRC_REG(IRC_RX0_PATT_MATCH_START_BIT);
	for (i=0;i<8;i++)
	{
		MMR_WRITE((i<<IRC_RX0_PATT_MATCH_IDX_IDX_SHIFT) |
				(1<<IRC_RX0_PATT_MATCH_IDX_RD_WRN_SHIFT) |
				(0<<IRC_RX0_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
				IRC_RX0_PATT_MATCH_IDX);
		MMR_WRITE(reg_pattern_saved[0][i], IRC_RX0_PATT_MATCH_WR_DATA);

		MMR_WRITE((i<<IRC_RX0_PATT_MATCH_IDX_IDX_SHIFT) |
				(1<<IRC_RX0_PATT_MATCH_IDX_RD_WRN_SHIFT) |
				(1<<IRC_RX0_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
				IRC_RX0_PATT_MATCH_IDX);
		MMR_WRITE(reg_pattern_mask_saved[0][i], IRC_RX0_PATT_MATCH_WR_DATA);
	}
	RESTORE_IRC_REG(IRC_RX0_LPBK_EN);
 
	for (i=0;i<8;i++)
	{
		MMR_WRITE((i<<IRC_RX1_PATT_MATCH_IDX_IDX_SHIFT) |
				(1<<IRC_RX1_PATT_MATCH_IDX_RD_WRN_SHIFT) |
				(0<<IRC_RX1_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
				IRC_RX1_PATT_MATCH_IDX);
		MMR_WRITE(reg_pattern_saved[1][i], IRC_RX1_PATT_MATCH_WR_DATA);

		MMR_WRITE((i<<IRC_RX1_PATT_MATCH_IDX_IDX_SHIFT) |
				(1<<IRC_RX1_PATT_MATCH_IDX_RD_WRN_SHIFT) |
				(1<<IRC_RX1_PATT_MATCH_IDX_PATT_OR_MASK_SHIFT), 
				IRC_RX1_PATT_MATCH_IDX);
		MMR_WRITE(reg_pattern_mask_saved[1][i], IRC_RX1_PATT_MATCH_WR_DATA);
	}
	RESTORE_IRC_REG(IRC_RX1_LPBK_EN);

  return 0;
}

static struct platform_driver xc_irda_driver = { 
  .driver   = { 
    .name = "xc_irda",
    .owner  = THIS_MODULE,
  },  
  .suspend  = xc_irda_suspend,
  .resume   = xc_irda_resume,
};

static struct platform_device *xc_irda_platform_device;

static int __init xc_irda_init(void)
{
  int error;

  printk("%s\n", __FUNCTION__);

  error = platform_driver_register(&xc_irda_driver);
  if (error)
    return error;

  xc_irda_platform_device = platform_device_alloc("xc_irda", -1);
  if (!xc_irda_platform_device) {
    error = -ENOMEM;
    goto err_driver_unregister;
  }

  error = platform_device_add(xc_irda_platform_device);
  if (error)
    goto err_free_device;


  return 0;

 err_free_device:
  platform_device_put(xc_irda_platform_device);
 err_driver_unregister:
  platform_driver_unregister(&xc_irda_driver);
  return error;
}

static void __exit xc_irda_exit(void)
{
  platform_device_unregister(xc_irda_platform_device);
  platform_driver_unregister(&xc_irda_driver);
  printk(KERN_INFO "xc_irda: removed.\n");
}
#endif

static int __init xc4irc_init(void)
{
	int err = 0;
	dev_t devno;
	int i;
	struct xc4irc_controller *host;


	printk("Load LIRC XCODE6\n");

#ifdef CONFIG_PM
	xc_irda_init();
#endif

	err = register_chrdev(XC4IRC_DEV_MAJOR, XC4IRC_DRV_NAME,
			&xc4irc_fops);
	if (err) {
		printk(KERN_ERR "xc4_irda: register_chrdev failed\n");
		goto _exit1;
	}


	for (i = 0; i < XC4IRC_DEV_COUNT; i++) {
		host = master.hosts[i] = kmalloc(sizeof(struct xc4irc_controller),
				GFP_KERNEL);

		memset(host, 0, sizeof(struct xc4irc_controller));

		devno = MKDEV(XC4IRC_DEV_MAJOR, i);
		host->devno = devno;
		atomic_set(&(master.host_opened[i]), 0);

		host->core_id = i;

		INIT_LIST_HEAD(&(host->rxbuf_descs));


		host->rx_buf = kmalloc(XC4IRC_RX_BUF_SIZE, GFP_KERNEL);
		if (host->rx_buf == NULL) {
			err = -ENOMEM;
			goto _exit2;
		}

		init_waitqueue_head(&(host->inq));
		init_MUTEX(&(host->mutex));

		/* only host0 have RX */
		if (i == 0) {
			/* init the timer for RX FIFO clean up */
			host->rx_timer.data = (unsigned long) host;
			host->rx_timer.expires = XC4IRC_RX_TIMER_DEFAULT;
			host->rx_timer.function = xc4irc_rx_timer_fn;
			init_timer(&host->rx_timer);

			host->patt_bh_timer.data = (unsigned long) host;
			host->patt_bh_timer.expires = XC4IRC_PATT_BH_TIMER_DEFAULT;
			host->patt_bh_timer.function = xc4irc_patt_bh_timer_fn;
			init_timer(&host->patt_bh_timer);
		}
	}

	err = request_irq(XC4IRC_IRQ,
			xc4irc_irq_handler,
			IRQF_SHARED,
			XC4IRC_DRV_NAME,
			(void *) &master);
	if (err) {
		goto _exit2;
	}

	return (0);

_exit2:
	unregister_chrdev(XC4IRC_DEV_MAJOR, XC4IRC_DRV_NAME);

_exit1:
	return (err);

}

static void __exit xc4irc_exit(void)
{
	int i;

	printk("Exit LIRC XCODE6\n");

	free_irq(XC4IRC_IRQ, &master);
	//	unregister_chrdev_region(host.devno, XC4IRC_DEV_COUNT);
	//	unregister_chrdev_region(master.hosts[0]->devno, XC4IRC_DEV_COUNT);
	unregister_chrdev(XC4IRC_DEV_MAJOR, XC4IRC_DRV_NAME);

	//	kfree(host.rx_buf);
	for (i = 0; i < XC4IRC_DEV_COUNT; i++) {
		kfree(master.hosts[i]->rx_buf);
		kfree(master.hosts[i]);
	}
#ifdef CONFIG_PM
	xc_irda_exit();
#endif
}


module_init(xc4irc_init);
module_exit(xc4irc_exit);

MODULE_DESCRIPTION("Infra-red driver for XCode4 Viper");
MODULE_AUTHOR("Jason Miu, jmiu@vixs.com");
MODULE_LICENSE("GPL");
