/*
 * Support functions for ViXS XCODE6 GPIO
 *
 * Copyright (C) 2015 ViXS Systems, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.
 */

#include <linux/version.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/interrupt.h>
#include <linux/syscore_ops.h>
#include <linux/err.h>
#include <linux/clk.h>
#include <linux/io.h>
#include <linux/device.h>
#include <linux/pm_runtime.h>
#include <linux/pm.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <linux/irqdomain.h>
#include <linux/irqchip/chained_irq.h>
#include <linux/gpio.h>

#include "xc6regs.h"
#include "xcboot.h"
#include "xcerr.h"
#include "iia.h"

static int g_dbg_level = 3;  // 3 default to output error msg, 0 to disable all msg // 255 to enale all msg   // level larger than this will NOT output to /var/log/messages
module_param(g_dbg_level, int, 0644);
MODULE_PARM_DESC(g_dbg_level, "GPIO debug msg level. 3: default, output error msg; 0: disable all msg; 255: enable all msg.");

extern spinlock_t gpio_reg_lock;

enum {
    DBGLEVEL0       = 0,
    DBGLEVELERR     = 1,
    DBGLEVELWARN    = 2,
    DBGLEVELINFO    = 3,
    DBGLEVELDEBUG   = 4,
    DBGLEVELMAX     = 255
};

#define ALL_MSG "xc6_gpio, "

void print_debug(int level, char *fmt, ...);
void log_printf(int id, int level, char *fmt, ...);

#define PPC_INT_MASK_LOCK			XC_MIPS_INTERLOCK5
#define PPC_INT_MASK_LOCK_INDEX		5
#define PPC_INT_MASK_LOCK_GPIO_ID	6
static const uint32 mutex_masks[8] = {0x0000000F, 0x000000F0, 0x00000F00, 0x0000F000, 0x000F0000, 0x00F00000, 0x0F000000, 0xF0000000};
static const uint32 mutex_shifts[8] = {0, 4, 8, 12, 16, 20, 24, 28};

#define PERROR(format, args...)    print_debug(DBGLEVELERR, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PWARN(format, args...)     print_debug(DBGLEVELWARN, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PINFO(format, args...)     print_debug(DBGLEVELINFO, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PDEBUG(format, args...)    print_debug(DBGLEVELDEBUG, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PVERBOSE(format, args...)  print_debug(DBGLEVEL0, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)

#define mmr_reg_readl(dev,reg) readl(dev->base+reg)
#define mmr_reg_writel(dev,reg,data) writel(data,(dev->base+reg))

static struct platform_device *xc6_gpio_device[MAXXCODENUM] = {NULL};

#define XC6_GPIO_PINS 69
#define XC6_GPIO_GROUPS 9

struct xc6_gpio_pdata {
	unsigned int board_id;
	unsigned int m_irq;
	void __iomem *mp_mmr;
};

struct gpio_regs {
	u32 in;
	u32 out;
	u32 oe;
    u32 isr;
	u32 ctrl;
};

struct gpio_map {
    struct gpio_regs *regs;
    u32 group_pin;
    u32 mode_mask;
    u32 int_mask;
    bool with_int;
    bool dedicated;
};    

static struct gpio_regs xc6_gpio_regs[XC6_GPIO_GROUPS] = {
    {XC_GPIO_DEDICATED_IN,  XC_GPIO_DEDICATED_OUT,  XC_GPIO_DEDICATED_OUTEN, XC_PPC_INT_STATUS, XC_PPC_INT_MASK},
    {XC_GPIO_B_IN,          XC_GPIO_B_OUT,          XC_GPIO_B_OE,            0,   XC_GPIO_B_CTRL},
    {XC_GPIO_C_IN,          XC_GPIO_C_OUT,          XC_GPIO_C_OE,            0,   XC_GPIO_C_CTRL},
    {XC_GPIO_D_IN,          XC_GPIO_D_OUT,          XC_GPIO_D_OE,            0,   XC_GPIO_D_CTRL},
    {XC_GPIO_H_IN,          XC_GPIO_H_OUT,          XC_GPIO_H_OE,            0,   XC_GPIO_H_CTRL},
    {XC_GPIO_I_IN,          XC_GPIO_I_OUT,          XC_GPIO_I_OE,            0,   XC_GPIO_I_CTRL},
    {XC_GPIO_L_IN,          XC_GPIO_L_OUT,          XC_GPIO_L_OE,            0,   XC_GPIO_L_CTRL},
    {XC_GPIO_M_IN,          XC_GPIO_M_OUT,          XC_GPIO_M_OE,            0,   XC_GPIO_M_CTRL},
    {XC_GPIO_T_IN,          XC_GPIO_T_OUT,          XC_GPIO_T_OE,            0,   XC_GPIO_T_CTRL},
};

static struct gpio_map xc6_gpio_map[XC6_GPIO_PINS] = {
    {&xc6_gpio_regs[0],   0,  0,    XC_PPC_INT_MASK_INT_EN_GPIO_0_INT_MASK,     true,     true}, //dedicated
    {&xc6_gpio_regs[0],   1,  0,    XC_PPC_INT_MASK_INT_EN_GPIO_1_INT_MASK,     true,     true},
    {&xc6_gpio_regs[0],   2,  0,    XC_PPC_INT_MASK_INT_EN_GPIO_2_INT_MASK,     true,     true},
    {&xc6_gpio_regs[0],   3,  0,    XC_PPC_INT_MASK_INT_EN_GPIO_3_INT_MASK,     true,     true},
    {&xc6_gpio_regs[0],   4,  0,    XC_PPC_INT_MASK_INT_EN_GPIO_4_INT_MASK,     true,     true},
    {&xc6_gpio_regs[0],   5,  0,    0,     false,    true},
    {&xc6_gpio_regs[0],   6,  0,    0,     false,    true},
    {&xc6_gpio_regs[0],   7,  0,    0,     false,    true},
    {&xc6_gpio_regs[0],   8,  0,    0,     false,    true},
    {&xc6_gpio_regs[0],   9,  0,    0,     false,    true},
    {&xc6_gpio_regs[0],  10,  0,    0,     false,    true},
    {&xc6_gpio_regs[0],  11,  0,    0,     false,    true},
    {&xc6_gpio_regs[0],  12,  0,    0,     false,    true},
    {&xc6_gpio_regs[0],  13,  0,    0,     false,    true},
    {&xc6_gpio_regs[0],  14,  0,    0,     false,    true},
    {&xc6_gpio_regs[0],  15,  0,    0,     false,    true},
    {&xc6_gpio_regs[1],   0,  XC_GPIO_B_CTRL_GPIO_MODE_SEL_MASK,    XC_GPIO_B_CTRL_INT_MASK_MASK,     true,     false}, //GPIO_B
    {&xc6_gpio_regs[1],   1,  XC_GPIO_B_CTRL_GPIO_MODE_SEL_MASK,    0,     false,    false},
    {&xc6_gpio_regs[1],   2,  XC_GPIO_B_CTRL_GPIO_MODE_SEL_MASK,    0,     false,    false},
    {&xc6_gpio_regs[1],   3,  XC_GPIO_B_CTRL_GPIO_MODE_SEL_MASK,    0,     false,    false},
    {&xc6_gpio_regs[2],   0,  XC_GPIO_C_CTRL_GPIO_MODE_SEL_MASK,    XC_GPIO_C_CTRL_INT_MASK_MASK,     true,     false}, //GPIO_C
    {&xc6_gpio_regs[2],   1,  XC_GPIO_C_CTRL_GPIO_MODE_SEL_MASK,    0,     false,    false},
    {&xc6_gpio_regs[2],   2,  XC_GPIO_C_CTRL_GPIO_MODE_SEL_MASK,    0,     false,    false},
    {&xc6_gpio_regs[2],   3,  XC_GPIO_C_CTRL_GPIO_MODE_SEL_MASK,    0,     false,    false},
    {&xc6_gpio_regs[2],   4,  XC_GPIO_C_CTRL_GPIO_MODE_SEL_MASK,    0,     false,    false},
    {&xc6_gpio_regs[2],   5,  XC_GPIO_C_CTRL_GPIO_MODE_SEL_MASK,    0,     false,    false},
    {&xc6_gpio_regs[2],   6,  XC_GPIO_C_CTRL_GPIO_MODE_SEL_MASK,    0,     false,    false},
    {&xc6_gpio_regs[2],   7,  XC_GPIO_C_CTRL_GPIO_MODE_SEL_MASK,    0,     false,    false},
    {&xc6_gpio_regs[3],   0,  XC_GPIO_D_CTRL_GPIO_MODE_SEL0_MASK,    XC_GPIO_D_CTRL_INT_MASK0_MASK,     true,     false}, //GPIO_D
    {&xc6_gpio_regs[3],   1,  XC_GPIO_D_CTRL_GPIO_MODE_SEL0_MASK,    0,     false,    false},
    {&xc6_gpio_regs[3],   2,  XC_GPIO_D_CTRL_GPIO_MODE_SEL0_MASK,    0,     false,    false},
    {&xc6_gpio_regs[3],   3,  XC_GPIO_D_CTRL_GPIO_MODE_SEL1_MASK,    XC_GPIO_D_CTRL_INT_MASK1_MASK,     true,     false},
    {&xc6_gpio_regs[3],   4,  XC_GPIO_D_CTRL_GPIO_MODE_SEL1_MASK,    0,     false,    false},
    {&xc6_gpio_regs[3],   5,  XC_GPIO_D_CTRL_GPIO_MODE_SEL1_MASK,    0,     false,    false},
    {&xc6_gpio_regs[4],   0,  XC_GPIO_H_CTRL_GPIO_MODE_SEL0_MASK,    XC_GPIO_H_CTRL_INT_MASK0_MASK,     true,     false}, //GPIO_H
    {&xc6_gpio_regs[4],   1,  XC_GPIO_H_CTRL_GPIO_MODE_SEL0_MASK,    0,     false,    false},
    {&xc6_gpio_regs[4],   2,  XC_GPIO_H_CTRL_GPIO_MODE_SEL0_MASK,    0,     false,    false},
    {&xc6_gpio_regs[4],   3,  XC_GPIO_H_CTRL_GPIO_MODE_SEL0_MASK,    0,     false,    false},
    {&xc6_gpio_regs[4],   8,  XC_GPIO_H_CTRL_GPIO_MODE_SEL2_MASK,    XC_GPIO_H_CTRL_INT_MASK2_MASK,     true,     false},
    {&xc6_gpio_regs[4],   9,  XC_GPIO_H_CTRL_GPIO_MODE_SEL2_MASK,    0,     false,    false},
    {&xc6_gpio_regs[4],  10,  XC_GPIO_H_CTRL_GPIO_MODE_SEL2_MASK,    0,     false,    false},
    {&xc6_gpio_regs[4],  11,  XC_GPIO_H_CTRL_GPIO_MODE_SEL2_MASK,    0,     false,    false},
    {&xc6_gpio_regs[5],   0,  (1<<31),    XC_GPIO_I_CTRL_INT_MASK0_MASK,     true,     false}, //GPIO_I
    {&xc6_gpio_regs[5],   1,  (1<<31),    0,     false,    false},
    {&xc6_gpio_regs[5],   4,  (1<<29),    XC_GPIO_I_CTRL_INT_MASK2_MASK,     true,     false},
    {&xc6_gpio_regs[6],   0,  (1<<30),    XC_GPIO_L_CTRL_INT_MASK0_MASK,     true,     false}, //GPIO_L
    {&xc6_gpio_regs[6],   1,  (1<<30),    0,     false,    false},
    {&xc6_gpio_regs[6],   2,  (1<<30),    0,     false,    false},
    {&xc6_gpio_regs[6],   3,  (1<<30),    0,     false,    false},
    {&xc6_gpio_regs[6],   4,  (1<<30),    0,     false,    false},
    {&xc6_gpio_regs[6],   5,  (1<<31),    XC_GPIO_L_CTRL_INT_MASK2_MASK,     true,     false},
    {&xc6_gpio_regs[7],   0,  (1<<31),    (1<<7),     true,     false}, //GPIO_M
    {&xc6_gpio_regs[7],   1,  (1<<31),    0,     false,    false},
    {&xc6_gpio_regs[7],   2,  (1<<30),    (1<<6),     true,     false},
    {&xc6_gpio_regs[7],   3,  (1<<30),    0,     false,    false},
    {&xc6_gpio_regs[7],   4,  (1<<29),    (1<<5),     true,     false},
    {&xc6_gpio_regs[7],   5,  (1<<29),    0,     false,    false},
    {&xc6_gpio_regs[7],   6,  (1<<28),    (1<<4),     true,     false},
    {&xc6_gpio_regs[7],   7,  (1<<28),    0,     false,    false},
    {&xc6_gpio_regs[7],  12,  (1<<25),    0,     true,     false},
    {&xc6_gpio_regs[7],  13,  (1<<25),    0,     false,    false},
    {&xc6_gpio_regs[7],  14,  (1<<25),    (1<<1),     true,     false},
    {&xc6_gpio_regs[7],  15,  (1<<25),    0,     false,    false},
    {&xc6_gpio_regs[7],  16,  (1<<24),    0,     true,     false},
    {&xc6_gpio_regs[7],  17,  (1<<24),    0,     false,    false},
    {&xc6_gpio_regs[7],  18,  (1<<24),    (1<<0),     false,    false},
    {&xc6_gpio_regs[8],   0,  (1<<31),    (1<<0),     false,    false},
    {&xc6_gpio_regs[8],   2,  (1<<31),    (1<<0),     true,     false},
    {&xc6_gpio_regs[8],   3,  (1<<31),    0,     false,    false},
  
};

struct gpio_bank {
	void __iomem *base;
	u16 irq;
	struct irq_domain *domain;
	struct gpio_map *map;
	struct gpio_chip chip;
	struct device *dev;
	u32 width;
};


void print_debug(int level, char *fmt, ...)
{
    va_list ap ;
    char s[128];

    if (level > g_dbg_level) 
        return;
    
    va_start(ap, fmt);
    vsnprintf(s, sizeof(s), fmt, ap);
    printk(KERN_NOTICE  ALL_MSG"%s", s);
    va_end(ap);
}

static int xc6_gpio_to_irq(struct gpio_chip *chip, unsigned offset)
{
	struct gpio_bank *bank = container_of(chip, struct gpio_bank, chip);

	return irq_find_mapping(bank->domain, offset);
}


static void _set_gpio_direction(struct gpio_bank *bank, int offset, int is_output)
{
	void __iomem *reg = bank->base;
	u32 l;

	reg += bank->map[offset].regs->oe;
	l = readl(reg);
	if (is_output)
		l |= (1 << bank->map[offset].group_pin);
	else
        l &= ~(1 << bank->map[offset].group_pin);
	writel(l, reg);
}

static void _set_gpio_dataout(struct gpio_bank *bank, int offset, int enable)
{
	void __iomem *reg = bank->base + (bank->map[offset].regs->out);
	u32 gpio_bit = (1 << bank->map[offset].group_pin);
	u32 l;

	l = readl(reg);
	if (enable)
		l |= gpio_bit;
	else
		l &= ~gpio_bit;
	writel(l, reg);
}

static int _get_gpio_datain(struct gpio_bank *bank, int offset)
{
	void __iomem *reg = bank->base + (bank->map[offset].regs->in);

	return (readl(reg) & (1 << bank->map[offset].group_pin)) != 0;
}

static int _get_gpio_dataout(struct gpio_bank *bank, int offset)
{
	void __iomem *reg = bank->base + (bank->map[offset].regs->out);

	return (readl(reg) & (1 << bank->map[offset].group_pin)) != 0;
}

static int gpio_is_output(struct gpio_bank *bank, unsigned offset)
{
	void __iomem *reg = bank->base + (bank->map[offset].regs->oe);

	return readl(reg) & (1 << bank->map[offset].group_pin);
}

static inline void _clear_gpio_irqstatus(struct gpio_bank *bank, int offset)
{
	void __iomem *reg = bank->base + bank->map[offset].regs->isr;

	writel(bank->map[offset].int_mask, reg);
}

static int hw_interlock_lock(struct gpio_bank *bank, u32 reg, u32 idx, u32 owner_id)
{
	void __iomem *lock = (void *)((u32)bank->base + reg);
	u32 mask = mutex_masks[idx];
	owner_id <<= mutex_shifts[idx];
	owner_id &= mask;
	writel(owner_id, lock);
	if((readl(lock) & mask) == owner_id)
		return XCE_OK;
	else
		return XCE_NO_MORE;
}

static int hw_interlock_unlock(struct gpio_bank *bank, u32 reg, u32 idx, u32 owner_id)
{
	void __iomem *lock = (void *)((u32)bank->base + reg);
	u32 mask = mutex_masks[idx];
	owner_id <<= mutex_shifts[idx];
	owner_id &= mask;
	writel(owner_id, lock);
	if((readl(lock) & mask) == 0)
		return XCE_OK;

	PERROR("owner id 0x%x lock id 0x%x\n", owner_id, readl(lock));	
	return XCE_TRAP;
}

static inline void _set_gpio_irqenable(struct gpio_bank *bank, int offset, int enable)
{
	void __iomem *reg = bank->base + bank->map[offset].regs->ctrl;
	u32 l;
	u32 lock_idx = PPC_INT_MASK_LOCK_GPIO_ID + smp_processor_id();
	if (bank->map[offset].with_int) {
		while(hw_interlock_lock(bank, PPC_INT_MASK_LOCK, PPC_INT_MASK_LOCK_INDEX, lock_idx) != XCE_OK);
		l = readl(reg);
		if (enable)
		{
			l |= bank->map[offset].int_mask;
		}
		else
		{
			l &= ~(bank->map[offset].int_mask);
		}
		writel(l, reg);
		hw_interlock_unlock(bank, PPC_INT_MASK_LOCK, PPC_INT_MASK_LOCK_INDEX, lock_idx);
	}
}

static int xc6_gpio_request(struct gpio_chip *chip, unsigned offset)
{
	struct gpio_bank *bank = container_of(chip, struct gpio_bank, chip);
	unsigned long flags;
    void __iomem *reg = bank->base;

    if (bank->map[offset].dedicated)
        return 0;

	spin_lock_irqsave(&gpio_reg_lock, flags);

    reg += bank->map[offset].regs->ctrl;
    writel(readl(reg) | bank->map[offset].mode_mask, reg);

	spin_unlock_irqrestore(&gpio_reg_lock, flags);

	return 0;
}

static void xc6_gpio_free(struct gpio_chip *chip, unsigned offset)
{
#if 0
	struct gpio_bank *bank = container_of(chip, struct gpio_bank, chip);
	void __iomem *reg = bank->base;
	unsigned long flags;

    if (bank->map[offset].dedicated)
        return;

	spin_lock_irqsave(&gpio_reg_lock, flags);

    reg += bank->map[offset].regs->ctrl;
    writel(readl(reg) & ~(bank->map[offset].mode_mask), reg);

	spin_unlock_irqrestore(&gpio_reg_lock, flags);
#endif

	return;
}

static irqreturn_t xc6_gpio_irq_handler(int irq, void *dev_id)
{
	void __iomem *reg = NULL;
	struct gpio_bank *bank = dev_id;
	irqreturn_t ret = IRQ_NONE;
	u32 isr;
    int i;

    PDEBUG("Enter\n");

    for (i = 0; i < XC6_GPIO_PINS; i++)
    {
        if (bank->map[i].dedicated && bank->map[i].with_int) //non dedicated gpio int not supported yet
        {
            reg = bank->base + bank->map[i].regs->isr;
            isr = readl(reg) & bank->map[i].int_mask;
            PDEBUG("reg: %x isr: %x\n", reg, isr);
            if (isr)
            {
                PDEBUG("GPIO %d interrupt handled\n", i);
                _clear_gpio_irqstatus(bank, i);
                generic_handle_irq(irq_find_mapping(bank->domain, i));
                ret = IRQ_HANDLED;
            }
        }
    }
    
    PDEBUG("Exit\n");

    return ret;
}

static int _set_gpio_triggering(struct gpio_bank *bank, int offset,
							unsigned trigger)
{
	void __iomem *reg = bank->base + bank->map[offset].regs->oe;
	u32 l = 0;

	l = readl(reg);
	if ((trigger & IRQ_TYPE_EDGE_RISING) || (trigger & IRQ_TYPE_EDGE_FALLING))
	{
		l |= XC_GPIO_DEDICATED_OUTEN_GPIO_INT_EDGE_LVL_MASK; //1:edge 0:level triggered interrupt
	}
	else if(trigger & IRQ_TYPE_LEVEL_LOW)
	{
		l &= ~XC_GPIO_DEDICATED_OUTEN_GPIO_INT_EDGE_LVL_MASK;
		l &= ~XC_GPIO_DEDICATED_OUTEN_GPIO_INT_POLARITY_MASK; //0:lo 1:hi
	}
     else //IRQ_TYPE_LEVEL_HIGH
     {
         l &= ~XC_GPIO_DEDICATED_OUTEN_GPIO_INT_EDGE_LVL_MASK;
		l |= XC_GPIO_DEDICATED_OUTEN_GPIO_INT_POLARITY_MASK; //0:lo 1:hi
     }
	writel(l, reg);

	return 0;
}

static int xc6_gpio_irq_type(struct irq_data *d, unsigned type)
{
	struct gpio_bank *bank = irq_data_get_irq_chip_data(d);
	int retval = 0;
	unsigned long flags;

	if (type & ~IRQ_TYPE_SENSE_MASK)
		return -EINVAL;

	if (bank->map[d->hwirq].dedicated)
	{
    	spin_lock_irqsave(&gpio_reg_lock, flags);
    	retval = _set_gpio_triggering(bank, d->hwirq, type);
    	spin_unlock_irqrestore(&gpio_reg_lock, flags);

    	if (type & (IRQ_TYPE_LEVEL_LOW | IRQ_TYPE_LEVEL_HIGH))
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 0, 0)
    		__irq_set_handler_locked(d->irq, handle_level_irq);
#else
    		irq_set_handler_locked(d, handle_level_irq);
#endif
    	else if (type & (IRQ_TYPE_EDGE_FALLING | IRQ_TYPE_EDGE_RISING))
#if LINUX_VERSION_CODE < KERNEL_VERSION(4, 0, 0)
    		__irq_set_handler_locked(d->irq, handle_edge_irq);
#else
    		irq_set_handler_locked(d, handle_edge_irq);
#endif
	}

	return retval;
}

static void xc6_gpio_ack_irq(struct irq_data *d)
{
	struct gpio_bank *bank = irq_data_get_irq_chip_data(d);

	_clear_gpio_irqstatus(bank, d->hwirq);
}

static void xc6_gpio_mask_irq(struct irq_data *d)
{
	struct gpio_bank *bank = irq_data_get_irq_chip_data(d);
	unsigned long flags;

	spin_lock_irqsave(&gpio_reg_lock, flags);
	_set_gpio_irqenable(bank, d->hwirq, 0);
	spin_unlock_irqrestore(&gpio_reg_lock, flags);
}

static void xc6_gpio_unmask_irq(struct irq_data *d)
{
	struct gpio_bank *bank = irq_data_get_irq_chip_data(d);
	unsigned long flags;

	spin_lock_irqsave(&gpio_reg_lock, flags);
	_set_gpio_irqenable(bank, d->hwirq, 0);
	_clear_gpio_irqstatus(bank, d->hwirq);
	_set_gpio_irqenable(bank, d->hwirq, 1);
	spin_unlock_irqrestore(&gpio_reg_lock, flags);
}

static struct irq_chip gpio_irq_chip = {
	.name		= "XC6GPIO",
	.irq_ack	= xc6_gpio_ack_irq,
	.irq_mask	= xc6_gpio_mask_irq,
	.irq_unmask	= xc6_gpio_unmask_irq,
	.irq_set_type	= xc6_gpio_irq_type,
};

static int xc6_gpio_input(struct gpio_chip *chip, unsigned offset)
{
	struct gpio_bank *bank;
	unsigned long flags;

	bank = container_of(chip, struct gpio_bank, chip);
	spin_lock_irqsave(&gpio_reg_lock, flags);
	_set_gpio_direction(bank, offset, 0);
	spin_unlock_irqrestore(&gpio_reg_lock, flags);
	return 0;
}

static int xc6_gpio_get(struct gpio_chip *chip, unsigned offset)
{
	struct gpio_bank *bank;

	bank = container_of(chip, struct gpio_bank, chip);

	if (gpio_is_output(bank, offset))
		return _get_gpio_dataout(bank, offset);
	else
		return _get_gpio_datain(bank, offset);
}

static int xc6_gpio_output(struct gpio_chip *chip, unsigned offset, int value)
{
	struct gpio_bank *bank;
	unsigned long flags;

	bank = container_of(chip, struct gpio_bank, chip);
	spin_lock_irqsave(&gpio_reg_lock, flags);
	_set_gpio_dataout(bank, offset, value);
	_set_gpio_direction(bank, offset, 1);
	spin_unlock_irqrestore(&gpio_reg_lock, flags);
	return 0;
}

static void xc6_gpio_set(struct gpio_chip *chip, unsigned offset, int value)
{
	struct gpio_bank *bank;
	unsigned long flags;

	bank = container_of(chip, struct gpio_bank, chip);
	spin_lock_irqsave(&gpio_reg_lock, flags);
	_set_gpio_dataout(bank, offset, value);
	spin_unlock_irqrestore(&gpio_reg_lock, flags);
}

/* This lock class tells lockdep that GPIO irqs are in a different
 * category than their parents, so it won't report false recursion.
 */
static struct lock_class_key gpio_lock_class;

static void xc6_gpio_chip_init(struct gpio_bank *bank)
{
	bank->chip.request = xc6_gpio_request;
	bank->chip.free = xc6_gpio_free;
	bank->chip.direction_input = xc6_gpio_input;
	bank->chip.get = xc6_gpio_get;
	bank->chip.direction_output = xc6_gpio_output;
	bank->chip.set = xc6_gpio_set;
	bank->chip.to_irq = xc6_gpio_to_irq;
	bank->chip.label = "xc6gpio";
	bank->chip.ngpio = bank->width;
}

static int xc6_gpio_install_irq(struct platform_device *pdev)
{
	struct gpio_bank *bank = platform_get_drvdata(pdev);
    int ret;

    ret = request_irq(bank->irq, xc6_gpio_irq_handler, IRQF_SHARED, pdev->name, (void *)bank);
    if (ret) {
        PERROR("request_irq failed\n");
        return ret;
    }
    
    #ifndef XC_SOC_BUILD
        /* enable PPC IIA interrupt */
        IIAHostSetMask(bank->base, IIA_PPC_INT);
    #else
        ret = request_irq(XCODE6_IRQ_PROC5, xc6_gpio_irq_handler, IRQF_SHARED, pdev->name, (void *)bank);
        if (ret) {
            PERROR("request_irq failed\n");
            return ret;
        }
    #endif

    return 0;
}

static int xc6_gpio_remove_irq(struct platform_device *pdev)
{
	struct gpio_bank *bank = platform_get_drvdata(pdev);

    free_irq(bank->irq, (void *)bank);

    #ifndef XC_SOC_BUILD
        /* disable PPC IIA interrupt */
        IIAHostClearMask(bank->base, IIA_PPC_INT);
    #else
        free_irq(XCODE6_IRQ_PROC5, (void *)bank);
    #endif
    
    return 0;
}

static int xc6_gpio_probe(struct platform_device *pdev)
{
	struct device *dev = &pdev->dev;
	struct device_node *node = dev->of_node;
	struct gpio_bank *bank;
    struct xc6_gpio_pdata *pdata = (struct xc6_gpio_pdata*)pdev->dev.platform_data;
	int irq;
    int i;
    int ret;

	bank = devm_kzalloc(dev, sizeof(struct gpio_bank), GFP_KERNEL);
	if (!bank) {
		PERROR("Memory alloc failed\n");
		return -ENOMEM;
	} 

    bank->map = xc6_gpio_map;
	bank->irq = pdata->m_irq;
    bank->base = pdata->mp_mmr;
	bank->dev = dev;
 	bank->width = XC6_GPIO_PINS;
	bank->domain = irq_domain_add_linear(node, bank->width,
					     &irq_domain_simple_ops, NULL);
	if (!bank->domain) {
		PERROR("Couldn't register an IRQ domain\n");
		return -ENODEV;
	}

	platform_set_drvdata(pdev, bank);

	xc6_gpio_chip_init(bank);
	bank->chip.base = pdata->board_id * 1000;
    
	ret = gpiochip_add(&bank->chip);
    if (ret) {
        PERROR("gpiochip_add failed\n");
        return ret;
    }

	for (i = 0; i < bank->width; i++) {
        if (bank->map[i].dedicated && bank->map[i].with_int) //non dedicated gpio int not supported yet
        {
    		irq = irq_create_mapping(bank->domain, i);
            PDEBUG("irq_create_mapping: %d -> %d\n", i, irq);
    		irq_set_lockdep_class(irq, &gpio_lock_class);
    		irq_set_chip_data(irq, bank);
    		irq_set_chip_and_handler(irq, &gpio_irq_chip,
    						 handle_simple_irq);
    		irq_modify_status(irq, IRQ_NOREQUEST | IRQ_NOAUTOEN, IRQ_NOPROBE);
        }
	}
    
    xc6_gpio_install_irq(pdev);

	return 0;
}

static int xc6_gpio_remove(struct platform_device *pdev)
{
	struct gpio_bank *bank = platform_get_drvdata(pdev);
    int error;
    int i;

    xc6_gpio_remove_irq(pdev);
    
    for (i = 0; i < bank->width; i++) {
        if (bank->map[i].dedicated && bank->map[i].with_int) //non dedicated gpio int not supported yet
        {
            irq_dispose_mapping(irq_find_mapping(bank->domain, i));
        }
    }

#if LINUX_VERSION_CODE < KERNEL_VERSION(3, 18, 0)
    error = gpiochip_remove(&bank->chip);
    if (error)
    {
        PERROR("gpiochip_remove failed\n");
        return error;
    }
#else
    /* funtion returns void as of 3.18 linux kernel */
    gpiochip_remove(&bank->chip);
#endif

    irq_domain_remove(bank->domain);
    devm_kfree(&pdev->dev, (void *)platform_get_drvdata(pdev));

	return 0;
}

#ifdef CONFIG_PM
static int xc6_gpio_suspend(struct platform_device *pdev, pm_message_t state)
{
	printk("xc6_gpio_suspend\n");
    xc6_gpio_remove_irq(pdev);

	return 0;
}

static int xc6_gpio_resume(struct platform_device *pdev)
{
	printk("xc6_gpio_resume\n");
    xc6_gpio_install_irq(pdev);

	return 0;
}
#endif

static struct platform_driver xc6_gpio_driver = {
	.probe		= xc6_gpio_probe,
    .remove     = xc6_gpio_remove,
	.driver		= {
		.name	= "xc6_gpio",
	},
	#ifdef CONFIG_PM
	.suspend    = xc6_gpio_suspend,
	.resume     = xc6_gpio_resume,
	#endif
};

static int __init xc6_gpio_init(void)
{
    struct platform_device *pDevice;
	struct xc6_gpio_pdata spi_pdata;
    s_xc_device info;
    int i;
    int error;
    
    for (i = 0; i < MAXXCODENUM; i++)
    {
        if (get_xc_pcie_device_info(i, &info) == 0)
        {
            PDEBUG("found xc device %d ok\n", i);

			spi_pdata.board_id = i;
			spi_pdata.m_irq = info.m_irq;
			spi_pdata.mp_mmr = info.mp_mmr;
			
            pDevice = platform_device_alloc("xc6_gpio", i);;

            if (!pDevice) 
            {
                PERROR("platform_device_alloc failed\n");
                return (-ENOMEM);
            }

			error = platform_device_add_data(pDevice, &spi_pdata, sizeof(spi_pdata));
			if (error)
			{
				PERROR("platform_device_add_data failed\n");
				goto err_free_device;
			}

            PDEBUG(" ->platform_device_add\n");

            error = platform_device_add(pDevice);
            if (error)
            {
                PERROR("platform_device_add failed\n");
                goto err_free_device;
            }
            
            xc6_gpio_device[i] = pDevice;
        }
    }
    
	return platform_driver_register(&xc6_gpio_driver);

err_free_device:
    platform_device_put(pDevice);
    return error;
}
module_init(xc6_gpio_init);

static void __exit xc6_gpio_exit(void)
{
    int i;

    PDEBUG("platform_driver_unregister\n");
	platform_driver_unregister(&xc6_gpio_driver);

    for (i = 0; i < MAXXCODENUM; i++)
    {
        if (xc6_gpio_device[i] != NULL)
        {
            PDEBUG("platform_device_unregister\n");
            platform_device_unregister(xc6_gpio_device[i]);
        }
        else
            break;
    }
}
module_exit(xc6_gpio_exit);

MODULE_AUTHOR("Zhigang Luo <zluo@vixs.com>");
MODULE_DESCRIPTION("ViXS XCODE6 GPIO");
MODULE_LICENSE("GPL");

