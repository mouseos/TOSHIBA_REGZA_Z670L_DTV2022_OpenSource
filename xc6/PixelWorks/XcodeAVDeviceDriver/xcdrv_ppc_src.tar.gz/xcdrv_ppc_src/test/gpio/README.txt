1. GPIO mapping

GPIO_#      PIN_#   
0           GPIO_DEDICATED[0]
1           GPIO_DEDICATED[1]
2           GPIO_DEDICATED[2]
3           GPIO_DEDICATED[3]
4           GPIO_DEDICATED[4]
5           GPIO_DEDICATED[5]
6           GPIO_DEDICATED[6]
7           GPIO_DEDICATED[7]
8           GPIO_DEDICATED[8]
9           GPIO_DEDICATED[9]
10          GPIO_DEDICATED[10]
11          GPIO_DEDICATED[11]
12          GPIO_DEDICATED[12]
13          GPIO_DEDICATED[13]
14          GPIO_DEDICATED[14]
15          GPIO_DEDICATED[15]
16          GPIO_B[0]
17          GPIO_B[1]
18          GPIO_B[2]
19          GPIO_B[3]
20          GPIO_C[0]
21          GPIO_C[1]
22          GPIO_C[2]
23          GPIO_C[3]
24          GPIO_C[4]
25          GPIO_C[5]
26          GPIO_C[6]
27          GPIO_C[7]
28          GPIO_D[0]
29          GPIO_D[1]
30          GPIO_D[2]
31          GPIO_D[3]
32          GPIO_D[4]
33          GPIO_D[5]
34          GPIO_H[0]
35          GPIO_H[1]
36          GPIO_H[2]
37          GPIO_H[3]
38          GPIO_H[8]
39          GPIO_H[9]
40          GPIO_H[10]
41          GPIO_H[11]
42          GPIO_I[0]
43          GPIO_I[1]
44          GPIO_I[4]
45          GPIO_L[0]
46          GPIO_L[1]
47          GPIO_L[2]
48          GPIO_L[3]
49          GPIO_L[4]
50          GPIO_L[5]
51          GPIO_M[0]
52          GPIO_M[1]
53          GPIO_M[2]
54          GPIO_M[3]
55          GPIO_M[4]
56          GPIO_M[5]
57          GPIO_M[6]
58          GPIO_M[7]
59          GPIO_M[12]
60          GPIO_M[13]
61          GPIO_M[14]
62          GPIO_M[15]
63          GPIO_M[16]
64          GPIO_M[17]
65          GPIO_M[18]
66          GPIO_T[0]
67          GPIO_T[2]
68          GPIO_T[3]

2. GPIO Userspace Interface(See sysfs.txt for detail info)
All the GPIO interfaces are based in /sys/class/gpio/.
2.1 Request/Release
You first have to request a GPIO. So if we wanted to request GPIO 23, we would do:

root:/> echo 23 > /sys/class/gpio/export

If this process was successful, you would end up with a /sys/class/gpio/gpio23/ directory.
Then when we were done with it, we would release it by doing:

root:/> echo 23 > /sys/class/gpio/unexport

IMPORTANT: Please release all requested GPIO before unloading GPIO driver.

2.2 Reading/Writing
In the specific GPIO directory, there will be two files: direction and value. Reading from them returns the current state (direction / value) as you might expect. Writing to them sets the current state.

Possible commands for direction:

high: Set GPIO to an output with a starting value of 1
low: Set GPIO to an output with a starting value of 0
out: Same as low
in: Set GPIO to an input

The value field simply uses numeric values, so 0 or 1.

Examples

To set GPIO 23 to an input:

root:/> echo in > /sys/class/gpio/gpio23/direction

To set GPIO 23 to a high output:

root:/> echo high > /sys/class/gpio/gpio23/direction

To set GPIO 23's value to 0:

root:/> echo 0 > /sys/class/gpio/gpio23/value

To read GPIO 23's current value:

root:/> cat /sys/class/gpio/gpio23/value
0

2.3 Interrupt
See gpio-int.c for reference usage.
