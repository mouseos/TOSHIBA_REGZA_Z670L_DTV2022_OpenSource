/**********************************************************************************
* Filename: vixstypes.h
*
*  ViXS Systems Inc. Prioprietary and Confidential
**********************************************************************************/
#ifndef __VIXSTYPES_H__FE3BABCA_79A1_4EED_901F_53A41D8C4F3D__
#define __VIXSTYPES_H__FE3BABCA_79A1_4EED_901F_53A41D8C4F3D__

#include <linux/types.h>

// Our base data types are defined in following flatform dependent files
// The data types are:
//  int8    - 8-bit integer
//  uint8   - 8-bit unsigned integer
//  int16   - 16-bit integer
//  uint16  - 16-bit unsigned integer
//  int32   - 32-bit integer
//  uint32  - 32-bit unsigned integer
//  int64   - 64-bit integer
//  uint64  - 64-bit unsigned integer
//  pint8   - pointer to 8-bit integer
//  puint8  - pointer to 8-bit unsigned integer
//  pint16  - pointer to 16-bit integer
//  puint16 - pointer to 16-bit unsigned integer
//  pint32  - pointer to 32-bit integer
//  puint32 - pointer to 32-bit unsigned integer
//  pint64  - pointer to 64-bit integer
//  puint64 - pointer to 64-bit unsigned integer
//
//  uint    - unsigned integer (flatform native)
//  puint   - pointer to unsigned integer (flatform native)
//  pint    - pointer to signed integer
//
//  pvoid   - pointer to void
//

typedef signed char         int8, *pint8;
typedef signed short        int16, *pint16;
typedef signed int         int32, *pint32;
typedef signed long long    int64, *pint64;

typedef unsigned char       uint8, *puint8;
typedef unsigned short      uint16, *puint16;
typedef unsigned int       uint32, *puint32;
typedef unsigned long long  uint64, *puint64;

typedef void    *pvoid;

typedef unsigned long       *pulong; // this is 64bit on 64bit Linux, and 32bit on 32bit Linux

#ifdef ARC_FIRMWARE
#define UCV     _Uncached volatile
#define UC      _Uncached
#else
#define UCV     volatile
#define UC
#endif

#define gcc_packed  __attribute__((packed))


#ifndef NULL
#define NULL    ((void*)0)
#endif

#endif // __VIXSTYPES_H__FE3BABCA_79A1_4EED_901F_53A41D8C4F3D__

