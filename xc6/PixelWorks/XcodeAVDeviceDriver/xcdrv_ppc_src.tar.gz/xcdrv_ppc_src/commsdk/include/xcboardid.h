
/********************************************************************************** 
*
* Filename: xcboardid.h
* 
* ViXS Systems Confidential and Prioprietary 
*
**********************************************************************************/

/**********************************************************************
 * Copyright (c) 2002-2004 VIXS Systems Inc. All rights reserved.
 *
 * ViXS Confidential material not for non-NDA distribution
 *
 **********************************************************************/
#ifndef __XCBOARDID_H__
#define __XCBOARDID_H__

//
// XCodeIV-EAGLE boards
//

/*Tesla*/
#define BID_TESLA_0000    0x00000010  


/*Viper*/
#define BID_VIPER_00FF    0x000000ff  /* VIPER_533K4B_FULLSPEED */
#define BID_VIPER_00FE    0x000000fe  /* VIPER_513K4B_FULLSPEED */
#define BID_VIPER_00FD    0x000000fd  /* VIPER_486K4B_FULLSPEED */
#define BID_VIPER_00FC    0x000000fc  /* VIPER_405K4B_SLOWSPEED*/
#define BID_VIPER_00FB    0x000000fb  /* VIPER_486ELP_FULLSPEED */
#define BID_VIPER_00FA    0x000000fa  /* VIPER_533ELP_FULLSPEED */
#define BID_VIPER_00F9    0x000000f9  /* VIPER_405ELP_SLOWSPEED */
#define BID_VIPER_00F8    0x000000f8  /* VIPER_432ELP_FULLSPEED*/
#define BID_VIPER_00F7    0x000000f7  /* VIPER_513ELP_SLOWSPEED */
#define BID_VIPER_00F6    0x000000f6  /* VIPER_513ELP_FULLSPEED */

/*Viper SOC*/
#define BID_VIPER_1101    0x00001101  /* XC42xx_K4B2G1646C-HCH9_2x2x16 */
#define BID_VIPER_1102    0x00001102  /* XC42xx_Ch0x2x16_K4B2G1646B_HCH9_Ch1x2x16_K4B1G1646E_HCH9 */
#define BID_VIPER_1103    0x00001103
#define BID_VIPER_1104    0x00001104
#define BID_VIPER_1105    0x00001105
#define BID_VIPER_1106    0x00001106
#define BID_VIPER_1701    0x00001701  /* XC42xx_Ch0x2x16_K4B2G1646B_HCH9_Ch1x2x16_K4B1G1646E_HCH9 */

/* Eagle FPGA */
#define BID_EAGLE_00F1    0x000000f1  /* standalone, ddr2 mem, ddr3 sequencer */
#define BID_EAGLE_00F2    0x000000f2  /* stack, ddr2 mem, ddr3 sequencer */
#define BID_EAGLE_00F3    0x000000f3  /* standalone ddr3 mem */
#define BID_EAGLE_00F4    0x000000f4  /* stack ddr3 mem */
/* XC4115 */
#define BID_EAGLE_0081    0x00000081  /* xc4115, 432MHz full speed memory */
#define BID_EAGLE_0082    0x00000082  /* xc4115, 486MHz full speed memory */
#define BID_EAGLE_0083    0x00000083  /* xc4115, 513MHz full speed memory */
#define BID_EAGLE_0085    0x00000085  /* xc4115 v2 board, 486MHz full speed */
#define BID_EAGLE_0087    0x00000087  /* xc4115 rev2 board, 486MHz, 512MB for firmware*/
#define BID_EAGLE_0088    0x00000088  /* xc4115 rev2, 3ddr, 256MB for firmware*/
#define BID_EAGLE_008f    0x0000008f  /* xc4115, 432MHz full speed memory */
#define BID_EAGLE_2282    0x00002282  /* xc4115 */
#define BID_EAGLE_2286    0x00002286  /* xc4115 USB */
#define BID_EAGLE_2283    0x00002283  /* xc4111 PCI */
#define BID_EAGLE_2284    0x00002284  /* xc4111 */
#define BID_EAGLE_2285    0x00002285  /* xc4111 USB */
#define BID_EAGLE_2581    0x00002581  /* xc4115 */
/* XC4105 */
#define BID_EAGLE_0001    0x00000001  /* xc4105, 486MHz full speed memory */
#define BID_EAGLE_0002    0x00000002  /* xc4105, 513MHz power save */
#define BID_EAGLE_0003    0x00000003  /* xc4105, 486MHz low power */
#define BID_EAGLE_0004    0x00000004  /* xc4105, 486MHz full speed */
#define BID_EAGLE_000D    0x0000000d  /* USB dongle, 486MHz memory, 256MB FB */
#define BID_EAGLE_000E    0x0000000e  /* USB dongle, 486MHz memory, 128MB FB */
#define BID_EAGLE_0011    0x00000011  /* USB dongle, 256MB ddr * 1                    */
#define BID_EAGLE_1301    0x00001301  /* xc4105 */
#define BID_EAGLE_1F01    0x00001f01  /* xc4105 */
#define BID_EAGLE_1F02    0x00001f02  /* xc4105 */
#define BID_EAGLE_2001    0x00002001  /* xc4105 */
#define BID_EAGLE_2002    0x00002002  /* xc4105 */
#define BID_EAGLE_2003    0x00002003  /* xc4105 */
#define BID_EAGLE_2004    0x00002004  /* xc4105 */
#define BID_EAGLE_2302    0x00002302  /* xc4105 */
#define BID_EAGLE_2303    0x00002303  /* xc4105 */
/* SOC */
#define BID_EAGLE_000A    0x0000000a  /* SOC xc4105 */
#define BID_EAGLE_000B    0x0000000b  /* USB dongle, 256MB */
#define BID_EAGLE_000C    0x0000000c  /* USB dongle, 128MB */
#define BID_EAGLE_0010    0x00000010  /* USB dongle, 256MB ddr * 1    */
#define BID_EAGLE_0084    0x00000084  /* SOC xc4115 */
#define BID_EAGLE_0086    0x00000086  /* SOC xc4115 boot from PCI */
#define BID_EAGLE_2101    0x00002101  /* SOC xc4105 */
#define BID_EAGLE_2301    0x00002301  /* SOC xc4105 */
#define BID_EAGLE_2304    0x00002304  /* SOC xc4105 */
#define BID_EAGLE_2481    0x00002481
#define BID_EAGLE_2482    0x00002482  /* SOC xc4115 */
#define BID_EAGLE_2483    0x00002483  /* SOC xc4111 */
#define BID_EAGLE_1D81    0x00001d81
#define BID_EAGLE_1D82    0x00001d82  /* SOC xc4115 */

//
// SSDID's
//
#define SSDID_2010      0x2010
#define SSDID_2011      0x2011
#define SSDID_2012      0x2012
#define SSDID_2013      0x2013
#define SSDID_2014      0x2014
#define SSDID_2015      0x2015


//
// SSVID's
//
#define SSVID_1745      0x1745
#define SSVID_10DE      0x10DE

//
// CHIPID's
//
#define SPYDERASICID    0x00000000
#define MINIASICID      0x01000000
#define CAMINOASICID    0x03000000
#define CHIPIDMASK      0x03FF0000

#endif

