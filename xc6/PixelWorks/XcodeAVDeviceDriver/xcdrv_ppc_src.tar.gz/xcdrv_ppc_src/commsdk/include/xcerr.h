/*******************************************************************
* Filename: xcerr.h
*  ViXS Systems Inc. Prioprietary and Confidential
********************************************************************/
#ifndef __XCERR_H__5FA901AE_F23E_4F89_9C02_3F9224A4F84A__
#define __XCERR_H__5FA901AE_F23E_4F89_9C02_3F9224A4F84A__


#define XCE_OK              0       // OK/Succeded/Completed
#define XCE_PROCESSING      (-1000)    // Request accepted and is being processed

#define XCE_UNKNOWN         (-1001)    // Failed due to unknown error
#define XCE_INIT            (-1002)    // Failed due to firmware not being initialized
#define XCE_NO_SUPPORT      (-1003)    // Not supported
                                    // (Usually means for a feature/command/request
                                    // that by design can be selectively supported upon
                                    // implementation, the target object does not support
                                    // it.)
#define XCE_NO_ACCESS       (-1004)    // Permission to access this feature/obejct is denied
                                    // (Not enabled in current configuration)

#define XCE_FATAL           (-1010)   // Fatal error (HW stall, processor exception, etc.)
#define XCE_TRAP            (-1011)   // Caught unexpected event/values/cases in a debug setup
#define XCE_IO              (-1012)   // HW operation ended up in an error status

#define XCE_OTP_NVM_LOCKED  (-1015)   // OTP NVM RD/WR block locked

#define XCE_ILLEGAL         (-1020)   // Illegal operation
                                    // (e.g. releasing memroy with incorrect address,
                                    // committing read/write for already committed items,
                                    // etc.)
#define XCE_INVAL_COMMAND   (-1021)   // Invalid/undefined command
#define XCE_INVAL_HANDLE    (-1022)   // Handle or address is not of an existing object
#define XCE_INVAL_PARAM     (-1023)   // Invalid parameter(s)
#define XCE_INVAL_FORMAT    (-1024)   // Invalid or unsupported media type/format
#define XCE_INVAL_BUFFER    (-1025)   // Invalid or unsupported buffer type

#define XCE_WRONG_MEM_CONF  (-1029)   // wrong memory configuration
#define XCE_NO_MEM          (-1030)   // A pool has run out of free space
#define XCE_FRAGMENT        (-1031)   // Although there might be free areas allocation failed
                                    // due to fragmentation
#define XCE_FULL            (-1032)   // Object (buffer, etc.) is full
#define XCE_EMPTY           (-1033)   // Object (buffer, etc.) is empty
#define XCE_NOT_EMPTY       (-1034)   // Object (buffer, etc.) is not empty
#define XCE_TOO_MANY        (-1035)   // Request denied due to too many pending requests,
                                    // or resource use would exceed limit
#define XCE_NO_MORE         (-1036)   // Requested resource is exhausted
#define XCE_WRONG_STATE     (-1037)   // Request not accepted in current state
#define XCE_TIMEOUT         (-1038)   // Operation cancelled due to expiration
                                    // of a pre-determined time period
#define XCE_CANCELLED       (-1039)   // Operation cancelled as requested
#define XCE_IN_USE          (-1040)   // Resource is in use and can not be returned forcedly
#define XCE_EXIST           (-1041)   // Object to add/create already exists
#define XCE_NO_EXIST        (-1042)   // Object to delete/free doesn't exist

#define XCE_WRONG_SEQ       (-1043)   // wrong sequence
#define XCE_NOT_AVAILABLE   (-1044)   // information is not available for querying

#endif //__XCERR_H__5FA901AE_F23E_4F89_9C02_3F9224A4F84A__
