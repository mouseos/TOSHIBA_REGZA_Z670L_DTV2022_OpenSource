XC6 platform peripheral component driver readme

1. XC6 platform peripheral component driver includes below components:

xc_gpio: gpio driver - to control gpio pins
xc_i2c: i2c bus driver - to control i2c device 
xc_spi0: spi driver - to control device connected to spi0 bus
xc_spi1: spi driver - to control device connected to spi1/2/3/4 bus

2. To compile drivers

Ensure cross-compiler and toolchain are installed on PC linux
2.1 Build Linux kernel
Extract Linux source code to /root/
# tar -xjvf Software/linux/src/linux-linaro-3.x-src-<version>.tar.bz2 -C /root/
# cd /root/linux-linaro-3.x/
# make xcode68xx_defconfig
# make
2.2 Compile drivers
# export KERNELDIR=/root/linux-linaro-3.x
# cd /your/working/folder
# tar zxf /any/where/xcdrv_ppc_src.tar.gz
# cd xcdrv_ppc_src
# make

3. More information regarding gpio/i2c/spi usage

3.1 gpio

file xcdrv_ppc_src/test/gpio/readme.txt provide detailed GPIO pin mapping
file xcdrv_ppc_src/test/gpio/gpio-int.c provide sample how to poll gpio pin
interrupt. 

3.2 i2c

file  xcdrv_ppc_src/test/i2c/dev-interface provide detailed information of i2c
ioctl, this is from standard Linux kernel i2c interface doc

3.3 spi

file xcdrv_ppc_src/test/spi/spi-summary and spidev provide detailed information on how
to use spi as bus driver and use spi as general read/write/ioctl interface

