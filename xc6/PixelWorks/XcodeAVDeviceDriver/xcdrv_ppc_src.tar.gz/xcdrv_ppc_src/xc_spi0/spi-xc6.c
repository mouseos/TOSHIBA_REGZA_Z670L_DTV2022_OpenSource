/*
 * xc6_spi.c - SPI master driver for ViXS System SPI master
 *
 * Copyright (C) 2015 ViXS Systems, Inc.
 *
 * Based on viper xcode_spi.c
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <linux/module.h>
#include <linux/init.h>
#include <linux/syscore_ops.h>
#include <linux/errno.h>
#include <linux/interrupt.h>
#include <linux/io.h>
#include <linux/workqueue.h>
#include <linux/completion.h>
#include <linux/delay.h>
#include <linux/spi/spi.h>
#include <linux/platform_device.h>

#include <linux/mtd/partitions.h>
#include <linux/spi/flash.h>

#include <asm/io.h>
#include <asm/bug.h>

#include "xc6regs.h"
#include "xcboot.h"
#include "iia.h"

static unsigned int spi_mode = 0;
module_param(spi_mode, uint, 0);
MODULE_PARM_DESC(spi_mode, "SPI device operation mode. 0:spidev 1:mtd");
static int g_dbg_level = 3;  // 3 default to output error msg, 0 to disable all msg // 255 to enale all msg   // level larger than this will NOT output to /var/log/messages
module_param(g_dbg_level, int, 0644);
MODULE_PARM_DESC(g_dbg_level, "SPI0 debug msg level. 3: default, output error msg; 0: disable all msg; 255: enable all msg.");


#define DRIVER_NAME	    "xc6_spi0"
//#define XC6_SPI_POLL_MODE   / polling mode or interrupt mode
#define XC6_SPI_BUS_NUM     0

#define NUMBEROF10MSDELAY           1
#define NUMBEROF100NSDELAY          (NUMBEROF10MSDELAY * 100000 * 100)
#define NUMBEROFPOLLS               (NUMBEROF10MSDELAY*1)   //based on Min 100 Kilobits/sec (Max 3 Megabits/sec)

enum {
    DBGLEVEL0       = 0,
    DBGLEVELERR     = 1,
    DBGLEVELWARN    = 2,
    DBGLEVELINFO    = 3,
    DBGLEVELDEBUG   = 4,
    DBGLEVELMAX     = 255
};

#define ALL_MSG "xc6_spi0, "

static void print_debug(int level, char *fmt, ...);

#define PERROR(format, args...)    print_debug(DBGLEVELERR, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PWARN(format, args...)     print_debug(DBGLEVELWARN, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PINFO(format, args...)     print_debug(DBGLEVELINFO, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PDEBUG(format, args...)    print_debug(DBGLEVELDEBUG, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PVERBOSE(format, args...)  print_debug(DBGLEVEL0, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)

#define HOST_MUTEX_START                    0x8
#define HOST_MUTEX_END                      0xF
#define XC_FLASH_HW_MUTEX                                 XC_MIPS_INTERLOCK2
#define XC_FLASH_HW_MUTEX_ID_SHIFT                        XC_MIPS_INTERLOCK2_ID4_SHIFT
#define XC_FLASH_INTERLOCK_NAND_DRV_ID                    (HOST_MUTEX_START+1)
#define XC_FLASH_INTERLOCK_SPI_DRV_ID                     (HOST_MUTEX_START+2)

struct xc6_spi_pdata {
	unsigned int board_id;
	unsigned int m_irq;
	void __iomem *mp_mmr;
};

struct xc6_spi {	
	struct spi_master *master;
	struct spi_message *cur_msg;
    void __iomem *base;
	spinlock_t lock;
	u32 irq;
	u32 hold;
	u32 cap_edge;
	u32 tr_size; 		//Tranmit len 0-3
	u32 rem_size;		//Remained len
	u32 idx;			//Index in buffer
	u8* tx_buf;
	u8* rx_buf;
	struct completion done;
};

static struct platform_device *xc6_spi_device[MAXXCODENUM] = {NULL};

static void print_debug(int level, char *fmt, ...)
{
    va_list ap ;
    char s[128];

    if (level > g_dbg_level) 
        return;
    
    va_start(ap, fmt);
    vsnprintf(s, sizeof(s), fmt, ap);
    printk(KERN_NOTICE  ALL_MSG"%s", s);
    va_end(ap);
}

static void change_nandtospi(struct xc6_spi *xc6_spi)
{

}

static void spi_hw_lock(struct xc6_spi *xc6_spi)
{
    uint32 data;
    uint32 mtxdat;

    while (1){
        data = readl(xc6_spi->base + XC_FLASH_HW_MUTEX);
        data = (data >> XC_FLASH_HW_MUTEX_ID_SHIFT) & 0x0F;

        if (data == XC_FLASH_INTERLOCK_SPI_DRV_ID){
            break;
        }
        if (data != 0){
            msleep(1);
        }
        mtxdat = XC_FLASH_INTERLOCK_SPI_DRV_ID << XC_FLASH_HW_MUTEX_ID_SHIFT;
        writel(mtxdat, xc6_spi->base + XC_FLASH_HW_MUTEX);
    }
    
    // change to spi mode
    change_nandtospi(xc6_spi);   
}

static void spi_hw_unlock(struct xc6_spi *xc6_spi)
{
    uint32 data;
    uint32 mtxdat;

    data = readl(xc6_spi->base + XC_FLASH_HW_MUTEX);
    data = (data >> XC_FLASH_HW_MUTEX_ID_SHIFT) & 0x0F;
    
    if(data == XC_FLASH_INTERLOCK_SPI_DRV_ID) {
        mtxdat = (XC_FLASH_INTERLOCK_SPI_DRV_ID & 0x0F) << XC_FLASH_HW_MUTEX_ID_SHIFT;
        writel(mtxdat, xc6_spi->base + XC_FLASH_HW_MUTEX);
        data = readl(xc6_spi->base + XC_FLASH_HW_MUTEX);
    }
}


static void xc6_spi_set_speed(struct xc6_spi *xc6_spi, struct spi_transfer *xfer)
{
	uint32 div;
	uint32 tmp;
	/* The src clk is 162M, max divider is 65535, check for valid device clk speed */
	if ((xfer->speed_hz > 1500) && (xfer->speed_hz <= 80000000)) {
		tmp = (162000000 / xfer->speed_hz) >> 1;
		div = (tmp << 16) | tmp;
		PDEBUG("new clock speed %d, div 0x%08x\n", xfer->speed_hz, div);
		writel(div, xc6_spi->base + XC_SPI_PULSE_WIDTH_CONFIG);
	}
}

#ifndef XC6_SPI_POLL_MODE

static inline void xc6_spi_en_irq(struct xc6_spi *xc6_spi)
{
	u32 tmp;
    void __iomem *reg;
    
    // clear interrupt
    reg = xc6_spi->base + XC_SPI_FIFO_INT_STATUS;
    tmp = readl(reg);
    writel(tmp, reg);

    //enable interrupt
#ifndef XC_SOC_BUILD
    reg = xc6_spi->base + XC_SPI_FIFO_HOST_INT_MASK;
    PDEBUG("SPI_FIFO_HOST_INT_MASK addr: %x\n", reg);
    tmp = XC_SPI_FIFO_HOST_INT_MASK_INT_EN_SPI_DONE_MASK;
    writel(tmp, reg);
#else
    reg = xc6_spi->base + XC_SPI_FIFO_MIPS_INT_MASK;
    PDEBUG("SPI_FIFO_HOST_INT_MASK addr: %x\n", reg);
    tmp = XC_SPI_FIFO_MIPS_INT_MASK_INT_EN_SPI_DONE_MASK;
    writel(tmp, reg);
#endif

	return;
}

static inline void xc6_spi_dis_irq(struct xc6_spi *xc6_spi)
{
	u32 tmp;
    void __iomem *reg;
    
    //disable interrupt
#ifndef XC_SOC_BUILD
    reg = xc6_spi->base + XC_SPI_FIFO_HOST_INT_MASK;
    tmp = 0;
    writel(tmp, reg);
#else
    reg = xc6_spi->base + XC_SPI_FIFO_MIPS_INT_MASK;
    tmp = 0;
    writel(tmp, reg);
#endif
    
	return;
}

#else

static int xc6_spi_poll_status(struct xc6_spi *xc6_spi)
{
    int ret = -ETIMEDOUT;
    u32 tmp;
    unsigned long long pollcount = 0;
    void __iomem *reg;

    reg = xc6_spi->base + XC_SPI_STATUS;
    while (pollcount < (unsigned long long)NUMBEROF100NSDELAY)
    {
        //Delay_10s_of_Ms (pXcode, NUMBEROF10MSDELAY);
        tmp = readl(reg);
        tmp &= XC_SPI_STATUS_SPI_BUSY_MASK;
        if (tmp == 0)
        {
            ret = 0;
            break;
        }
        //pollcount = NUMBEROFPOLLS - 1;
        udelay(10);
        pollcount++;
    }

    return ret;
}
#endif


static int xc6_spi_shift(struct xc6_spi *xc6_spi, u8 *pbuf, u32 hold, u32 select)
{	
    u32 config;
    u32 data = 0;
    int i;
    void __iomem *reg;

	for (i=0; i <= xc6_spi->tr_size; i++)
		data |= pbuf[i] << (3-i)*8;

    config =(((xc6_spi->cap_edge << XC_SPI_CFG_CAP_EDGE_SHIFT) & XC_SPI_CFG_CAP_EDGE_MASK) | 
           ((xc6_spi->tr_size << XC_SPI_CFG_XFER_SIZE_SHIFT) & XC_SPI_CFG_XFER_SIZE_MASK) |
           ((0x2 << XC_SPI_CFG_SHFT_EDGE_SHIFT) & XC_SPI_CFG_SHFT_EDGE_MASK) |
           ((hold << XC_SPI_CFG_HOLD_EN_SHIFT) & XC_SPI_CFG_HOLD_EN_MASK));

    reg = xc6_spi->base + XC_SPI_CFG;
    config |= (XC_SPI_CFG_SPI_RESETN_MASK | XC_SPI_CFG_WRITE_PROTECT_N_MASK);
	config |= ((select << XC_SPI_CFG_SPI_SEL_SHIFT) & XC_SPI_CFG_SPI_SEL_MASK);
    PDEBUG("SPI_CFG: 0x%08x\n", config);
	writel(config, reg);
    reg = xc6_spi->base + XC_SPI_WDAT;
    PDEBUG("SPI_WDAT: 0x%08x\n", data);
	writel(data, reg);

#ifndef XC6_SPI_POLL_MODE
    return 0;
#else
	return xc6_spi_poll_status(xc6_spi);
#endif
}

static inline void xc6_spi_init_hw(struct xc6_spi *xc6_spi)
{
	void __iomem *reg;
	u32 tmp;

    //RESET
    reg = xc6_spi->base + XC_RBM_PADU_CTRL;
    tmp = readl(reg);
    tmp &= ~XC_RBM_PADU_CTRL_PADU_CTRL_SPI0_MASK;
    writel(tmp, reg);
    
    reg = xc6_spi->base + XC_ACC_BLK_STOP0;
    tmp = readl(reg);
    tmp &= ~XC_ACC_BLK_STOP0_NRFC_BLK_STOP_MASK;
    writel(tmp, reg);

    reg = xc6_spi->base + XC_ACC_RESET_REG0;
    tmp = readl(reg);
    tmp |=XC_ACC_RESET_REG0_NRFC_RESET_MASK;
    writel(tmp, reg);
    udelay(1); 
    tmp &= ~XC_ACC_RESET_REG0_NRFC_RESET_MASK;
    writel(tmp, reg);

    /* SPI BUS CLOCK = HUECLK / 8 = 20.25MHz */
	reg = xc6_spi->base + XC_CG_DUMMY_REG1;
	tmp = readl(reg);
	if((tmp & 0xFF00) == 0x1100) {
    	reg = xc6_spi->base + XC_SPI_PULSE_WIDTH_CONFIG;
    	tmp = (0x08 << XC_SPI_PULSE_WIDTH_CONFIG_SPI_CLK_HI_WIDTH_SHIFT) | (0x08 << XC_SPI_PULSE_WIDTH_CONFIG_SPI_CLK_LOW_WIDTH_SHIFT);
    	writel(tmp, reg);
    } else {
    	reg = xc6_spi->base + XC_SPI_PULSE_WIDTH_CONFIG;
    	tmp = (0x04 << XC_SPI_PULSE_WIDTH_CONFIG_SPI_CLK_HI_WIDTH_SHIFT) | (0x04 << XC_SPI_PULSE_WIDTH_CONFIG_SPI_CLK_LOW_WIDTH_SHIFT);
    	writel(tmp, reg);
	}
    /* SPI MODE */
    reg = xc6_spi->base + XC_SPI_CFG;
    tmp = (0x0 << XC_SPI_CFG_CAP_EDGE_SHIFT) | (0x2 << XC_SPI_CFG_SHFT_EDGE_SHIFT);
    tmp |= (XC_SPI_CFG_SPI_RESETN_MASK | XC_SPI_CFG_WRITE_PROTECT_N_MASK);
    writel(tmp, reg);
}

#ifndef XC6_SPI_POLL_MODE

static inline void xc6_spi_rx(struct xc6_spi *xc6_spi, u8* pbuf)
{	
	u32 data, i;
	void __iomem *reg;

    reg = xc6_spi->base + XC_SPI_RDAT;
	data = readl(reg);
	PDEBUG("SPI read data 0x%08x\n", data);

	for (i=0; i <= xc6_spi->tr_size; i++){	
		pbuf[i] = (data>>((xc6_spi->tr_size-i)*8))&0xff;
	}
    
	return;
}


static irqreturn_t xc6_spi_isr(int irq, void* dev_id)
{
	struct xc6_spi *xc6_spi = dev_id;
	struct spi_device *spi;
	u32 temp, hold, cs;
    void __iomem *reg;
	  
	if (unlikely(dev_id == NULL))
		return IRQ_NONE;

    PDEBUG("Enter %s\n", __func__);

    reg = xc6_spi->base + XC_SPI_FIFO_INT_STATUS;
	temp = readl(reg);
    PDEBUG("INT_STATUS: 0x%08x\n", temp);
	if ((temp & XC_SPI_FIFO_INT_STATUS_SPI_DONE_MASK) == 0)
		return IRQ_NONE;

    if (xc6_spi->rem_size == 0) {
        //clean up only SPI done interrupt
	    temp = XC_SPI_FIFO_INT_STATUS_SPI_DONE_MASK;
        reg = xc6_spi->base + XC_SPI_FIFO_INT_STATUS;
	    writel(temp, reg);
        
        return IRQ_HANDLED;
    }
	spi = xc6_spi->cur_msg->spi;
	cs = spi->chip_select;

	//hold until transfer done
	spin_lock(&xc6_spi->lock);
	xc6_spi->rem_size -= xc6_spi->tr_size + 1;
	hold = (xc6_spi->hold == 1) || (xc6_spi->rem_size > 4);	
	spin_unlock(&xc6_spi->lock);

	//start process data read first
	if (xc6_spi->rx_buf)		
		xc6_spi_rx(xc6_spi, xc6_spi->rx_buf + xc6_spi->idx);

	spin_lock(&xc6_spi->lock);
	xc6_spi->idx += xc6_spi->tr_size + 1;	
	if (xc6_spi->rem_size > 4)
		xc6_spi->tr_size = 3;
	else
		xc6_spi->tr_size = xc6_spi->rem_size - 1;
	spin_unlock(&xc6_spi->lock);

	//clean up only SPI done interrupt
	temp = XC_SPI_FIFO_INT_STATUS_SPI_DONE_MASK;
    reg = xc6_spi->base + XC_SPI_FIFO_INT_STATUS;
	writel(temp, reg);
	
	//start next Tx/Rx Until rem_size = 0
	if (xc6_spi->rem_size > 0) {        
		if(xc6_spi->tx_buf)
			xc6_spi_shift(xc6_spi, xc6_spi->tx_buf + xc6_spi->idx, hold, cs);
		
		if (xc6_spi->rx_buf)
		{
            temp = 0;
			xc6_spi_shift(xc6_spi, (u8*)(&temp), hold, cs);
		}
		
	} else {
		//printk("SPI ISR COMPLETE\n");		
		complete(&xc6_spi->done);
	}
	
    return IRQ_HANDLED;
}

static int xc6_spi_transfer_one_message(struct spi_master *master,
					    struct spi_message *msg)
{
	struct xc6_spi *xc6_spi = spi_master_get_devdata(master);
	struct spi_device *spi = msg->spi;
	struct spi_transfer *xfer;
	int status = 0;
    u32 hold, data, cs;
    int ms;

	xc6_spi->cur_msg = msg;
	cs = spi->chip_select;
    spi_hw_lock(xc6_spi);

    //enable SPI interrupt again in case it is disabled by SOC SPI driver
    xc6_spi_en_irq(xc6_spi);

	list_for_each_entry(xfer, &msg->transfers, transfer_list) {

		unsigned long flags;

		spin_lock_irqsave(&xc6_spi->lock, flags);

		xc6_spi_set_speed(xc6_spi, xfer);
		
        if (xfer->transfer_list.next == &msg->transfers) //last transfer
            xc6_spi->hold = xfer->cs_change;
        else
            xc6_spi->hold = 1;
        xc6_spi->rem_size = xfer->len;
        xc6_spi->idx = 0;
        xc6_spi->cap_edge = 0;
        xc6_spi->rx_buf = (u8*)xfer->rx_buf;
        xc6_spi->tx_buf = (u8*)xfer->tx_buf;
        //process not 4 byte aligned byte firsr
        xc6_spi->tr_size = (xfer->len > 4) ? 3 : xfer->len-1; 
        hold = (xc6_spi->hold == 1) || (xc6_spi->rem_size > 4);


		if (xfer->tx_buf != NULL) {
            PDEBUG("SPI write len: %d\n", xfer->len);
            data = 0;
            status = xc6_spi_shift(xc6_spi, (u8*)xfer->tx_buf, hold, cs);
            if (status != 0)
                goto out;
		}

        if (xfer->rx_buf != NULL) {
            PDEBUG("SPI read len: %d\n", xfer->len);
            data = 0;
            status = xc6_spi_shift(xc6_spi, (u8*)&data, hold, cs);
            if (status != 0)
                goto out;
		}

		spin_unlock_irqrestore(&xc6_spi->lock, flags);

        wait_for_completion(&xc6_spi->done);

		if (xfer->delay_usecs)
			udelay(xfer->delay_usecs);

		msg->actual_length += xfer->len;
	}

out:
	msg->status = status;

    spi_hw_unlock(xc6_spi);
    
	spi_finalize_current_message(master);

	return 0;
}


#else

static int xc6_spi_read_dword(struct xc6_spi *xc6_spi, u32 * pData, u32 hold)
{
    int retval;
    int temp = 0;
	struct spi_device *spi = xc6_spi->cur_msg->spi;
    void __iomem *reg;
	u32 cs = spi->chip_select;

    xc6_spi->tr_size = 3;
    retval = xc6_spi_shift(xc6_spi, (u8 *)&temp, hold, cs);
    if (retval == 0){
        reg = xc6_spi->base + XC_SPI_RDAT;
        *pData = readl(reg);
        PDEBUG("Read SPI data register value: 0x%08x\n", *pData);
    }
    else
        PERROR("Read SPI data failed\n");

    return retval;
}

static int xc6_spi_read(struct xc6_spi *xc6_spi, u8* pbuf, u32 size)
{
    int retval = 0;
    u32 cnt = size;
    u32 data32;
    u8 *p8 = pbuf;

    while (cnt > 0)
    {
        if (cnt > 4)
        {
            retval = xc6_spi_read_dword(xc6_spi, &data32, 1);
            if (retval != 0){
                return retval;
            }

            *(p8++) = (uint8)((data32 & 0xff000000)>>24);
            *(p8++) = (uint8)((data32 & 0x00ff0000)>>16);
            *(p8++) = (uint8)((data32 & 0x0000ff00)>>8);
            *(p8++) = (uint8)(data32 & 0x000000ff);         

            cnt -= 4;
        }else
        {
            // last 1 dword, or less than 4 bytes
            retval = xc6_spi_read_dword(xc6_spi, &data32, xc6_spi->hold);
            if (retval != 0){
                return retval;
            }

            *(p8++) = (uint8)((data32 & 0xff000000)>>24);
            if (cnt >= 2)
			{
                *(p8++) = (uint8)((data32 & 0x00ff0000)>>16);
	            if (cnt >= 3)
				{
	                *(p8++) = (uint8)((data32 & 0x0000ff00)>>8);
		            if (cnt == 4){
		                *(p8++) = (uint8)(data32 & 0x000000ff);
		            }						
	            }
            }

            cnt = 0;
        }
    }

    return 0;
}

static int xc6_spi_write(struct xc6_spi *xc6_spi, u32 cs, u8* pbuf, u32 size)
{
    int retval;
    u32 cnt = size;
    u8 *p8 = pbuf;

    while (cnt > 0){
        if (cnt > 4){
            xc6_spi->tr_size = 3;
            retval = xc6_spi_shift(xc6_spi, p8, 1, cs);
            if (retval != 0){
                return retval;
            }
            p8 += 4;
            cnt -= 4;
        } else {
            xc6_spi->tr_size = cnt - 1;
            retval = xc6_spi_shift(xc6_spi, p8, xc6_spi->hold, cs);
            if (retval != 0){
                return retval;
            }
            cnt = 0;
        }
    }

    return 0;
}

static int xc6_spi_transfer_one_message(struct spi_master *master,
					    struct spi_message *msg)
{
	struct xc6_spi *xc6_spi = spi_master_get_devdata(master);
	struct spi_device *spi = msg->spi;
	struct spi_transfer *xfer;	
	int status = 0;
	u32 chip_select = spi->chip_select;

    spi_hw_lock(xc6_spi);
    
	list_for_each_entry(xfer, &msg->transfers, transfer_list) {

		unsigned long flags;

		spin_lock_irqsave(&xc6_spi->lock, flags);

        if (xfer->transfer_list.next == &msg->transfers) //last transfer
            xc6_spi->hold = xfer->cs_change;
        else
            xc6_spi->hold = 1;

		if (xfer->tx_buf != NULL) {
            PDEBUG("SPI write chip %d len: %d\n", chip_select, xfer->len);
            status = xc6_spi_write(xc6_spi, chip_select, (u8*)xfer->tx_buf, xfer->len);
            if (status != 0)
                goto out;
		}

        if (xfer->rx_buf != NULL) {
            PDEBUG("SPI readip %d len: %d\n", chip_select, xfer->len);
            status = xc6_spi_read(xc6_spi, chip_select, (u8*)xfer->rx_buf, xfer->len);
            if (status != 0)
                goto out;
		}

		spin_unlock_irqrestore(&xc6_spi->lock, flags);

		if (xfer->delay_usecs)
			udelay(xfer->delay_usecs);

		msg->actual_length += xfer->len;
	}

out:
	msg->status = status;

    spi_hw_unlock(xc6_spi);

	spi_finalize_current_message(master);

	return 0;
}
#endif

static int xc6_spi_setup(struct spi_device *spi)
{	
	return 0;
}

static void xc6_spi_cleanup(struct spi_device *spi)
{
	return;
}

static struct mtd_partition spi_partitions_sdk[] = {
	{
		.name	= "SPI_BOOT",
		.offset = 0x0000000,
		.size	= 0x2000000,
	},
};

static struct flash_platform_data spi_flash_data_sdk = {
	.name		= "S25FL512S",
	.nr_parts	= ARRAY_SIZE(spi_partitions_sdk),
	.parts		= spi_partitions_sdk,
	.type 		= "s25fl512s"
};

static struct spi_board_info spi_mtd = {
	.modalias	= "m25p80",
	.platform_data = &spi_flash_data_sdk,
	.max_speed_hz = 10000000,
	.bus_num	= XC6_SPI_BUS_NUM,
	.chip_select = 0,
	.mode		=  SPI_MODE_1,	
};

static struct spi_board_info spi_dev_0 = {
    .modalias   = "spidev",
    .max_speed_hz = 10000000,
    .bus_num    = XC6_SPI_BUS_NUM,
    .chip_select = 0,
    .mode       =  SPI_MODE_1,
};

static struct spi_board_info spi_dev_1 = {
    .modalias   = "spidev",
    .max_speed_hz = 80000000,
    .bus_num    = XC6_SPI_BUS_NUM,
    .chip_select = 1,
    .mode       =  SPI_MODE_1,
};

static int xc6_spi_probe(struct platform_device *pdev)
{
	struct spi_master	*master;
    struct xc6_spi_pdata *pdata = (struct xc6_spi_pdata*)pdev->dev.platform_data;
	struct xc6_spi	*xc6_spi = NULL;
	int status;
    
	PDEBUG("START: XCode SPI Controller driver\n");
 
	master = spi_alloc_master(&pdev->dev, sizeof *xc6_spi);
	if (!master) {
		PERROR("Fail to allocate master\n");
		return -ENOMEM;
	}
    
	xc6_spi = spi_master_get_devdata(master);
#ifndef XC_SOC_BUILD
	xc6_spi->irq = pdata->m_irq;
#else
	xc6_spi->irq = XCODE6_IRQ_SPI0;
#endif
	xc6_spi->cur_msg = NULL;
    xc6_spi->base = pdata->mp_mmr;
    xc6_spi->cap_edge = 0;
    xc6_spi->rem_size = 0;
	platform_set_drvdata(pdev, xc6_spi);
	
	xc6_spi_init_hw(xc6_spi);
	
	master->num_chipselect = 2;
	master->bus_num = XC6_SPI_BUS_NUM + pdata->board_id * 10;
	master->mode_bits = SPI_MODE_1;
	master->setup = xc6_spi_setup;
	master->transfer_one_message = xc6_spi_transfer_one_message;
	master->cleanup = xc6_spi_cleanup;
	xc6_spi->master = master;
	PDEBUG("bus# %d num_cs %d irq# %d\n", master->bus_num, master->num_chipselect, xc6_spi->irq);
#ifndef XC6_SPI_POLL_MODE
	status = request_irq(xc6_spi->irq, xc6_spi_isr, IRQF_SHARED, "xc6_spi_irq", (void*)xc6_spi);
	if (status){
		PERROR("fail to request irq %d error %d\n", xc6_spi->irq, status);
		goto free_master;
	}

#ifndef XC_SOC_BUILD
    IIAHostSetMask(xc6_spi->base, IIA_NRFC_INT);
#endif
    
    xc6_spi_en_irq(xc6_spi);
    
	init_completion(&xc6_spi->done);
#endif	
	spin_lock_init(&xc6_spi->lock);

	status = spi_register_master(master);	

	if (status < 0){
		PERROR("fail to register driver, errno:%d\n", status);
#ifndef XC6_SPI_POLL_MODE
		goto free_irq;
#else
        goto free_master;
#endif
	}

    if (spi_mode == 0) {
	    spi_dev_0.bus_num = master->bus_num;
        spi_new_device(master, &spi_dev_0);

	    spi_dev_1.bus_num = master->bus_num;
        spi_new_device(master, &spi_dev_1);
    }
    else {
	    spi_mtd.bus_num = master->bus_num;
        spi_new_device(master, &spi_mtd);
    }
	
	PDEBUG("END: XCode SPI Controller driver probe success\n");		
	return status;

#ifndef XC6_SPI_POLL_MODE
free_irq:
	free_irq(xc6_spi->irq, (void*)xc6_spi);
#endif
free_master:
	if(master)
		spi_master_put(master);
    
	PERROR("XCode SPI Controller driver init fail\n");
	return status;	
}

static int xc6_spi_remove(struct platform_device *pdev)
{
	struct xc6_spi *xc6_spi;	

	xc6_spi = platform_get_drvdata(pdev);

    spi_unregister_master(xc6_spi->master);
#ifndef XC6_SPI_POLL_MODE
    xc6_spi_dis_irq(xc6_spi);
	free_irq(xc6_spi->irq, xc6_spi);
#endif
	platform_set_drvdata(pdev, NULL);
	spi_master_put(xc6_spi->master);

	return 0;
}

static struct platform_driver xc6_spi_driver = {
	.probe		= xc6_spi_probe,
    .remove     = xc6_spi_remove,
	.driver		= {
		.name	= "xc6_spi0",
        .owner	= THIS_MODULE,
	},
};

static int __init xc6_spi_init(void)
{
    struct platform_device *pDevice;
	struct xc6_spi_pdata spi_pdata;
    s_xc_device info;
    int i;
    int error;
    
    for (i = 0; i < MAXXCODENUM; i++)
    {
        if (get_xc_pcie_device_info(i, &info) == 0)
        {
            PDEBUG("found xc device %d ok\n", i);
			
			spi_pdata.board_id = i;
			spi_pdata.m_irq = info.m_irq;
			spi_pdata.mp_mmr = info.mp_mmr;
			
            pDevice = platform_device_alloc("xc6_spi0", i);;

            if (!pDevice) 
            {
                PERROR("platform_device_alloc failed\n");
                return (-ENOMEM);
            }

			error = platform_device_add_data(pDevice, &spi_pdata, sizeof(spi_pdata));
			if (error)
			{
				PERROR("platform_device_add_data failed\n");
				goto err_free_device;
			}

            PDEBUG(" ->platform_device_add\n");

            error = platform_device_add(pDevice);
            if (error)
            {
                PERROR("platform_device_add failed\n");
                goto err_free_device;
            }
            
            xc6_spi_device[i] = pDevice;
        }
    }

	return platform_driver_register(&xc6_spi_driver);

err_free_device:
    platform_device_put(pDevice);
    return error;
}
module_init(xc6_spi_init);

static void __exit xc6_spi_exit(void)
{
    int i;

    PDEBUG("platform_driver_unregister\n");
	platform_driver_unregister(&xc6_spi_driver);

    for (i = 0; i < MAXXCODENUM; i++)
    {
        if (xc6_spi_device[i] != NULL)
        {
            PDEBUG("platform_device_unregister\n");
            platform_device_unregister(xc6_spi_device[i]);
        }
        else
            break;
    }
}
module_exit(xc6_spi_exit);

MODULE_DESCRIPTION("SPI master driver for ViXS XCode6 SPI Master");
MODULE_AUTHOR("Zhigang Luo <zluo@vixs.com>");
MODULE_LICENSE("GPL");
