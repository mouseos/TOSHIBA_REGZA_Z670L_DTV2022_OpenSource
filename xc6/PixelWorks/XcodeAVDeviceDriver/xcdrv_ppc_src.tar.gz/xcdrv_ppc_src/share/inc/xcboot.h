/*  ViXS Systems Inc. Proprietary and Confidential */

/** xcboot.h
* This file defines xcboot driver interface 
*
*/

#ifndef _XCBOOT_H_
#define _XCBOOT_H_

#include "vixstypes.h"

#define	MAXXCODENUM		(40)
#define MAX_CMD_LEN     (128)


typedef struct s_xc_device_
{
    pvoid                   mp_mmr;
    pvoid                   mp_mmfb;
    uint32                  m_rsize;
    uint32                  m_fbsize;
    uint32                  m_irq;
    uint32                  m_phys_1M_buf;  // physical address of 1M bytes buf access by PCIe host
    struct pci_dev          *mps_pcidev;
    unsigned long           m_physfb;
    unsigned long           m_physmmr;    
}   s_xc_device, *ps_xc_device;
    
uint32 get_xc_pcie_device_info(uint32 index, ps_xc_device pinfo);  
uint32 reboot_xc_pcie_device(uint32 index);

#ifdef XC_SOC_BUILD
uint32 get_xc_pcie_device_info(uint32 index, ps_xc_device pinfo)
{
    if (index == 0) {
		pinfo->mp_mmfb = NULL;
        pinfo->mp_mmr = (void *)XC_SOC_PROC_MMREG_BASE;
        pinfo->m_irq = XCODE6_IRQ_PPC; //default for PPC
        return 0;
    }

    return -1;
}
#endif


#endif

