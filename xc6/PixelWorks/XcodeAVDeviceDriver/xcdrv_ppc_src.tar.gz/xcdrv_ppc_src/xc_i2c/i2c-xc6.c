/*
 * XCODE6 I2C master mode driver
 *
 * Copyright (C) 2015 ViXS Systems, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */

#include <linux/module.h>
#include <linux/delay.h>
#include <linux/i2c.h>
#include <linux/err.h>
#include <linux/interrupt.h>
#include <linux/completion.h>
#include <linux/platform_device.h>
#include <linux/clk.h>
#include <linux/io.h>
#include <linux/of.h>
#include <linux/of_device.h>
#include <linux/slab.h>

#include "xc6regs.h"
#include "xcerr.h"
#include "xcboot.h"
#include "iia.h"

static int g_dbg_level = 3;  // 3 default to output error msg, 0 to disable all msg // 255 to enale all msg   // level larger than this will NOT output to /var/log/messages
module_param(g_dbg_level, int, 0644);
MODULE_PARM_DESC(g_dbg_level, "I2C debug msg level. 3: default, output error msg; 0: disable all msg; 255: enable all msg.");

/* HW support 2 I2C masters */
#define XC6_I2C_BLOCKS 2
#define XC6_I2C_NUM XC6_I2C_BLOCKS

#define XC6_I2C_FIFO_SIZE 64

enum {
    DBGLEVEL0       = 0,
    DBGLEVELERR     = 1,
    DBGLEVELWARN    = 2,
    DBGLEVELINFO    = 3,
    DBGLEVELDEBUG   = 4,
    DBGLEVELMAX     = 255
};

#define ALL_MSG "xc6_i2c, "

void print_debug(int level, char *fmt, ...);
void log_printf(int id, int level, char *fmt, ...);

#define PPC_INT_MASK_LOCK			XC_MIPS_INTERLOCK5
#define PPC_INT_MASK_LOCK_INDEX		5
#define PPC_INT_MASK_LOCK_I2C_ID	1
static const uint32 mutex_masks[8] = {0x0000000F, 0x000000F0, 0x00000F00, 0x0000F000, 0x000F0000, 0x00F00000, 0x0F000000, 0xF0000000};
static const uint32 mutex_shifts[8] = {0, 4, 8, 12, 16, 20, 24, 28};

#define PERROR(format, args...)    print_debug(DBGLEVELERR, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PWARN(format, args...)     print_debug(DBGLEVELWARN, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PINFO(format, args...)     print_debug(DBGLEVELINFO, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PDEBUG(format, args...)    print_debug(DBGLEVELDEBUG, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PVERBOSE(format, args...)  print_debug(DBGLEVEL0, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)

/* 
 * Timeout waiting for the controller to respond
 * XCode I2C data FIFO depth 64 bytes (64 x 10 / 10^5) x 10^6 = 6400 us
 * set timeout period 100ms
 */
#define XC6_I2C_TIMEOUT (msecs_to_jiffies(100))

#define mmr_reg_readl(dev,reg) readl(dev->base+reg)
#define mmr_reg_writel(dev,reg,data) writel(data,(dev->base+reg))

static struct platform_device *xc6_i2c_device[MAXXCODENUM] = {NULL};
static struct resource xc6_i2c_resources[2];
/* use two mutex locks to protect the i2c ports */
static struct mutex xc6_i2c_mutex[XC6_I2C_BLOCKS];
/* xc6_i2c_gpiom_mutex, protect the GPIO_M group registers access */
static struct mutex xc6_i2c_gpiom_mutex;
static bool xc6_i2c_hwinit_flag[XC6_I2C_BLOCKS] = {false};
static bool xc6_i2c_ext_port_en = false;

struct xc6_i2c_dev {
	struct mutex		*lock;
	struct device		*dev;
	void    		    *base;		/* virtual */
	int			        irq;
	struct completion	cmd_complete;
    bool 				wait_complete;
	u32			        cmd_err;
	u32			        nr; //HW block number
	u32					bus_num;
	u32			        int_mask;
	u8			        *buf;
	size_t		        buf_len;
	struct i2c_adapter	adapter;
};

void print_debug(int level, char *fmt, ...)
{
    va_list ap ;
    char s[128];

    if (level > g_dbg_level) 
        return;
    
    va_start(ap, fmt);
    vsnprintf(s, sizeof(s), fmt, ap);
    printk(KERN_NOTICE  ALL_MSG"%s", s);
    va_end(ap);
}

static int hw_interlock_lock(struct xc6_i2c_dev *i2c_dev, u32 reg, u32 idx, u32 owner_id)
{
	u32 mask = mutex_masks[idx];
	owner_id <<= mutex_shifts[idx];
	owner_id &= mask;
	mmr_reg_writel(i2c_dev, reg, owner_id);
	if((mmr_reg_readl(i2c_dev, reg) & mask) == owner_id)
		return XCE_OK;
	else
		return XCE_NO_MORE;
}

static int hw_interlock_unlock(struct xc6_i2c_dev *i2c_dev, u32 reg, u32 idx, u32 owner_id)
{
	u32 mask = mutex_masks[idx];
	owner_id <<= mutex_shifts[idx];
	owner_id &= mask;
	mmr_reg_writel(i2c_dev, reg, owner_id);
	if((mmr_reg_readl(i2c_dev, reg) & mask) == 0)
		return XCE_OK;

	PERROR("owner id 0x%x lock id 0x%x\n", owner_id, mmr_reg_readl(i2c_dev, reg));	
	return XCE_TRAP;
}

static int xc6_i2c_reset(struct xc6_i2c_dev *i2c_dev)
{
    u32 temp;
	u32 lock_idx;
	unsigned long flags;

    //reset the I2C internal counters
    mmr_reg_writel(i2c_dev, XC_I2C0_DATA_READ + i2c_dev->nr*0x10, 0x00000000);

    /* clear interrupts */
    mmr_reg_writel(i2c_dev, XC_PPC_INT_STATUS, i2c_dev->int_mask);

#ifndef XC_SOC_BUILD
    /* enable PPC IIA interrupt */
    IIAHostSetMask(i2c_dev->base, IIA_PPC_INT);

    /* enable I2C HOST interrupts */
    temp = mmr_reg_readl(i2c_dev, XC_PPC_HOST_INT_MASK);
    temp |= i2c_dev->int_mask;
    mmr_reg_writel(i2c_dev, XC_PPC_HOST_INT_MASK, temp);
#else
	/* disable PPC IIA interrupt */
	//IIALocalClearMask(IIA_PPC_INT);
	
	local_irq_save(flags);
	lock_idx = PPC_INT_MASK_LOCK_I2C_ID + smp_processor_id();
	while(hw_interlock_lock(i2c_dev, PPC_INT_MASK_LOCK, PPC_INT_MASK_LOCK_INDEX, lock_idx) != XCE_OK);
    temp = mmr_reg_readl(i2c_dev, XC_PPC_INT_MASK);
    temp |= i2c_dev->int_mask;
    mmr_reg_writel(i2c_dev, XC_PPC_INT_MASK, temp);
	hw_interlock_unlock(i2c_dev, PPC_INT_MASK_LOCK, PPC_INT_MASK_LOCK_INDEX, lock_idx);
	local_irq_restore(flags);
#endif

	return 0;
}

static inline void xc6_i2c_toggle_scl (struct xc6_i2c_dev *dev, u32 clk)
{
	volatile u32 out, mask;
	u32 cnt = 0;	
	out = mmr_reg_readl(dev, XC_GPIO_M_OUT);
	mask = (1 << (dev->bus_num<<1));
	
	out |= mask;	
	mmr_reg_writel(dev, XC_GPIO_M_OUT, out);
	while(!(mmr_reg_readl(dev, XC_GPIO_M_IN) & out)) {
		if(cnt++ > 100) {
			PERROR("recover i2c bus %d, can't toggle clk pin high\n", dev->bus_num);
			return;
		}
	}
	udelay(clk>>1);

	out &= ~mask;
	mmr_reg_writel(dev, XC_GPIO_M_OUT, out);
	cnt = 0;
	while(mmr_reg_readl(dev, XC_GPIO_M_IN) & out) {
		if(cnt++ > 100) {
			PERROR("recover i2c bus %d, can't toggle clk pin low\n", dev->bus_num);
			return;
		}
	}
	udelay(clk>>1);
}

static void xc6_i2c_bus_recover(struct xc6_i2c_dev *dev)
{
	volatile u32 temp, sda, out;
	u32 pin_scl, pin_sda;
	int cnt = 0, clk_cnt=0;	

	if(!dev)
		return;

	pin_scl = (1 << (dev->bus_num<<1));
	pin_sda = (2 << (dev->bus_num<<1));
	
	PINFO("recover i2c bus %d\n", dev->bus_num);
	mutex_lock(&xc6_i2c_gpiom_mutex);

	/* switch to gpio mode and do a gpio i2c bit bang recover */
	temp = mmr_reg_readl(dev, XC_GPIO_M_CTRL);
	temp |= (1<<(31 - dev->bus_num));
	mmr_reg_writel(dev, XC_GPIO_M_CTRL, temp);

	/* pin order i2c0 scl:bit0; sda:bit1, set scl output and sda input */
	temp = mmr_reg_readl(dev, XC_GPIO_M_OE);
	temp &= ~(pin_scl | pin_sda);
	temp |= pin_scl;
	mmr_reg_writel(dev, XC_GPIO_M_OE, temp);

	/* do recover with gpio mode 
	 * try assert sda = 1, then toggle scl
	 * check sda == 1 ? if not toggle scl until sda == 1
	 * send stop bit (scl=1; sda=0->1)
	 * received 8 continuous sda high means the bus is released by device,
	 * since the sda is pulled high,  NAK sent and followed by STOP.
	 */		
	do {
		clk_cnt++;
		xc6_i2c_toggle_scl(dev, 10);
		sda = mmr_reg_readl(dev, XC_GPIO_M_IN) & pin_sda;
		if(sda & pin_sda)
			cnt++;
		else
			cnt=0;
		/* 
		 * the device max send 8 bits and wait for an ACK, 
		 * send up to 18 clk and timeout 
		 */
		if (clk_cnt > 18) {
			PERROR("recover i2c bus %d failed\n", dev->bus_num);
			break;
		}
	} while (cnt < 8);
	/* send STOP */
	out = mmr_reg_readl(dev, XC_GPIO_M_OUT);
	out |= pin_scl;
	mmr_reg_writel(dev, XC_GPIO_M_OUT, out);
	udelay(2);
	out &= ~pin_sda;
	mmr_reg_writel(dev, XC_GPIO_M_OUT, out);

	temp = mmr_reg_readl(dev, XC_GPIO_M_OE);
	temp |= pin_sda;
	mmr_reg_writel(dev, XC_GPIO_M_OE, temp);
	udelay(2);
	out |= pin_sda;
	mmr_reg_writel(dev, XC_GPIO_M_OUT, out);
	udelay(5);
	/* change the i2c pins back the HW mode */
	temp = mmr_reg_readl(dev, XC_GPIO_M_OE);
	temp &= ~(pin_scl | pin_sda);
	mmr_reg_writel(dev, XC_GPIO_M_OE, temp);
	out = mmr_reg_readl(dev, XC_GPIO_M_OUT);
	out &= ~(pin_scl | pin_sda);
	mmr_reg_writel(dev, XC_GPIO_M_OUT, out);
	temp = mmr_reg_readl(dev, XC_GPIO_M_CTRL);
	temp &= ~(1<<(31 - dev->bus_num));
	mmr_reg_writel(dev, XC_GPIO_M_CTRL, temp);

	mutex_unlock(&xc6_i2c_gpiom_mutex);
}

/*
 * Low level master read/write transaction.
 */
static int xc6_i2c_xfer_msg(struct i2c_adapter *adap,
			     struct i2c_msg *msg, int stop)
{
	struct xc6_i2c_dev *i2c_dev = i2c_get_adapdata(adap);
	unsigned long timeout;
    u32 temp;
	u32 channel_sel;
    u32 stop_en = 0;
    u32 start_en = 1;
    u32 adr_mode = 0; //$0: 7-bit addressing $1: 10-bit addressing
    u32 wop = 1; //0: Read $1: Write
    int i;
    u16 num_bytes;
    u16 num_words;
    u16 left_bytes;
	u32 savedIntMask = i2c_dev->int_mask;  
	// Save interrupt mask, for disabling I2C interrupt during time out, i.e. when switching to polling mode

	volatile u32 intStat;
	volatile u32 i2cCmd;

	PDEBUG("addr: 0x%04x, len: %d, flags: 0x%x, stop: %d\n",
		msg->addr, msg->len, msg->flags, stop);

    if (msg->len == 0)
		return -EINVAL;

    if (msg->flags & I2C_M_STOP)
		stop = 1;
	if (msg->flags & I2C_M_TEN)
		adr_mode = 1;
	if (msg->flags & I2C_M_NOSTART)
		start_en = 0;
    if (msg->flags & I2C_M_RD)
		wop = 0;

    //set up config register
    temp = 0;
    temp |= (0xFFFF << XC_I2C0_CONFIG_TIMEOUT_SHIFT );
    temp |= (adr_mode << XC_I2C0_CONFIG_ADR_MODE_SHIFT); //$0: 7-bit addressing $1: 10-bit addressing
    temp |= (360 << XC_I2C0_CONFIG_ATOMIC_PERIOD_SHIFT); //360 is for 100KHZ = (144MHZ/4/360)

	channel_sel = (i2c_dev->bus_num > 1) ? 1 : 0;	// two masters and each master support two ports.
	temp |= (channel_sel << XC_I2C0_CONFIG_CHANNEL_SEL_SHIFT); //$0: i2c0 and i2c1. $1: i2c2 and i2c3

    PDEBUG("XC_I2C_CONFIG: %x\n", temp);
    mmr_reg_writel(i2c_dev, XC_I2C0_CONFIG + i2c_dev->nr*0x10, temp);

	i2c_dev->buf = msg->buf;
	i2c_dev->buf_len = msg->len;

    do
    {
    num_bytes = min_t(size_t, XC6_I2C_FIFO_SIZE, i2c_dev->buf_len);
    
    if (wop == 1) //write
    {
        //load data for write
        num_words = num_bytes >> 2;
        if (num_words != 0)
        {
            for (i = 0; i < num_words; i++)
            {
                temp = (*i2c_dev->buf++);
                temp |= ((*i2c_dev->buf++) << 8);
                temp |= ((*i2c_dev->buf++) << 16);
                temp |= ((*i2c_dev->buf++) << 24);
                mmr_reg_writel(i2c_dev, XC_I2C0_DATA_LOAD + i2c_dev->nr*0x10, temp);
            }
        }

        left_bytes = num_bytes & 0x3;
        if (left_bytes != 0)
        {
            temp = 0;
            for (i = 0; i < left_bytes; i++)
            {
                temp |= (*i2c_dev->buf++) << (8 * i);
            }
            mmr_reg_writel(i2c_dev, XC_I2C0_DATA_LOAD + i2c_dev->nr*0x10, temp);
        }
    }
        
    //set up command register
    temp = 0;
    temp |= (msg->addr << (XC_I2C0_COMMAND_SLAVE_ADR_SHIFT));
    temp |= (wop << XC_I2C0_COMMAND_WOP_SHIFT);
    if (i2c_dev->buf_len == msg->len)
        temp |= (1 << XC_I2C0_COMMAND_START_EN_SHIFT);
    if (i2c_dev->buf_len == num_bytes && stop)
        temp |= (1 << XC_I2C0_COMMAND_STOP_EN_SHIFT);
    PDEBUG("i2c_dev->buf_len=%d, num_bytes=%d, stop_en=%d\n", i2c_dev->buf_len, num_bytes, stop_en);
    temp |= (num_bytes << XC_I2C0_COMMAND_BYTE_CNT_SHIFT);
    PDEBUG("XC_I2C_COMMAND: %x\n", temp);
	i2c_dev->wait_complete = true;
    mmr_reg_writel(i2c_dev, XC_I2C0_COMMAND + i2c_dev->nr*0x10, temp);

    timeout = wait_for_completion_timeout(&i2c_dev->cmd_complete,
						XC6_I2C_TIMEOUT);

		if (unlikely(i2c_dev->cmd_err))
    {
			PERROR("bus %d error: 0x%x, cmd: 0x%x, cmd_reg: 0x%x\n", i2c_dev->bus_num, i2c_dev->cmd_err,
					temp, mmr_reg_readl(i2c_dev, XC_I2C0_COMMAND + i2c_dev->nr*0x10));

			/* recover the bus busy */
			if (i2c_dev->cmd_err & (XC_PPC_INT_STATUS_I2C0_BUSY_ERROR_MASK << i2c_dev->nr * 5))
				xc6_i2c_bus_recover(i2c_dev);

			//reset the I2C FIFO counters
        mmr_reg_writel(i2c_dev, XC_I2C0_DATA_READ + i2c_dev->nr*0x10, 0x00000000);
			return -EIO;
	}

	if (unlikely(timeout == 0)) 
	{
			i2c_dev->int_mask = 0;  // switch to polling mode, checking if interrupt is pending.

			intStat = mmr_reg_readl(i2c_dev, XC_PPC_INT_STATUS);
			i2cCmd = mmr_reg_readl(i2c_dev, XC_I2C0_COMMAND + i2c_dev->nr*0x10);
			
			/* If no command error, output warning only */
			PWARN("bus: %d cmd: 0x%x, cmd_reg: 0x%x timed out \n", i2c_dev->bus_num, temp, i2cCmd);
			PDEBUG("intStat:%#x int_mask:%#x nr:%d\n", intStat, savedIntMask, i2c_dev->nr);

			if (intStat & savedIntMask) {
				if (intStat & (XC_PPC_INT_STATUS_I2C0_XFERDONE_MASK << i2c_dev->nr)) {
				// There is an I2C transfer done interrupt pending
					i2c_dev->wait_complete = false;
				}
				else {
					// Handle command and bus error 
					i2c_dev->cmd_err = (intStat & savedIntMask) & ~(XC_PPC_INT_STATUS_I2C0_XFERDONE_MASK << i2c_dev->nr);
					i2c_dev->cmd_err |= (i2cCmd & XC_I2C0_COMMAND_ERROR_MASK);
					
					if (i2c_dev->cmd_err) {
						PDEBUG("Error handling\n");
						if (i2c_dev->cmd_err & (XC_PPC_INT_STATUS_I2C0_BUSY_ERROR_MASK << i2c_dev->nr * 5))
							xc6_i2c_bus_recover(i2c_dev);

						//reset the I2C FIFO counters
        				mmr_reg_writel(i2c_dev, XC_I2C0_DATA_READ + i2c_dev->nr*0x10, 0x00000000);
						mmr_reg_writel(i2c_dev, XC_PPC_INT_STATUS, (intStat & savedIntMask));
						i2c_dev->int_mask = savedIntMask;
						return -EIO;
					}
				}
				mmr_reg_writel(i2c_dev, XC_PPC_INT_STATUS, (intStat & savedIntMask));
			}

			i2c_dev->int_mask = savedIntMask; // switch back to interrupt mode.
	}

    if (wop == 0) //read
    {
        //read data
        num_words = num_bytes >> 2;
        if (num_words != 0)
        {
            for (i = 0; i < num_words; i++)
            {
                temp = mmr_reg_readl(i2c_dev, XC_I2C0_DATA_READ + i2c_dev->nr*0x10);
                *i2c_dev->buf++ = temp;
                *i2c_dev->buf++ = temp >> 8;
                *i2c_dev->buf++ = temp >> 16;
                *i2c_dev->buf++ = temp >> 24;
            }
        }

        left_bytes = num_bytes & 0x3;
        if (left_bytes != 0)
        {
            temp = mmr_reg_readl(i2c_dev, XC_I2C0_DATA_READ + i2c_dev->nr*0x10);
            PDEBUG("read: %x\n", temp);
            for (i = 0; i < left_bytes; i++)
            {
                *i2c_dev->buf++ = temp >> (8 * i);
            }
        }
    }

    i2c_dev->buf_len -= num_bytes;

    }while (i2c_dev->buf_len);

	return 0;
}


/*
 * Prepare controller for a transaction and call xc6_i2c_xfer_msg
 * to do the work.
 */
static int
xc6_i2c_xfer(struct i2c_adapter *adap, struct i2c_msg msgs[], int num)
{
	struct xc6_i2c_dev *i2c_dev = i2c_get_adapdata(adap);
	int i;
	int r = 0;

	mutex_lock(i2c_dev->lock);
	
	if (i2c_dev->bus_num > 1) {
		PERROR("BUS %d not supported \n", i2c_dev->bus_num);
		mutex_unlock(i2c_dev->lock);
		return -EIO;
	}
	
	for (i = 0; i < num; i++)
    {
		r = xc6_i2c_xfer_msg(adap, &msgs[i], (i == (num - 1)));
		if (r != 0)
			break;
	}
	mutex_unlock(i2c_dev->lock);

	if (r == 0)
		r = num;

	return r;
}

static u32
xc6_i2c_func(struct i2c_adapter *adap)
{
	return I2C_FUNC_I2C | (I2C_FUNC_SMBUS_EMUL & ~I2C_FUNC_SMBUS_QUICK) |
	       I2C_FUNC_PROTOCOL_MANGLING;
}

static irqreturn_t
xc6_i2c_isr(int irq, void *dev_id)
{
	struct xc6_i2c_dev *i2c_dev = dev_id;
	irqreturn_t ret = IRQ_NONE;
	volatile u32 intStat;
	volatile u32 i2cStat;

    PDEBUG("Enter\n");
	intStat = mmr_reg_readl(i2c_dev, XC_PPC_INT_STATUS);
	if((intStat & i2c_dev->int_mask) && !i2c_dev->wait_complete)
		BUG();

	if((intStat & i2c_dev->int_mask) == 0)
		return ret;
   
    PDEBUG("intStat: %x\n", intStat);

	if (intStat & i2c_dev->int_mask)
	{
        PDEBUG("IRQ_HANDLED\n");
		ret = IRQ_HANDLED;
        i2c_dev->cmd_err = (intStat & i2c_dev->int_mask) & ~(XC_PPC_INT_STATUS_I2C0_XFERDONE_MASK << i2c_dev->nr);
        i2cStat = mmr_reg_readl(i2c_dev, XC_I2C0_COMMAND + i2c_dev->nr*0x10);
        PDEBUG("XC_I2C_COMMAND: %x, intStat:%#x\n", i2cStat, intStat);
        i2c_dev->cmd_err |= (i2cStat & XC_I2C0_COMMAND_ERROR_MASK);
        //clear interrupts
        mmr_reg_writel(i2c_dev, XC_PPC_INT_STATUS, (intStat & i2c_dev->int_mask));
		i2c_dev->wait_complete = false;
        complete(&i2c_dev->cmd_complete);
	}

    PDEBUG("Exit\n");

	return ret;
}

static const struct i2c_algorithm xc6_i2c_algo = {
	.master_xfer	= xc6_i2c_xfer,
	.functionality	= xc6_i2c_func,
};

static int xc6_i2c_install_irq(struct platform_device *pdev)
{
	struct xc6_i2c_dev  *i2c_dev = platform_get_drvdata(pdev);
    int i, ret;

    for (i = 0; i < XC6_I2C_NUM; i++, i2c_dev++)
    {
        ret = request_irq(i2c_dev->irq, xc6_i2c_isr, IRQF_SHARED, pdev->name, (void *)i2c_dev);
        if (ret) {
            PERROR("failure requesting irq %i\n", i2c_dev->irq);
            return ret;
        }
        
        #ifdef XC_SOC_BUILD
        ret = request_irq(XCODE6_IRQ_PROC5, xc6_i2c_isr, IRQF_SHARED, pdev->name, (void *)i2c_dev);
        if (ret) {
            PERROR("failure requesting irq %i\n", XCODE6_IRQ_PROC5);
            return ret;
        }
        #endif
    }

    return 0;
}

static int xc6_i2c_remove_irq(struct platform_device *pdev)
{
	struct xc6_i2c_dev  *i2c_dev = platform_get_drvdata(pdev);
    int i;

    for (i = 0; i < XC6_I2C_NUM; i++, i2c_dev++)
    {
        free_irq(i2c_dev->irq, (void *)i2c_dev);
        #ifdef XC_SOC_BUILD
            free_irq(XCODE6_IRQ_PROC5, (void *)i2c_dev);
        #endif
    }
    
    return 0;
}

static int xc6_i2c_probe(struct platform_device *pdev)
{
	struct xc6_i2c_dev	*i2c_dev;
	struct i2c_adapter	*adap;
	struct resource		*mem;
	u32 temp;
	int irq;
	int ret;
    int i;

	irq = platform_get_irq(pdev, 0);
    PDEBUG("IORESOURCE_IRQ: %d\n", irq);
	if (irq < 0) {
		PERROR("no irq resource\n");
		return irq;
	}

	mem = platform_get_resource(pdev, IORESOURCE_REG, 0);
    PDEBUG("IORESOURCE_REG: %x\n", mem->start);

	for (i = 0; i < XC6_I2C_BLOCKS; i++)
		mutex_init(&xc6_i2c_mutex[i]);
	mutex_init(&xc6_i2c_gpiom_mutex);

    i2c_dev = devm_kzalloc(&pdev->dev, XC6_I2C_NUM*sizeof(struct xc6_i2c_dev), GFP_KERNEL);
	if (!i2c_dev) {
		PERROR("Menory allocation failed\n");
		return -ENOMEM;
	}

	platform_set_drvdata(pdev, i2c_dev);

    for (i = 0; i < XC6_I2C_NUM ; i++, i2c_dev++)
    {
		i2c_dev->nr = i & 0x1; //two i2c masters and each master support two ports. I2C0:0,2; I2C1:1,3;
        i2c_dev->lock = &xc6_i2c_mutex[i2c_dev->nr];
        i2c_dev->bus_num = i;
        switch (i2c_dev->nr)
        {
            case 0:
            i2c_dev->int_mask = (XC_PPC_INT_STATUS_I2C0_XFERDONE_MASK | XC_PPC_INT_STATUS_I2C0_BUSY_ERROR_MASK |
                                 XC_PPC_INT_STATUS_I2C0_ARB_FAIL_MASK);
            break;

            case 1:
            i2c_dev->int_mask = (XC_PPC_INT_STATUS_I2C1_XFERDONE_MASK | XC_PPC_INT_STATUS_I2C1_BUSY_ERROR_MASK |
                                 XC_PPC_INT_STATUS_I2C1_ARB_FAIL_MASK);
            break;

            default:
                i2c_dev->int_mask = 0;
                PERROR("Wrong i2c bus number\n");
                break;
        }
        i2c_dev->dev = &pdev->dev;
    	i2c_dev->irq = irq;
    	i2c_dev->base = (void *)mem->start;
		i2c_dev->wait_complete = false;
        init_completion(&i2c_dev->cmd_complete);

		//enable I2C in GPIO_M
		mutex_lock(&xc6_i2c_gpiom_mutex);
    	temp = mmr_reg_readl(i2c_dev, XC_GPIO_M_CTRL);
		temp &=~(1<<(31-i2c_dev->bus_num));    
		mmr_reg_writel(i2c_dev, XC_GPIO_M_CTRL, temp);
		mutex_unlock(&xc6_i2c_gpiom_mutex);

		/* Change the xcode I2C slave address for customer board */
		temp = mmr_reg_readl(i2c_dev, XC_I2C_SLAVE_ADDR_OVERRIDE);
		if (temp == 0) {
			temp = mmr_reg_readl(i2c_dev, XC_CG_DUMMY_REG1) & 0xFFFF;
			switch (temp) {
				case 0x1100:
				case 0x1101:
				case 0x1102:
				case 0x1103:
				case 0x1104:
				case 0x1105:
				case 0x1106:
				case 0x1107:
				case 0x1108:
				case 0x1109:
				case 0x110A:
				case 0x110B:
				case 0x110C:
				case 0x1140:
				case 0x1141:
				case 0x1142:
					PDEBUG("Change XCode I2C slave address to 0x33\n");
					mmr_reg_writel(i2c_dev, XC_I2C_SLAVE_ADDR_OVERRIDE, 0x33);
					break;
				default:
					break;
			}
		}

    	msleep(10);

		if (!xc6_i2c_hwinit_flag[i2c_dev->nr]) {
			xc6_i2c_reset(i2c_dev);
			xc6_i2c_hwinit_flag[i2c_dev->nr] = true;
		}

    	adap = &i2c_dev->adapter;
    	i2c_set_adapdata(adap, i2c_dev);
    	adap->owner = THIS_MODULE;
    	adap->class = I2C_CLASS_HWMON;
    	snprintf(adap->name, sizeof(adap->name), "XCODE6-%d I2C-%d", pdev->id, i2c_dev->bus_num);
    	adap->algo = &xc6_i2c_algo;
    	adap->dev.parent = &pdev->dev;
    	adap->dev.of_node = pdev->dev.of_node;

    	/* i2c device drivers may be active on return from add_adapter() */
        PDEBUG(" ->i2c_add_adapter\n");
    	adap->nr = -1;
    	ret = i2c_add_adapter(adap);
    	if (ret) {
    		PERROR("failure adding adapter\n");
    		return ret;
    	}
    }

    xc6_i2c_install_irq(pdev);
    
	return 0;
}

static int xc6_i2c_remove(struct platform_device *pdev)
{
	struct xc6_i2c_dev  *i2c_dev = platform_get_drvdata(pdev);
    int i;

    for (i = 0; i < XC6_I2C_NUM; i++, i2c_dev++)
    {
        i2c_del_adapter(&i2c_dev->adapter);
    }
    
    xc6_i2c_remove_irq(pdev);

    devm_kfree(&pdev->dev, (void *)platform_get_drvdata(pdev));

	return 0;
}

#ifdef CONFIG_PM
static int xc6_i2c_suspend(struct platform_device *pdev, pm_message_t state)
{
	printk("xc6_i2c_suspend\n");
    xc6_i2c_remove_irq(pdev);

	return 0;
}

static int xc6_i2c_resume(struct platform_device *pdev)
{
	printk("xc6_i2c_resume\n");
    xc6_i2c_install_irq(pdev);

	return 0;
}
#endif

static struct platform_driver xc6_i2c_driver = {
	.probe		= xc6_i2c_probe,
	.remove		= xc6_i2c_remove,
	.driver		= {
		.name	= "xc6_i2c",
		.owner	= THIS_MODULE,
	},
	#ifdef CONFIG_PM
	.suspend    = xc6_i2c_suspend,
	.resume     = xc6_i2c_resume,
	#endif
};

static int __init xc6_i2c_init(void)
{
    struct platform_device *pDevice;
    s_xc_device info;
    int i;
    int error;
    
    for (i = 0; i < MAXXCODENUM; i++)
    {
        if (get_xc_pcie_device_info(i, &info) == 0)
        {
            PDEBUG("found xc device %d ok\n", i);
            pDevice = platform_device_alloc("xc6_i2c", i);

            if (!pDevice) 
            {
                PERROR("platform_device_alloc failed\n");
                return (-ENOMEM);
            }

            //memory resources
            xc6_i2c_resources[0].start = (resource_size_t)info.mp_mmr;
            xc6_i2c_resources[0].end = (resource_size_t)(xc6_i2c_resources[0].start + 0x20000 - 1);
            xc6_i2c_resources[0].flags = IORESOURCE_REG;
            PDEBUG("IORESOURCE_REG: %x\n", info.mp_mmr);

            //irq resources
            xc6_i2c_resources[1].start = info.m_irq;
            xc6_i2c_resources[1].end = 0;
            xc6_i2c_resources[1].flags = IORESOURCE_IRQ;
            PDEBUG("IORESOURCE_IRQ: %d\n", info.m_irq);
            
            PDEBUG(" ->platform_device_add_resources\n");

            error = platform_device_add_resources(pDevice, xc6_i2c_resources, 2);
            if (error)
            {
                PERROR("platform_device_add_resources failed\n");
                goto err_free_device;
            }

            PDEBUG(" ->platform_device_add\n");

            error = platform_device_add(pDevice);
            if (error)
            {
                PERROR("platform_device_add failed\n");
                goto err_free_device;
            }
            
            xc6_i2c_device[i] = pDevice;
        }
    }
    
	return platform_driver_register(&xc6_i2c_driver);

err_free_device:
    platform_device_put(pDevice);
    return error;
}
module_init(xc6_i2c_init);

static void __exit xc6_i2c_exit(void)
{
    int i;

    PDEBUG("platform_driver_unregister\n");
	platform_driver_unregister(&xc6_i2c_driver);

    for (i = 0; i < MAXXCODENUM; i++)
    {
        if (xc6_i2c_device[i] != NULL)
        {
            PDEBUG("platform_device_unregister\n");
            platform_device_unregister(xc6_i2c_device[i]);
        }
        else
            break;
    }
}
module_exit(xc6_i2c_exit);

MODULE_AUTHOR("Zhigang Luo <zluo@vixs.com>");
MODULE_DESCRIPTION("ViXS XCODE6 I2C bus adapter");
MODULE_LICENSE("GPL");
