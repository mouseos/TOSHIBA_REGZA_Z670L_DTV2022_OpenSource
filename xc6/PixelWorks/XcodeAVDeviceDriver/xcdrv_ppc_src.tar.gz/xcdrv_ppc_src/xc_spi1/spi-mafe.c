/*
 * spi-mafe.c - SPI master driver for ViXS System SPI master
 *
 * Copyright (C) 2015 ViXS Systems, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 */
#include <linux/module.h>
#include <linux/init.h>
#include <linux/syscore_ops.h>
#include <linux/errno.h>
#include <linux/interrupt.h>
#include <linux/dma-mapping.h>
#include <linux/io.h>
#include <linux/workqueue.h>
#include <linux/completion.h>
#include <linux/delay.h>
#include <linux/spi/spi.h>
#include <linux/platform_device.h>

#include <linux/mtd/partitions.h>
#include <linux/spi/flash.h>

#include <asm/io.h>
#include <asm/bug.h>

#include "xc6regs.h"
#include "xcboot.h"
#include "iia.h"

static int g_dbg_level = 3;  // 3 default to output error msg, 0 to disable all msg // 255 to enale all msg   // level larger than this will NOT output to /var/log/messages
module_param(g_dbg_level, int, 0644);
MODULE_PARM_DESC(g_dbg_level, "SPI1 debug msg level. 3: default, output error msg; 0: disable all msg; 255: enable all msg.");


//#define MAFE_SPI_POLL_MODE
//#define MAFE_SPI_ENGINEER_BOARD_TEST
#define DRIVER_NAME	"xc6_spi1"
#define MAFE_SPI_TIMEOUT 1000
#define MAFE_SPI_DMA_BUF_SIZE 1024
#define MAFE_SPI_DMA_BUF_OFFSET (158*1024)
#define MAFE_SPI_BUS_CNT 4
#define MAFE_SPI_BUS_NUM 1


enum {
    DBGLEVEL0       = 0,
    DBGLEVELERR     = 1,
    DBGLEVELWARN    = 2,
    DBGLEVELINFO    = 3,
    DBGLEVELDEBUG   = 4,
    DBGLEVELMAX     = 255
};

#define ALL_MSG "xc6_spi1, "

static void print_debug(int level, char *fmt, ...);

#define PERROR(format, args...)    print_debug(DBGLEVELERR, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PWARN(format, args...)     print_debug(DBGLEVELWARN, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PINFO(format, args...)     print_debug(DBGLEVELINFO, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PDEBUG(format, args...)    print_debug(DBGLEVELDEBUG, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)
#define PVERBOSE(format, args...)  print_debug(DBGLEVEL0, "[%s] %d:"format, __FUNCTION__, __LINE__, ##args)

struct mafe_spi_pdata {
	unsigned int board_id;
	unsigned int m_irq;
	void __iomem *mp_mmr;
	void __iomem *mp_mmfb;
};

struct mafe_spi {	
	struct spi_master *master;
	struct device *dev;
    void __iomem *base;
    void __iomem *ch_base;
    void __iomem *fb_base;
	spinlock_t lock;
	unsigned int irq;
    u32 channel;
    u32 cur_speed;
    u8 cur_mode;
    u8 *dma_tx_buf;
	u8 *dma_rx_buf;
	u32 dma_tx_buf_phy;
	u32 dma_rx_buf_phy;
    bool wait_complete;
    u32 waitMask;
	struct completion done;
};

static struct platform_device *mafe_spi_device[MAXXCODENUM][MAFE_SPI_BUS_CNT] = {{NULL},};

static void print_debug(int level, char *fmt, ...)
{
    va_list ap ;
    char s[128];

    if (level > g_dbg_level) 
        return;
    
    va_start(ap, fmt);
    vsnprintf(s, sizeof(s), fmt, ap);
    printk(KERN_NOTICE  ALL_MSG"%s", s);
    va_end(ap);
}

static inline void mafe_spi_en_irq(struct mafe_spi *mafe_spi)
{
	u32 tmp;
    void __iomem *reg;
    
    // clear interrupt
    reg = mafe_spi->ch_base + XC_MDM_INTSTATUS;
    tmp = readl(reg);
    writel(tmp, reg);

    //enable interrupt
    reg = mafe_spi->ch_base + XC_MDM_INTMASK;
    tmp = XC_MDM_INTMASK_INTTIMER_MASK_MASK | XC_MDM_INTMASK_INTEMPTY_MASK_MASK;
    writel(tmp, reg);

	return;
}

static inline void mafe_spi_dis_irq(struct mafe_spi *mafe_spi)
{
	u32 tmp;
    void __iomem *reg;
    
    //disable interrupt
    reg = mafe_spi->ch_base + XC_MDM_INTMASK;
    tmp = 0;
    writel(tmp, reg);	
	return;
}

unsigned int mafe_spi_get_sclk(struct mafe_spi *mafe_spi)
{
    unsigned int freq = 144;
    int sclk_sel, div_int;
    void __iomem *reg;

    freq = 144;
    
    reg = mafe_spi->base + XC_CG_CLK_SRC_EN0;
    sclk_sel = (readl(reg) & XC_CG_CLK_SRC_EN0_SCLK_SRC_EN_MASK);
    // 0: Use XTL clock
    if(!sclk_sel){
        return (freq * 1000000);
    }

    // 1: Use clock source selected by SCLK_SRC_SEL
    reg = mafe_spi->base + XC_CG_CLK_SRC_SEL0;
    sclk_sel = (readl(reg) & XC_CG_CLK_SRC_SEL0_SCLK_SRC_SEL_MASK) >> 
                XC_CG_CLK_SRC_SEL0_SCLK_SRC_SEL_SHIFT;
    switch(sclk_sel){
    case 0:
        // $0:CG_PLL1/5
        reg = mafe_spi->base + XC_CG_PLL1_FREQ;
        div_int = (readl(reg) & XC_CG_PLL1_FREQ_FB_DIV_INT_MASK) >> 
                   XC_CG_PLL1_FREQ_FB_DIV_INT_SHIFT;
        freq = (div_int * freq) / 5;
        break;
    case 1:
        // $1:CG_PLL1/10
        reg = mafe_spi->base + XC_CG_PLL1_FREQ;
        div_int = (readl(reg) & XC_CG_PLL1_FREQ_FB_DIV_INT_MASK) >> 
                   XC_CG_PLL1_FREQ_FB_DIV_INT_SHIFT;
        freq = (div_int * freq) / 10;
        break;
    case 2:
        // $2:CG_PLL0/12
        reg = mafe_spi->base + XC_CG_PLL0_FREQ;
        div_int = (readl(reg) & XC_CG_PLL0_FREQ_FB_DIV_INT_MASK) >> 
                   XC_CG_PLL0_FREQ_FB_DIV_INT_SHIFT;
        freq = (div_int * freq) / 12;
        break;
    case 3:
        // $3:CG_PLL3/8
        reg = mafe_spi->base + XC_CG_PLL3_FREQ;
        div_int = (readl(reg) & XC_CG_PLL3_FREQ_FB_DIV_INT_MASK) >> 
                   XC_CG_PLL3_FREQ_FB_DIV_INT_SHIFT;
        freq = (div_int * freq) / 8;
        break;
    case 4:
        // $4:CG_PLL2/6
        reg = mafe_spi->base + XC_CG_PLL2_FREQ;
        div_int = (readl(reg) & XC_CG_PLL2_FREQ_FB_DIV_INT_MASK) >> 
                   XC_CG_PLL2_FREQ_FB_DIV_INT_SHIFT;
        freq = (div_int * freq) / 6;
        break;
    case 5:
        // $5:CG_PLL0/8
        reg = mafe_spi->base + XC_CG_PLL0_FREQ;
        div_int = (readl(reg) & XC_CG_PLL0_FREQ_FB_DIV_INT_MASK) >> 
                   XC_CG_PLL0_FREQ_FB_DIV_INT_SHIFT;
        freq = (div_int * freq) / 8;
        break;
    case 6:
        // $6:CG_PLL4/6
        reg = mafe_spi->base + XC_CG_PLL4_FREQ;
        div_int = (readl(reg) & XC_CG_PLL4_FREQ_FB_DIV_INT_MASK) >> 
                   XC_CG_PLL4_FREQ_FB_DIV_INT_SHIFT;
        freq = (div_int * freq) / 6;
        break;
    case 7:
        // $7:CG_PLL1/4
        reg = mafe_spi->base + XC_CG_PLL1_FREQ;
        div_int = (readl(reg) & XC_CG_PLL1_FREQ_FB_DIV_INT_MASK) >> 
                   XC_CG_PLL1_FREQ_FB_DIV_INT_SHIFT;
        freq = (div_int * freq) / 4;
        break;
    default:
        break;
    }

    PDEBUG("X %d MHz\n", freq);

    return (freq * 1000000);
}

unsigned int mafe_spi_get_heuclk(struct mafe_spi *mafe_spi)
{
    unsigned int freq = 144;  
    int hueclk_sel, div_int;
    void __iomem *reg;

    freq = 144;
    reg = mafe_spi->base + XC_CG_CLK_SRC_EN0;
    hueclk_sel = (readl(reg) & XC_CG_CLK_SRC_EN0_HUECLK_SRC_EN_MASK);
    // 0: Use XTL clock
    if(!hueclk_sel){
        return (freq * 1000000);
    }

    // 1: Use clock source selected by HUECLK_SRC_SEL
    reg = mafe_spi->base + XC_CG_CLK_SRC_SEL0;
    hueclk_sel = (readl(reg) & XC_CG_CLK_SRC_SEL0_HUECLK_SRC_SEL_MASK) >> 
                  XC_CG_CLK_SRC_SEL0_HUECLK_SRC_SEL_SHIFT;

    switch(hueclk_sel){
    case 0:
        // $0:CG_PLL2/6
        reg = mafe_spi->base + XC_CG_PLL2_FREQ;
        div_int = (readl(reg) & XC_CG_PLL2_FREQ_FB_DIV_INT_MASK) >> 
                   XC_CG_PLL2_FREQ_FB_DIV_INT_SHIFT;
        freq = (div_int * freq) / 6;
        break;
    case 1:
        // $1:CG_PLL2/12
        reg = mafe_spi->base + XC_CG_PLL2_FREQ;
        div_int = (readl(reg) & XC_CG_PLL2_FREQ_FB_DIV_INT_MASK) >> 
                   XC_CG_PLL2_FREQ_FB_DIV_INT_SHIFT;
        freq = (div_int * freq) / 12;
        break;
    case 2:
        // $2:SCLK
        freq = mafe_spi_get_sclk(mafe_spi) / 1000000;
        break;
    default:
        break;
    }

    PDEBUG("X %d MHz\n", freq);

    return (freq * 1000000);
}

static void mafe_spi_config(struct mafe_spi *mafe_spi)
{
    u32 data;
    void __iomem *reg;

    // 1. set padu
    reg = mafe_spi->base + XC_RBM_PADU_CTRL;
    data = readl(reg);
    switch (mafe_spi->channel) {
    case 0:
        // MAFE0
        data |= (0x01 << XC_RBM_PADU_CTRL_PADU_CTRL_UART0_SHIFT);
        break;
    case 1:
        // MAFE1
        data |= (0x01 << XC_RBM_PADU_CTRL_PADU_CTRL_UART1_SHIFT);
        break;
    default:
        PERROR("Wrong channel number\n");
        return;
    }

    PDEBUG("RBM_PADU_CTRL %x\n", data);
    writel(data, reg);

    // 2. set frequence, 50/50 duty cycle
    data = (mafe_spi_get_heuclk(mafe_spi) / mafe_spi->cur_speed) / 2;
    PDEBUG("MDM_GSCLK %x\n", data);
    reg = mafe_spi->ch_base + XC_MDM_GSCLK_HI;
    writel(data, reg);
    reg = mafe_spi->ch_base + XC_MDM_GSCLK_LO;
    writel(data, reg);

    // 3. set FSYNC
    reg = mafe_spi->ch_base + XC_MDM_FS_HI;
    // always 1 for SPI mode. define the high pulse between multiple transfer. 1 means 2 GSCLK period
    writel(0x01, reg);
    reg = mafe_spi->ch_base + XC_MDM_FS_LO;
    // always 0 for SPI. define the low pulse between multiple transfer
    writel(0x00, reg);

    // 4. set BYTEPAUSE, always 0 for SPI mode
    reg = mafe_spi->ch_base + XC_MDM_BYTEPAUSE;
    writel(0x00, reg);

    // 5. set GSICFG
    reg = mafe_spi->ch_base + XC_MDM_GSICFG;
    data = 0;
    // GSI_INPUTEDGE and GSI_OUTPUTEDGE
    if (mafe_spi->cur_mode & SPI_CPHA){ //rising edge
        data &= ~XC_MDM_GSICFG_GSI_INPUTEDGE_MASK;
        data |= XC_MDM_GSICFG_GSI_OUTPUTEDGE_MASK;
    }else{ //falling edge
        data |= XC_MDM_GSICFG_GSI_INPUTEDGE_MASK;
        data &= ~XC_MDM_GSICFG_GSI_OUTPUTEDGE_MASK;
    }
    // GSCLK_DEFAULT
    if (mafe_spi->cur_mode & SPI_CPOL){
        data |= XC_MDM_GSICFG_GSI_GSCLK_DEFAULT_MASK;
    }else{
        data &= ~XC_MDM_GSICFG_GSI_GSCLK_DEFAULT_MASK;
    }
    //FSCS_DEFAULT
    data |= XC_MDM_GSICFG_GSI_FSCS_DEFAULT_MASK;
    // STLED316S_MODE(not support yet)
    data &= ~XC_MDM_GSICFG_GSI_STLED316S_MODE_MASK;
    // FLIP_FINE_TUNE(not support yet)
    data &= ~XC_MDM_GSICFG_GSI_FLIP_FINE_TUNE_MASK;
	// BITORDER(always msb first)
    data |= XC_MDM_GSICFG_GSI_BITORDER_MASK;
	// BYTEORDER(always LSB first)
    data &= ~XC_MDM_GSICFG_GSI_BYTEORDER_MASK;

    // GSI_V92MODE
    // GSI_USEEXTCLK = 0    
    // GSI_USEEXTFS = 0
    // SLIC_EN = 0
    data &= ~(XC_MDM_GSICFG_GSI_V92MODE_MASK | 
              XC_MDM_GSICFG_GSI_USEEXTCLK_MASK |
              XC_MDM_GSICFG_GSI_USEEXTFS_MASK |
              XC_MDM_GSICFG_GSI_SLIC_EN_MASK);
	data |= XC_MDM_GSICFG_GSI_BITORDER_MASK;

    PDEBUG("MDM_GSICFG %x\n", data);
    writel(data, reg);

    // soft reset
    udelay(1);
    reg = mafe_spi->ch_base + XC_MDM_SOFTRST;
    writel(0x0, reg);
    udelay(1);
    //reg = mafe_spi->ch_base + XC_MDM_INTMASK;
    //writel(readl(reg) | XC_MDM_INTMASK_INTTIMER_MASK_MASK | XC_MDM_INTMASK_INTEMPTY_MASK_MASK, reg);

    return;
}

static inline void mafe_spi_reset(struct mafe_spi *mafe_spi)
{
	void __iomem *reg;
	u32 tmp;

    mafe_spi->cur_speed = 0;
    mafe_spi->wait_complete = false;

    if (mafe_spi->channel == 0 || mafe_spi->channel == 1) {
        // reset
        reg = mafe_spi->base + XC_ACC_RESET_REG0;
        tmp = readl(reg);
        if (mafe_spi->channel == 0)
            tmp |= XC_ACC_RESET_REG0_MAFE0_RESET_MASK;
        else
            tmp |= XC_ACC_RESET_REG0_MAFE1_RESET_MASK;
        writel(tmp, reg);
        udelay(1);
        
        // clear reset
        if (mafe_spi->channel == 0)
            tmp &= ~XC_ACC_RESET_REG0_MAFE0_RESET_MASK;
        else
            tmp &= ~XC_ACC_RESET_REG0_MAFE1_RESET_MASK;
        writel(tmp, reg);
        udelay(1);

        // blk stop
        reg = mafe_spi->base + XC_ACC_BLK_STOP0;
        tmp = readl(reg);
        if (mafe_spi->channel == 0)
            tmp &= ~XC_ACC_BLK_STOP0_MAFE0_BLK_STOP_MASK;
        else
            tmp &= ~XC_ACC_BLK_STOP0_MAFE1_BLK_STOP_MASK;
        writel(tmp, reg);
        udelay(1);
    }

}

static irqreturn_t mafe_spi_isr(int irq, void* dev_id)
{
	struct mafe_spi *mafe_spi = dev_id;
	u32 temp;
    void __iomem *reg;
	  
	if (unlikely(dev_id == NULL))
		return IRQ_NONE;

    reg = mafe_spi->ch_base + XC_MDM_INTSTATUS;
	temp = readl(reg);
    PDEBUG("INT_STATUS: %x\n", temp);
	if ((temp & (XC_MDM_INTMASK_INTTIMER_MASK_MASK | XC_MDM_INTMASK_INTEMPTY_MASK_MASK)) == 0)
		return IRQ_NONE;

	//clean up only INTTIMER and INTEMPTY interrupt
	temp = XC_MDM_INTMASK_INTTIMER_MASK_MASK | XC_MDM_INTMASK_INTEMPTY_MASK_MASK;
	writel(temp, reg);

    if (mafe_spi->wait_complete)
	    complete(&mafe_spi->done);
	
    return IRQ_HANDLED;
}

static void mafe_spi_soft_reset (struct mafe_spi *mafe_spi)
{
    void __iomem *reg;

    reg = mafe_spi->ch_base + XC_MDM_SOFTRST;
    writel(0x0001, reg);
    ndelay(60);
    writel(0x0000, reg);
}

#ifdef MAFE_SPI_POLL_MODE
static int mafe_spi_wait_complete (struct mafe_spi *mafe_spi)
{
    int i = 0;
    void __iomem *reg;
    u32 status;

    reg = mafe_spi->ch_base + XC_MDM_INTSTATUS; 

    udelay(1);

    for (i=0; i < 1000000; i++)
    {
        status = readl(reg);
        if ((status & mafe_spi->waitMask) == mafe_spi->waitMask)
        {
            return 0;
        }
    }
    return -ETIMEDOUT;
}
#else
static int mafe_spi_wait_complete (struct mafe_spi *mafe_spi)
{
    unsigned long timeout;
    int status = 0;
    
    timeout = wait_for_completion_timeout(&mafe_spi->done, MAFE_SPI_TIMEOUT);
    if (timeout == 0) 
    {
        PERROR("MAFE SPI controller timed out\n");
        status = -ETIMEDOUT;
    }

    return status;
}
#endif

static int mafe_spi_shift_data (struct mafe_spi *mafe_spi, int frameSize)
{
    void __iomem *reg;
    unsigned long flags;
    int status = 0;
    
    spin_lock_irqsave(&mafe_spi->lock, flags);

    mafe_spi->wait_complete = true;

    reg = mafe_spi->ch_base + XC_MDM_INT_SIZE;
    writel(0x1, reg);

    reg = mafe_spi->ch_base + XC_MDM_FRAMECNT;
    writel(0x1, reg);

    reg = mafe_spi->ch_base + XC_MDM_FRAMESIZE;
    writel(frameSize, reg);

    reg = mafe_spi->ch_base + XC_MDM_FS_LO;
    writel(0, reg);
    writel(0xFFF, reg);

    reg = mafe_spi->ch_base + XC_MDM_STATE;
    writel(0x0001, reg);

#ifdef MAFE_SPI_POLL_MODE
    mafe_spi->waitMask = XC_MDM_INTSTATUS_INTTIMER_MASK;
#endif

    spin_unlock_irqrestore(&mafe_spi->lock, flags);

    status = mafe_spi_wait_complete(mafe_spi);

    reg = mafe_spi->ch_base + XC_MDM_STATE;
    writel(0x0000, reg);

    return status;
}

static int mafe_spi_transfer_one_message(struct spi_master *master,
					    struct spi_message *msg)
{
	struct mafe_spi *mafe_spi = spi_master_get_devdata(master);
	struct spi_device *spi = msg->spi;
    struct spi_transfer *xfer;
	int status = 0;
    void __iomem *reg;
    int i;
    u8 *tx_buf;
    u8 *rx_buf;
    int count;
    unsigned long flags;

    PDEBUG("enter\n");
    
    spin_lock_irqsave(&mafe_spi->lock, flags);

	/* If Master's(controller) state differs from that needed by Slave */
	if (mafe_spi->cur_speed != spi->max_speed_hz
			|| mafe_spi->cur_mode != spi->mode) {
		mafe_spi->cur_speed = spi->max_speed_hz;
		mafe_spi->cur_mode = spi->mode;
		mafe_spi_config(mafe_spi);
	}

    //enable SPI interrupt again in case it is disabled by SOC SPI driver
    mafe_spi_en_irq(mafe_spi);

    tx_buf = mafe_spi->dma_tx_buf;
    count = 0;
    
	list_for_each_entry(xfer, &msg->transfers, transfer_list) {

        PDEBUG("xfer->cs_change: %d\n", xfer->cs_change);
      
		if (xfer->tx_buf != NULL) {
            
            PDEBUG("Tx len: %d\n",xfer->len);
            memcpy(tx_buf, xfer->tx_buf, xfer->len);
            readl(mafe_spi->dma_tx_buf); //flush out pci memory write
            for (i=0;i<xfer->len;i++)
                PDEBUG("Tx%d:%x\n", i, ((u8*)xfer->tx_buf)[i]);
		}
        else {
            PDEBUG("Rx len: %d\n",xfer->len);
            memset(tx_buf, 0, xfer->len);
        }
        tx_buf += xfer->len;
        count += xfer->len;
        if (count >= MAFE_SPI_DMA_BUF_SIZE) {
            status = -EINVAL;
            PERROR("msg size too big\n");
            goto out;
        }
	}
        
    reg = mafe_spi->ch_base + XC_MDM_TX_BASE;
    writel(mafe_spi->dma_tx_buf_phy, reg);
    reg = mafe_spi->ch_base + XC_MDM_RX_BASE;
    writel(mafe_spi->dma_rx_buf_phy, reg);

    mafe_spi_soft_reset(mafe_spi);

    spin_unlock_irqrestore(&mafe_spi->lock, flags);

    status = mafe_spi_shift_data(mafe_spi, count);
    
	spin_lock_irqsave(&mafe_spi->lock, flags);

    if (status != 0){
        PERROR("Shift data FAILED!");
        goto out;
    }

    rx_buf = mafe_spi->dma_rx_buf;
    list_for_each_entry(xfer, &msg->transfers, transfer_list) {

        if (xfer->rx_buf != NULL) {
            reg = mafe_spi->ch_base + XC_MDM_INTSTATUS;
            if((readl(reg) & XC_MDM_INTSTATUS_RXFREE_ENTRIES_MASK) != 
                XC_MDM_INTSTATUS_RXFREE_ENTRIES_MASK) 
            {
                reg = mafe_spi->ch_base + XC_MDM_BUFFFLUSH;
                writel(0x1, reg);

#ifdef MAFE_SPI_POLL_MODE
                mafe_spi->waitMask = XC_MDM_INTSTATUS_INTEMPTY_MASK;
#endif
                spin_unlock_irqrestore(&mafe_spi->lock, flags);

                status = mafe_spi_wait_complete(mafe_spi);
                
                spin_lock_irqsave(&mafe_spi->lock, flags);

                if (status != 0) 
                {
                    PERROR("Flushing of reading FAILED!");
                    goto out;
                }
            }
            
            memcpy(xfer->rx_buf, rx_buf, xfer->len);
		}

        rx_buf += xfer->len;

	}
        
    msg->actual_length += count;

out:
	msg->status = status;
    
    spin_unlock_irqrestore(&mafe_spi->lock, flags);

	spi_finalize_current_message(master);

    PDEBUG("exit\n");

	return 0;
}

static int mafe_spi_setup(struct spi_device *spi)
{	
	return 0;
}

static void mafe_spi_cleanup(struct spi_device *spi)
{
	return;
}

#ifdef MAFE_SPI_ENGINEER_BOARD_TEST
static struct mtd_partition spi_partitions_eng[] = {
	{
		.name	= "M25P16_SPI_FS",
		.offset = 0x000000,
		.size	= 0x100000,
	},
};

static struct flash_platform_data spi_flash_data_eng = {
	.name		= "M25P16",
	.nr_parts	= ARRAY_SIZE(spi_partitions_eng),
	.parts		= spi_partitions_eng,
	.type 		= "m25p16"
};

static struct spi_board_info flash_eng = {
	.modalias	= "m25p80",
	.platform_data = &spi_flash_data_eng,
	.max_speed_hz = 16000000,
	.bus_num	= MAFE_SPI_BUS_NUM + 1,
	.chip_select = 0,
	.mode		=  SPI_MODE_3,
};
#else
static struct spi_board_info spi_dev = {
	.modalias	= "spidev",
	.max_speed_hz = 2000000,
	.bus_num	= MAFE_SPI_BUS_NUM + 1,
	.chip_select = 0,
	.mode		=  SPI_MODE_3,
};
#endif

static int mafe_spi_probe(struct platform_device *pdev)
{
	struct spi_master	*master;
    struct mafe_spi_pdata *pdata = (struct mafe_spi_pdata*)pdev->dev.platform_data;
	struct mafe_spi	*mafe_spi = NULL;
	int status;
#ifndef XC_SOC_BUILD
    void __iomem *reg;
#endif
    
	PDEBUG("START: XCode SPI Controller driver\n");

	master = spi_alloc_master(&pdev->dev, sizeof *mafe_spi);
	if (!master) {
		PERROR("Fail to allocate master\n");
		return -ENOMEM;
	}
    
	mafe_spi = spi_master_get_devdata(master);
	mafe_spi->dev = &pdev->dev;
    mafe_spi->channel = pdev->id;
    mafe_spi->base = pdata->mp_mmr;
    mafe_spi->ch_base = mafe_spi->base + mafe_spi->channel*0x80;
    
#ifndef XC_SOC_BUILD
    mafe_spi->irq = pdata->m_irq;
    PDEBUG("mp_mmr: %x\n", pdata->mp_mmr);
    mafe_spi->dma_tx_buf = pdata->mp_mmfb + MAFE_SPI_DMA_BUF_OFFSET;
    mafe_spi->dma_rx_buf = mafe_spi->dma_tx_buf + MAFE_SPI_DMA_BUF_SIZE;
    
    reg = mafe_spi->base + XC_CG_DUMMY_REG4;
    mafe_spi->dma_tx_buf_phy = readl(reg) + MAFE_SPI_DMA_BUF_OFFSET;
    PDEBUG("dma_tx_buf_phy: %x\n", mafe_spi->dma_tx_buf_phy);
    mafe_spi->dma_rx_buf_phy = mafe_spi->dma_tx_buf_phy + MAFE_SPI_DMA_BUF_SIZE;
#else
    mafe_spi->irq = XCODE6_IRQ_MAFE;
    mafe_spi->dma_tx_buf = dma_alloc_coherent(NULL, MAFE_SPI_DMA_BUF_SIZE,
		                                      &mafe_spi->dma_tx_buf_phy, GFP_KERNEL);
    if (!mafe_spi->dma_tx_buf) {
		PERROR("Fail to allocate dma_tx_buf\n");
        status = -ENOMEM;
		goto free_master;
    }
	
    PDEBUG("dma_tx_buf: %x dma_tx_buf_phy: %x\n", mafe_spi->dma_tx_buf, mafe_spi->dma_tx_buf_phy);

    mafe_spi->dma_rx_buf = dma_alloc_coherent(NULL, MAFE_SPI_DMA_BUF_SIZE,
		                                      &mafe_spi->dma_rx_buf_phy, GFP_KERNEL);
    if (!mafe_spi->dma_rx_buf) {
		PERROR("Fail to allocate dma_rx_buf\n");
        status = -ENOMEM;
		goto free_master;
    }
	
    PDEBUG("dma_rx_buf: %x dma_rx_buf_phy: %x\n", mafe_spi->dma_rx_buf, mafe_spi->dma_rx_buf_phy);
#endif
    
    init_completion(&mafe_spi->done);
	spin_lock_init(&mafe_spi->lock);
    
	platform_set_drvdata(pdev, mafe_spi);
	
	mafe_spi_reset(mafe_spi);
	
	master->num_chipselect = 1;
	master->bus_num = MAFE_SPI_BUS_NUM + mafe_spi->channel + pdata->board_id * 10;
	master->mode_bits = SPI_CPOL | SPI_CPHA;
	master->setup = mafe_spi_setup;
	master->transfer_one_message = mafe_spi_transfer_one_message;
	master->cleanup = mafe_spi_cleanup;
	mafe_spi->master = master;
	PDEBUG("bus# %d num_cs %d irq# %d\n", master->bus_num, master->num_chipselect, mafe_spi->irq);
#ifndef MAFE_SPI_POLL_MODE
	status = request_irq(mafe_spi->irq, mafe_spi_isr, IRQF_SHARED, "mafe_spi_irq", (void*)mafe_spi);
	if (status){
		PERROR("fail to request irq %d error %d\n", mafe_spi->irq, status);
		goto free_master;
	}

#ifndef XC_SOC_BUILD
    IIAHostSetMask(mafe_spi->base, IIA_MAFE_INT);
#endif
    
    mafe_spi_en_irq(mafe_spi);
#else

#ifndef XC_SOC_BUILD
    IIAHostClearMask(mafe_spi->base, IIA_MAFE_INT);
#endif

#endif

	status = spi_register_master(master);	

	if (status < 0){
		PERROR("fail to register driver, errno:%d\n", status);
#ifdef MAFE_SPI_POLL_MODE
        goto free_master;
#else
        goto free_irq;
#endif
	}  

#ifdef MAFE_SPI_ENGINEER_BOARD_TEST
    if (mafe_spi->channel == 1) {
		flash_eng.bus_num = master->bus_num;
        spi_new_device(master, &flash_eng);
    }
#else
	spi_dev.bus_num = master->bus_num;
	spi_new_device(master, &spi_dev);
#endif
	
	PDEBUG("END: Mafe SPI Controller driver probe success\n");		
	return status;

#ifndef MAFE_SPI_POLL_MODE
free_irq:
	free_irq(mafe_spi->irq, (void*)mafe_spi);
#endif
free_master:
	if(master)
		spi_master_put(master);
    
	PERROR("Mafe SPI Controller driver init fail\n");
	return status;	
}

static int mafe_spi_remove(struct platform_device *pdev)
{
	struct mafe_spi *mafe_spi;	

	mafe_spi = platform_get_drvdata(pdev);

    spi_unregister_master(mafe_spi->master);
#ifndef MAFE_SPI_POLL_MODE
    mafe_spi_dis_irq(mafe_spi);
	free_irq(mafe_spi->irq, mafe_spi);
#endif
	platform_set_drvdata(pdev, NULL);
#ifdef XC_SOC_BUILD
    dma_free_coherent(NULL, MAFE_SPI_DMA_BUF_SIZE, mafe_spi->dma_tx_buf,
                      mafe_spi->dma_tx_buf_phy);
    dma_free_coherent(NULL, MAFE_SPI_DMA_BUF_SIZE, mafe_spi->dma_rx_buf,
                      mafe_spi->dma_rx_buf_phy);
#endif
	spi_master_put(mafe_spi->master);
	
	return 0;
}

static struct platform_driver mafe_spi_driver = {
	.probe		= mafe_spi_probe,
    .remove     = mafe_spi_remove,
	.driver		= {
		.name	= "xc6_spi1",
        .owner	= THIS_MODULE,
	},
};

static int __init mafe_spi_init(void)
{
    struct platform_device *pDevice;
	struct mafe_spi_pdata spi_pdata;
    s_xc_device info;
    int i;
    int j;
    int error;
    
    for (i = 0; i < MAXXCODENUM; i++)
    {
        if (get_xc_pcie_device_info(i, &info) == 0)
        {
            PDEBUG("found xc device %d ok\n", i);

			spi_pdata.board_id = i;
			spi_pdata.m_irq = info.m_irq;
			spi_pdata.mp_mmr = info.mp_mmr;
			spi_pdata.mp_mmfb = info.mp_mmfb;

            for (j = 0; j < MAFE_SPI_BUS_CNT; j++)
            {
                pDevice = platform_device_alloc("xc6_spi1", j);;

                if (!pDevice) 
                {
                    PERROR("platform_device_alloc failed\n");
                    return (-ENOMEM);
                }
                PDEBUG(" ->platform_device_add_resources\n");

                error = platform_device_add_data(pDevice, &spi_pdata, sizeof(spi_pdata));
                if (error)
                {
                    PERROR("platform_device_add_data failed\n");
                    goto err_free_device;
                }

                PDEBUG(" ->platform_device_add\n");

                error = platform_device_add(pDevice);
                if (error)
                {
                    PERROR("platform_device_add failed\n");
                    goto err_free_device;
                }
                
                mafe_spi_device[i][j] = pDevice;
            }
        }
    }
    
	return platform_driver_register(&mafe_spi_driver);

err_free_device:
    platform_device_put(pDevice);
    return error;
}
module_init(mafe_spi_init);

static void __exit mafe_spi_exit(void)
{
    int i;
    int j;

    PDEBUG("platform_driver_unregister\n");
	platform_driver_unregister(&mafe_spi_driver);

    for (i = 0; i < MAXXCODENUM; i++)
    {
        for (j = 0; j < MAFE_SPI_BUS_CNT; j++)
        {
            if (mafe_spi_device[i][j] != NULL)
            {
                PDEBUG("platform_device_unregister\n");
                platform_device_unregister(mafe_spi_device[i][j]);
            }
            else
                break;
        }
    }
}
module_exit(mafe_spi_exit);

MODULE_DESCRIPTION("SPI master driver for ViXS Mafe SPI Master");
MODULE_AUTHOR("Zhigang Luo <zluo@vixs.com>");
MODULE_LICENSE("GPL");
